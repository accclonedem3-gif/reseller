# Hướng Dẫn Lấy 3 Key PayOS Cho Altivox AI

## Mục Tiêu

CTV/shop cần lấy 3 thông tin sau từ payOS để dán vào Altivox AI:

1. **PayOS Client ID**
2. **PayOS API Key**
3. **PayOS Checksum Key**

## Lưu Ý Quan Trọng

- Mỗi CTV/shop nên dùng key payOS riêng của mình.
- Không gửi 3 key này vào chat công khai, ảnh chụp màn hình, GitHub, Facebook hoặc nhóm Telegram.
- Trong Altivox AI, 3 key này được nhập ở màn hình cấu hình bot
- Nếu đổi kênh thanh toán trên payOS, nên cập nhật lại cả 3 key trong Altivox AI.

## Điều Kiện Trước Khi Lấy Key

1. Có tài khoản payOS tại: [https://my.payos.vn](https://my.payos.vn)
2. Tài khoản/tổ chức/cá nhân trên payOS đã được xác thực.
3. Đã liên kết ít nhất một tài khoản ngân hàng vào payOS.
4. Đã tạo hoặc chuẩn bị tạo **Kênh thanh toán**.

## Cách Tạo Kênh Thanh Toán Và Lấy Key

### 1. Đăng nhập payOS

Vào: [https://my.payos.vn](https://my.payos.vn)

### 2. Vào menu "Kênh thanh toán"

Bấm **Tạo kênh thanh toán**.

### 3. Điền thông tin kênh thanh toán

Điền tên kênh thanh toán và logo nếu payOS yêu cầu, sau đó bấm **Tiếp tục**.

![Điền thông tin kênh thanh toán](https://payos.vn/docs/assets/images/channel-input-731f8e68026a6a78dabaaf74b3eb2a1b.png)

### 4. Chọn ngân hàng chính

Chọn ngân hàng chính cho kênh, rồi bấm **Tạo kênh thanh toán và tích hợp**.

![Tạo kênh thanh toán và tích hợp](https://payos.vn/docs/assets/images/create-channel-and-integration-3ce0234bc0d969667fa6cf374aba0b60.png)

### 5. Copy 3 key

Sau khi tạo kênh thành công, payOS sẽ hiển thị màn hình tích hợp web/app. Copy đúng 3 giá trị:

- **Client ID**
- **API Key**
- **Checksum Key**

![Màn hình hiển thị Client ID, API Key và Checksum Key](https://payos.vn/docs/assets/images/integration-7826ebc91a70eb2122e92f2b29a7f89f.png)

Copy từng giá trị cẩn thận, không copy thừa dấu cách ở đầu hoặc cuối.

## Nếu Đã Có Sẵn Kênh Thanh Toán

1. Đăng nhập payOS: [https://my.payos.vn](https://my.payos.vn)
2. Vào **Kênh thanh toán**.
3. Chọn kênh thanh toán đang dùng.
4. Tìm phần **Tích hợp**, **Thông tin tích hợp**, **API key** hoặc tên tương tự.
5. Copy 3 giá trị: **Client ID**, **API Key**, **Checksum Key**.

Tên menu có thể thay đổi nhẹ theo giao diện payOS, nhưng 3 tên key cần lấy vẫn là **Client ID**, **API Key**, **Checksum Key**.

## Dán Key Vào Altivox AI

1. Đăng nhập Altivox AI.
2. Vào màn hình cấu hình bot/shop.
3. Tìm khu vực PayOS.
4. Dán theo đúng mapping:

| Trong Altivox AI   | Trên payOS  |
| ------------------ | ------------ |
| PayOS Client ID    | Client ID    |
| PayOS API Key      | API Key      |
| PayOS Checksum Key | Checksum Key |

5. Bấm lưu cấu hình.
6. Tạo thử một đơn thanh toán nhỏ để kiểm tra.

## Webhook PayOS

Nếu payOS yêu cầu cấu hình Webhook URL cho kênh thanh toán, nhập URL này:

```text
https://api.altivoxai.com/api/v1/webhooks/payos
```

Webhook này dùng để payOS báo về server khi đơn hàng thanh toán thành công.

## Checklist Trước Khi Test Thanh Toán

- [ ] Đã tạo kênh thanh toán trên payOS.
- [ ] Đã copy đúng Client ID.
- [ ] Đã copy đúng API Key.
- [ ] Đã copy đúng Checksum Key.
- [ ] Đã dán 3 key vào Altivox AI đúng ô.
- [ ] Đã lưu cấu hình bot/shop.
- [ ] Nếu payOS yêu cầu, đã cấu hình Webhook URL: `https://api.altivoxai.com/api/v1/webhooks/payos`
- [ ] Đã test tạo đơn thanh toán.

## Lỗi Thường Gặp

**"PayOS configuration is incomplete"**
Thiếu 1 trong 3 key: Client ID, API Key, Checksum Key.

**"Unauthorized" hoặc lỗi xác thực payOS**
Client ID/API Key sai, copy thừa khoảng trắng, hoặc key không thuộc kênh thanh toán đó.

**Thanh toán xong nhưng đơn không cập nhật**
Chưa cấu hình webhook, webhook URL sai, hoặc Checksum Key sai.

**Lỗi "signature không hợp lệ"**
Checksum Key sai hoặc không đúng với kênh thanh toán đã tạo link.

## Nguồn Tham Khảo Chính Thức

- [Tạo kênh thanh toán payOS](https://payos.vn/docs/huong-dan-su-dung/tao-kenh-thanh-toan/)
- [API payOS](https://payos.vn/docs/api/)
- [NodeJS SDK payOS](https://payos.vn/docs/sdks/back-end/node/)
- [Kiểm tra dữ liệu với signature](https://payos.vn/docs/tich-hop-webhook/kiem-tra-du-lieu-voi-signature/)
