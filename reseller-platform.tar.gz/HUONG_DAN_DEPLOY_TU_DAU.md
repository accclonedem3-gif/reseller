# Huong Dan Deploy Reseller Platform Tu Dau

File nay danh cho lan deploy dau tien len VPS. He thong gom:

- Web dashboard React.
- API NestJS.
- Worker Telegram bot.
- PostgreSQL.
- Redis.
- Nginx reverse proxy.
- PM2 de chay API va worker.

## 1. Chuan Bi Truoc Khi Lam

Can co:

- VPS Ubuntu 22.04 hoac 24.04 LTS.
- Cau hinh toi thieu nen dung: 2 vCPU, 4GB RAM, 60GB SSD/NVMe.
- Domain rieng.
- 2 subdomain:
  - `app.tenmien.com` cho web dashboard.
  - `api.tenmien.com` cho API.

Tao DNS record:

```text
app.tenmien.com  A  IP_VPS
api.tenmien.com  A  IP_VPS
```

Thay `tenmien.com` va `IP_VPS` bang thong tin that.

## 2. Tao User Rieng Tren VPS

Dang nhap VPS bang root lan dau, sau do chay:

```bash
adduser deploy
usermod -aG sudo deploy
```

Sau do dang xuat root va dang nhap lai bang user `deploy`.

Khong nen chay app bang user `root`.

## 3. Cai Phan Mem Can Thiet

```bash
sudo apt update
sudo apt install -y git nginx docker.io docker-compose-plugin
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm i -g pm2 pm2-logrotate
```

Kiem tra:

```bash
node -v
npm -v
docker --version
docker compose version
pm2 -v
```

## 4. Bat Firewall

Chi mo SSH, HTTP va HTTPS:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
sudo ufw status
```

Khong mo cac port nay ra internet:

```text
3000
5432
6379
```

Trong project, Docker da bind PostgreSQL va Redis ve `127.0.0.1`, nhung firewall van nen dong port ngoai.

## 5. Upload Code Len VPS

Tao thu muc:

```bash
sudo mkdir -p /opt/reseller-platform
sudo chown -R deploy:deploy /opt/reseller-platform
cd /opt/reseller-platform
```

Neu dung Git:

```bash
git clone LINK_REPO .
```

Neu khong dung Git, upload toan bo thu muc source len:

```text
/opt/reseller-platform
```

Khong upload `node_modules` neu khong can.

## 6. Tao File .env Production

Trong thu muc project:

```bash
cd /opt/reseller-platform
cp deploy/production.env.example .env
nano .env
```

Nhung bien bat buoc phai sua:

```env
NODE_ENV=production

DATABASE_URL=postgresql://postgres:MAT_KHAU_DB@localhost:5432/reseller_platform?schema=public
POSTGRES_USER=postgres
POSTGRES_PASSWORD=MAT_KHAU_DB
POSTGRES_DB=reseller_platform
REDIS_URL=redis://localhost:6379

JWT_ACCESS_SECRET=CHUOI_RANDOM_DAI
JWT_REFRESH_SECRET=CHUOI_RANDOM_DAI
APP_ENCRYPTION_KEY=CHUOI_RANDOM_DAI
INTERNAL_API_TOKEN=CHUOI_RANDOM_DAI

APP_PUBLIC_URL=https://api.tenmien.com
WEB_PUBLIC_URL=https://app.tenmien.com
CORS_ORIGIN=https://app.tenmien.com
PUBLIC_UPLOAD_BASE_URL=https://api.tenmien.com/uploads

PAYMENT_MODE=payos
MOCK_PROVIDER_ENABLED=false
MOCK_TELEGRAM_MODE=false
```

Tao chuoi random:

```bash
openssl rand -hex 32
```

Chay lenh tren 4 lan de lay 4 chuoi khac nhau cho:

- `JWT_ACCESS_SECRET`
- `JWT_REFRESH_SECRET`
- `APP_ENCRYPTION_KEY`
- `INTERNAL_API_TOKEN`

Rat quan trong:

- Khong doi `APP_ENCRYPTION_KEY` sau khi da co du lieu that.
- Neu doi `APP_ENCRYPTION_KEY`, cac key bot, buyer key, PayOS key da ma hoa trong DB co the khong giai ma duoc.
- Khong dua file `.env` len Git public.

## 7. PayOS Va Thanh Toan

Neu muon moi CTV tu cau hinh PayOS rieng tren web thi co the de trong:

```env
PAYOS_CLIENT_ID=
PAYOS_API_KEY=
PAYOS_CHECKSUM_KEY=
```

Khi do CTV phai vao dashboard de nhap PayOS cua rieng ho.

Neu muon co PayOS mac dinh cua he thong thi dien:

```env
PAYOS_CLIENT_ID=...
PAYOS_API_KEY=...
PAYOS_CHECKSUM_KEY=...
```

Khuyen nghi:

- Neu tien cua CTV nao ve CTV do, hay bat CTV nhap PayOS rieng.
- Khong nen dung PayOS admin lam fallback neu so tien can tach rieng theo tung CTV.

## 8. Email Reset Mat Khau

Neu muon gui email reset mat khau that, cau hinh:

```env
RESEND_API_KEY=...
MAIL_FROM=Reseller Platform <no-reply@tenmien.com>
PASSWORD_RESET_TTL_MINUTES=30
```

Neu chua cau hinh `RESEND_API_KEY`, local/dev se hien link reset test, nhung production nen cau hinh email that.

## 9. Chay PostgreSQL Va Redis

```bash
docker compose up -d
docker compose ps
```

Kiem tra container phai co:

```text
reseller-platform-postgres
reseller-platform-redis
```

## 10. Cai Dependency, Migrate DB, Build

```bash
npm ci
npm run db:generate
npm run db:deploy
npm run build
```

Neu build pass la code san sang chay.

## 11. Chay API Va Worker Bang PM2

```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 status
```

Xem log:

```bash
pm2 logs reseller-api
pm2 logs reseller-worker
```

Luu y:

- `reseller-api` co the chay 1 instance ban dau.
- `reseller-worker` chi nen chay 1 instance de tranh conflict Telegram polling.

## 12. Cau Hinh Nginx

Copy file cau hinh:

```bash
sudo cp deploy/nginx.reseller-platform.conf /etc/nginx/sites-available/reseller-platform
sudo nano /etc/nginx/sites-available/reseller-platform
```

Doi:

```text
app.example.com -> app.tenmien.com
api.example.com -> api.tenmien.com
```

Kich hoat site:

```bash
sudo ln -s /etc/nginx/sites-available/reseller-platform /etc/nginx/sites-enabled/reseller-platform
sudo nginx -t
sudo systemctl reload nginx
```

Neu `nginx -t` bao loi duplicate/default, co the tat default site:

```bash
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

## 13. Bat SSL HTTPS

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d app.tenmien.com -d api.tenmien.com
```

Sau khi xong, mo thu:

```text
https://app.tenmien.com
https://api.tenmien.com/api/v1
```

## 14. Bao Mat SSH

Nen dung SSH key.

Tren may ca nhan:

```bash
ssh-keygen -t ed25519 -C "deploy-reseller"
ssh-copy-id deploy@IP_VPS
```

Sau khi test dang nhap bang key OK, tren VPS sua:

```bash
sudo nano /etc/ssh/sshd_config
```

Dat:

```text
PasswordAuthentication no
PermitRootLogin no
PubkeyAuthentication yes
```

Restart SSH:

```bash
sudo systemctl restart ssh
```

Quan trong:

- Mo them mot terminal SSH moi de test truoc khi dong terminal cu.
- Neu cau hinh sai va dong terminal cu, co the bi khoa ngoai VPS.

## 15. Cai Fail2ban

```bash
sudo apt install -y fail2ban
sudo systemctl enable --now fail2ban
sudo fail2ban-client status
```

## 16. Log Rotate Cho PM2

```bash
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 20M
pm2 set pm2-logrotate:retain 14
pm2 save
```

Muc dich: tranh log day o cung.

## 17. Backup Database Hang Ngay

Tao thu muc:

```bash
mkdir -p ~/backups/reseller-platform
```

Test backup:

```bash
docker exec reseller-platform-postgres pg_dump -U postgres reseller_platform > ~/backups/reseller-platform/db-$(date +%F).sql
```

Them cron:

```bash
crontab -e
```

Them dong:

```cron
0 3 * * * docker exec reseller-platform-postgres pg_dump -U postgres reseller_platform > /home/deploy/backups/reseller-platform/db-$(date +\%F).sql
```

Nen lam them:

- Dong bo backup ra Google Drive, S3, Cloudflare R2 hoac mot VPS khac.
- Khong nen chi de backup trong cung VPS.

## 18. Test Sau Khi Deploy

Mo web:

```text
https://app.tenmien.com
```

Checklist test:

- Dang nhap admin.
- Tao tai khoan CTV.
- Dang nhap CTV.
- CTV cau hinh Telegram bot token.
- CTV cau hinh buyer key Canboso.
- CTV cau hinh PayOS rieng neu can thanh toan that.
- Verify Telegram.
- Verify nguon.
- Sync san pham.
- Vao bot Telegram bam `/start`.
- Xem san pham.
- Tao don.
- Thanh toan PayOS test.
- Kiem tra bot giao tai khoan.
- Kiem tra don tren dashboard.
- Kiem tra log API va worker.

Lenh xem log:

```bash
pm2 logs reseller-api
pm2 logs reseller-worker
```

## 19. Khi Update Code Sau Nay

Neu dung Git:

```bash
cd /opt/reseller-platform
git pull
npm ci
npm run db:deploy
npm run build
pm2 restart ecosystem.config.cjs
sudo systemctl reload nginx
```

Neu khong dung Git:

1. Upload code moi de len `/opt/reseller-platform`.
2. Chay:

```bash
cd /opt/reseller-platform
npm ci
npm run db:deploy
npm run build
pm2 restart ecosystem.config.cjs
sudo systemctl reload nginx
```

## 20. Checklist Bao Mat Cuoi

Truoc khi public:

- `NODE_ENV=production`.
- `MOCK_PROVIDER_ENABLED=false`.
- `MOCK_TELEGRAM_MODE=false`.
- Da doi tat ca secret default.
- `APP_PUBLIC_URL`, `WEB_PUBLIC_URL`, `CORS_ORIGIN` dung domain that.
- Da bat HTTPS.
- Firewall chi mo 22, 80, 443.
- DB/Redis khong public internet.
- Da tat SSH root login.
- Da tat SSH password login neu SSH key da OK.
- Da cai fail2ban.
- Da cai pm2-logrotate.
- Da co backup database hang ngay.
- Admin password khong dung mat khau yeu/mac dinh.
- Khong gui file `.env` cho nguoi khong lien quan.

## 21. Lenh Kiem Tra Nhanh

```bash
pm2 status
docker compose ps
sudo ufw status
sudo nginx -t
systemctl status nginx
df -h
free -m
```

Kiem tra API:

```bash
curl https://api.tenmien.com/api/v1
```

Kiem tra web:

```bash
curl -I https://app.tenmien.com
```

## 22. Ghi Chu Quan Trong

- `APP_ENCRYPTION_KEY` la khoa de ma hoa/giai ma bot token, buyer key, PayOS key. Hay backup ky.
- PostgreSQL la du lieu quan trong nhat. Mat DB la mat don hang, CTV, san pham, cau hinh.
- Worker phai chay thi bot Telegram, sync, giao hang tu dong moi hoat dong.
- API phai chay thi dashboard, webhook PayOS, webhook Telegram moi hoat dong.
- Web build nam o `apps/web/dist`, Nginx serve folder nay.

