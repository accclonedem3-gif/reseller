import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  PropsWithChildren,
  ReactNode,
  TextareaHTMLAttributes,
} from "react";
import { ArrowUpRight, type LucideIcon } from "lucide-react";

import { cn } from "@/lib/cn";
import { InfoHint } from "@/components/ui/info-hint";

export function StudioCard({
  children,
  className,
}: PropsWithChildren<{ className?: string }>) {
  return (
    <div
      className={cn(
        "rounded-[20px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,26,46,0.92),rgba(30,42,71,0.92))] p-5 shadow-[0_18px_42px_rgba(0,0,0,0.34)] sm:p-6",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function StudioBadge({
  children,
  tone = "neutral",
}: PropsWithChildren<{ tone?: "neutral" | "success" | "warning" | "danger" }>) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-[10px] border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.16em]",
        tone === "success" && "border-emerald-400/20 bg-emerald-500/10 text-emerald-100",
        tone === "warning" && "border-emerald-300/20 bg-emerald-400/10 text-emerald-100",
        tone === "danger" && "border-rose-400/18 bg-rose-500/10 text-rose-200",
        tone === "neutral" && "border-white/10 bg-[#18233c] text-slate-200",
      )}
    >
      {children}
    </span>
  );
}

export function StudioButton({
  children,
  className,
  variant = "primary",
  size = "md",
  type,
  ...props
}: PropsWithChildren<
  ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "ghost" | "danger";
    size?: "sm" | "md" | "lg";
  }
>) {
  return (
    <button
      type={type ?? "button"}
      className={cn(
        "inline-flex transform-gpu items-center justify-center gap-2 rounded-[12px] border font-semibold transition-[transform,background-color,border-color,box-shadow,color,opacity] duration-300 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A0F1C] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-55",
        size === "sm" && "px-3.5 py-2.5 text-sm",
        size === "md" && "px-4 py-3 text-sm",
        size === "lg" && "px-5 py-3.5 text-[0.95rem]",
        variant === "primary" &&
          "border-emerald-300/24 bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e] shadow-[0_12px_28px_rgba(16,185,129,0.22)] hover:-translate-y-px hover:brightness-110",
        variant === "secondary" &&
          "border-white/10 bg-[#18233c] text-slate-100 hover:-translate-y-px hover:border-emerald-300/18 hover:bg-[#1E2A47]",
        variant === "ghost" &&
          "border-transparent bg-transparent text-slate-300 hover:bg-[#18233c] hover:text-white",
        variant === "danger" &&
          "border-rose-300/20 bg-rose-500/12 text-rose-100 hover:-translate-y-px hover:border-rose-200/30 hover:bg-rose-500/18",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function StudioInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "w-full rounded-[12px] border border-white/10 bg-[#121A2E] px-4 py-3.5 text-sm font-medium text-white outline-none transition duration-200 placeholder:text-slate-500 focus:border-emerald-300/45 focus:bg-[#1E2A47] focus:shadow-[0_0_0_3px_rgba(16,185,129,0.16)]",
        props.className,
      )}
    />
  );
}

export function StudioTextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-[132px] w-full rounded-[12px] border border-white/10 bg-[#121A2E] px-4 py-3.5 text-sm font-medium text-white outline-none transition duration-200 placeholder:text-slate-500 focus:border-emerald-300/45 focus:bg-[#1E2A47] focus:shadow-[0_0_0_3px_rgba(16,185,129,0.16)]",
        props.className,
      )}
    />
  );
}

export function StudioSectionIntro({
  kicker,
  title,
  description,
  actions,
  titleClassName,
  descriptionClassName,
}: {
  kicker: string;
  title: string;
  description: string;
  actions?: ReactNode;
  titleClassName?: string;
  descriptionClassName?: string;
}) {
  return (
    <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
      <div className={cn("max-w-3xl", titleClassName || descriptionClassName ? "max-w-none" : "")}>
        <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-500">
          {kicker}
        </p>
        <div className="mt-3 flex max-w-full items-start gap-2">
          <h1
            className={cn(
              "max-w-[calc(100%-2rem)] text-balance text-3xl font-semibold tracking-tight text-white sm:text-[2.25rem]",
              titleClassName,
            )}
          >
            {title}
          </h1>
          <InfoHint
            content={description}
            className="shrink-0"
            panelClassName="max-w-xl"
            label={`Xem ghi chú cho ${title}`}
          />
        </div>
      </div>
      {actions ? <div className="flex flex-wrap gap-3">{actions}</div> : null}
    </div>
  );
}

export function StudioMetric({
  label,
  value,
  description,
  icon: Icon = ArrowUpRight,
  tone = "sky",
}: {
  label: string;
  value: string;
  description: string;
  icon?: LucideIcon;
  tone?: "sky" | "amber" | "emerald" | "violet";
}) {
  return (
    <StudioCard className="h-full">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
              {label}
            </p>
            <InfoHint
              content={description}
              className="shrink-0"
              panelClassName="max-w-[260px]"
              label={`Xem ghi chú cho ${label}`}
            />
          </div>
          <p className="text-3xl font-semibold tracking-tight text-white sm:text-[2rem]">
            {value}
          </p>
        </div>
        <div
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-[12px] border border-white/8 bg-[#121A2E]",
            tone === "sky" && "text-emerald-200",
            tone === "amber" && "text-emerald-300",
            tone === "emerald" && "text-emerald-200",
            tone === "violet" && "text-emerald-100",
          )}
        >
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </StudioCard>
  );
}
