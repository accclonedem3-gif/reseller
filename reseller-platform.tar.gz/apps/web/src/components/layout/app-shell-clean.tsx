import type { ReactNode } from "react";
import {
  Bell,
  Bot,
  ChartColumn,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Package,
  ShoppingBag,
  UserCircle2,
  Users,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { formatRoleLabel } from "@/lib/format";

const workspaceItems = [
  {
    to: "/",
    label: "Tong quan",
    description: "Theo doi doanh thu, vi va suc khoe van hanh.",
    icon: LayoutDashboard,
  },
  {
    to: "/bot-config",
    label: "Cau hinh bot",
    description: "Quan ly Telegram, provider va thanh toan.",
    icon: Bot,
  },
  {
    to: "/products",
    label: "San pham",
    description: "Cap nhat ten hien thi, gia ban va trang thai.",
    icon: Package,
  },
  {
    to: "/orders/pending",
    label: "Don cho xu ly",
    description: "Xu ly cac don dang wait stock hoac can theo doi.",
    icon: ShoppingBag,
  },
  {
    to: "/orders",
    label: "Don hang",
    description: "Xem toan bo lich su va trang thai xu ly don.",
    icon: ShoppingBag,
  },
  {
    to: "/wallet",
    label: "Vi seller",
    description: "Nop rut va xem ledger giao dich noi bo.",
    icon: CreditCard,
  },
] as const;

const insightItems = [
  {
    to: "/reports/top-buyers",
    label: "Top buyers",
    description: "Nhan dien nhom khach hang gia tri cao.",
    icon: Users,
  },
  {
    to: "/reports/top-referrers",
    label: "Top referrers",
    description: "Theo doi dong gioi thieu va kha nang mo rong.",
    icon: Users,
  },
  {
    to: "/reports/revenue",
    label: "Doanh thu",
    description: "Tong hop nhiep doanh thu va bien loi nhuan.",
    icon: ChartColumn,
  },
  {
    to: "/broadcasts",
    label: "Broadcast",
    description: "Gui thong bao bot va theo doi chien dich.",
    icon: Bell,
  },
  {
    to: "/profile",
    label: "Ho so",
    description: "Thong tin tai khoan seller hien tai.",
    icon: UserCircle2,
  },
] as const;

const navSections = [
  { title: "Workspace", items: workspaceItems },
  { title: "Insights", items: insightItems },
] as const;

const flatNavigation = [...workspaceItems, ...insightItems];

function NavigationSection({
  title,
  items,
}: {
  title: string;
  items: typeof workspaceItems | typeof insightItems;
}) {
  return (
    <div className="space-y-2">
      <p className="px-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-500">
        {title}
      </p>
      <div className="space-y-1.5">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                "group flex items-center gap-3 rounded-[18px] border px-3 py-2.5 transition",
                isActive
                  ? "border-slate-700 bg-slate-800/80 text-white shadow-[0_12px_30px_rgba(15,23,42,0.22)]"
                  : "border-transparent bg-transparent text-slate-300 hover:border-slate-800 hover:bg-slate-900/60 hover:text-white",
              )
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-[14px] border border-slate-800 bg-slate-900 text-slate-400 transition",
                    isActive && "border-slate-600 bg-slate-100 text-slate-900",
                  )}
                >
                  <item.icon className="h-4.5 w-4.5" />
                </span>
                <span className="min-w-0 flex-1 text-sm font-semibold">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();
  const location = useLocation();
  const fallbackSection = flatNavigation[0]!;
  const currentSection =
    flatNavigation.find((item) =>
      item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to),
    ) || fallbackSection;
  const displayName = session?.user.displayName || session?.user.email || "Seller";

  return (
    <div className="min-h-screen bg-[#0b1220] text-slate-100">
      <div className="mx-auto flex max-w-[1560px] gap-6 px-4 py-4 lg:px-6">
        <aside className="hidden w-[280px] shrink-0 flex-col rounded-[24px] border border-white/8 bg-[#0f1728] p-4 shadow-[0_30px_70px_rgba(2,6,23,0.34)] lg:flex">
          <div className="border-b border-white/8 px-2 pb-5">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-slate-700 bg-slate-950 text-white">
                <LayoutDashboard className="h-5 w-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Seller dashboard
                </p>
                <h1 className="mt-1 text-lg font-semibold text-white">Reseller Platform</h1>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-6 overflow-y-auto px-1 py-5">
            {navSections.map((section) => (
              <NavigationSection key={section.title} title={section.title} items={section.items} />
            ))}
          </div>

          <div className="rounded-[20px] border border-white/8 bg-slate-950/40 p-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
              Active session
            </p>
            <p className="mt-3 text-base font-semibold text-white">{displayName}</p>
            <p className="mt-1 text-sm text-slate-400">{session?.user.email}</p>
            <div className="mt-4 flex items-center justify-between gap-3 rounded-[16px] border border-white/8 bg-white/[0.03] px-3 py-2.5">
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-slate-500">Role</p>
                <p className="mt-1 text-sm font-medium text-slate-100">
                  {formatRoleLabel(session?.user.role)}
                </p>
              </div>
              <Button size="sm" variant="secondary" onClick={logout}>
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-5">
          <div className="rounded-[22px] border border-white/8 bg-[#10192b] px-4 py-4 shadow-[0_24px_60px_rgba(2,6,23,0.26)] lg:hidden">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Seller dashboard
                </p>
                <h1 className="mt-1 text-lg font-semibold text-white">Reseller Platform</h1>
              </div>
              <Button size="sm" variant="secondary" onClick={logout}>
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
            <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
              {flatNavigation.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm transition",
                      isActive
                        ? "border-slate-500 bg-slate-100 text-slate-950"
                        : "border-slate-800 bg-slate-950/50 text-slate-300",
                    )
                  }
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
            </div>
          </div>

          <header className="rounded-[24px] border border-white/8 bg-[#10192b] px-5 py-5 shadow-[0_24px_60px_rgba(2,6,23,0.24)]">
            <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
              <div className="max-w-3xl">
                <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-slate-500">
                  Operations
                </p>
                <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white sm:text-[2.2rem]">
                  {currentSection.label}
                </h2>
                <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-400">
                  {currentSection.description}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <span className="inline-flex items-center rounded-full border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-300">
                  Environment: Local
                </span>
                <span className="inline-flex items-center rounded-full border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-300">
                  User: {displayName}
                </span>
                <span className="inline-flex items-center rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
                  System ready
                </span>
              </div>
            </div>
          </header>

          <div>{children}</div>
        </main>
      </div>
    </div>
  );
}
