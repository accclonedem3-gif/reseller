import type { ReactNode } from "react";
import {
  Bell,
  Bot,
  ChartColumn,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Package,
  ShieldPlus,
  ShoppingBag,
  UserCircle2,
  Users,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { StudioButton } from "@/components/studio/studio-ui";
import { cn } from "@/lib/cn";
import { formatRoleLabel } from "@/lib/format";

type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
};

const sellerItems: readonly NavItem[] = [
  { to: "/", label: "Tổng quan", icon: LayoutDashboard },
  { to: "/bot-config", label: "Cấu hình bot", icon: Bot },
  { to: "/products", label: "Sản phẩm", icon: Package },
  { to: "/orders/pending", label: "Đơn chờ xử lý", icon: ShoppingBag },
  { to: "/orders", label: "Đơn hàng", icon: ShoppingBag },
  { to: "/wallet", label: "Ví seller", icon: CreditCard },
  { to: "/reports/top-buyers", label: "Top người mua", icon: Users },
  { to: "/reports/top-referrers", label: "Top giới thiệu", icon: Users },
  { to: "/reports/revenue", label: "Doanh thu", icon: ChartColumn },
  { to: "/broadcasts", label: "Thông báo bot", icon: Bell },
  { to: "/profile", label: "Hồ sơ", icon: UserCircle2 },
] as const;

const adminItems: readonly NavItem[] = [
  { to: "/admin/ctv", label: "Tài khoản CTV", icon: ShieldPlus },
] as const;

function isItemActive(pathname: string, itemPath: string) {
  return itemPath === "/"
    ? pathname === "/"
    : pathname === itemPath || pathname.startsWith(`${itemPath}/`);
}

function SidebarSection({ title, items }: { title: string; items: readonly NavItem[] }) {
  return (
    <section className="space-y-2.5">
      <p className="px-1 text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
        {title}
      </p>
      <div className="space-y-1.5">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                "group flex items-center gap-3 rounded-[14px] border px-3 py-2.5 transition",
                isActive
                  ? "border-emerald-300/24 bg-[#1e2a47] text-white shadow-[0_10px_24px_rgba(16,185,129,0.10)]"
                  : "border-transparent text-slate-400 hover:border-emerald-300/14 hover:bg-[#18233c] hover:text-white",
              )
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-[11px] border transition",
                    isActive
                      ? "border-emerald-300/26 bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e]"
                      : "border-white/8 bg-[#121a2e] text-slate-300",
                  )}
                >
                  <item.icon className="h-4.5 w-4.5" />
                </span>
                <span className="min-w-0 text-sm font-semibold">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </section>
  );
}

export function AppShellPrime({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();
  const location = useLocation();
  const isSuperAdmin = session?.user.role === "super_admin";
  const displayName =
    session?.user.displayName ||
    (isSuperAdmin ? "Quản trị viên" : session?.user.email) ||
    "Seller";

  const currentItems = isSuperAdmin ? adminItems : sellerItems;
  const navGroups = isSuperAdmin
    ? [{ title: "Quản trị", items: adminItems }]
    : [
        { title: "Vận hành", items: sellerItems.slice(0, 6) },
        { title: "Phân tích", items: sellerItems.slice(6) },
      ];

  const currentLabel =
    currentItems.find((item) => isItemActive(location.pathname, item.to))?.label || "Bảng điều khiển";

  return (
    <div className="dashboard-shell min-h-screen bg-transparent text-white">
      <div className="mx-auto flex max-w-[1820px] gap-6 px-4 py-5 lg:px-6 xl:py-6">
        <aside className="shell-sidebar hidden w-[262px] shrink-0 xl:flex">
          <div className="sticky top-6 flex h-[calc(100vh-3rem)] w-full flex-col rounded-[24px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,26,46,0.98),rgba(30,42,71,0.98))] p-5 shadow-[0_24px_56px_rgba(0,0,0,0.38)]">
            <div className="border-b border-white/8 pb-5">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-[14px] border border-emerald-300/24 bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e]">
                  <LayoutDashboard className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <p className="hidden">
                    Altivox AI
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span className="truncate text-lg font-black uppercase tracking-tight text-white">
                      Altivox
                    </span>
                    <span className="rounded-[6px] bg-[linear-gradient(135deg,#34D399,#10B981)] px-2 py-0.5 text-sm font-black uppercase tracking-tight text-[#07131e]">
                      AI
                    </span>
                  </div>
                </div>
              </div>
              <p className="hidden">
                Quản lý shop, sản phẩm, đơn hàng và ví nguồn trên cùng một giao diện gọn và rõ.
              </p>
            </div>

            <div className="flex-1 space-y-7 overflow-y-auto py-6">
              {navGroups.map((group) => (
                <SidebarSection key={group.title} title={group.title} items={group.items} />
              ))}
            </div>

            <div className="border-t border-white/8 pt-4">
              <div className="rounded-[16px] border border-white/8 bg-[#18233c] p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Phiên hiện tại
                </p>
                <p className="mt-3 text-base font-semibold text-white">{displayName}</p>
                <p className="mt-1 text-sm text-slate-400">{session?.user.email}</p>
                <div className="mt-4 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.22em] text-slate-500">Vai trò</p>
                    <p className="mt-1 text-sm font-semibold text-white">
                      {formatRoleLabel(session?.user.role)}
                    </p>
                  </div>
                  <StudioButton size="sm" variant="secondary" onClick={logout} type="button">
                    <LogOut className="h-4 w-4" />
                    Đăng xuất
                  </StudioButton>
                </div>
              </div>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1">
          <div className="shell-topbar hidden items-center justify-between rounded-[20px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,26,46,0.96),rgba(30,42,71,0.96))] px-5 py-4 shadow-[0_16px_34px_rgba(0,0,0,0.24)] xl:flex">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                Không gian làm việc
              </p>
              <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white">{currentLabel}</h1>
            </div>
            <div className="flex items-center gap-3">
              <div className="rounded-full border border-white/10 bg-[#18233c] px-3 py-2 text-sm text-slate-300">
                {displayName}
              </div>
              <div className="rounded-full border border-emerald-300/18 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-100">
                {formatRoleLabel(session?.user.role)}
              </div>
            </div>
          </div>

          <div className="shell-mobilebar rounded-[18px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,26,46,0.96),rgba(30,42,71,0.96))] px-4 py-3 shadow-[0_18px_36px_rgba(0,0,0,0.28)] xl:hidden">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Điều hướng nhanh
                </p>
                <p className="mt-1 text-sm font-semibold text-white">{displayName}</p>
              </div>
              <StudioButton size="sm" variant="secondary" onClick={logout} type="button">
                <LogOut className="h-4 w-4" />
                Đăng xuất
              </StudioButton>
            </div>

            <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
              {currentItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-[10px] border px-3 py-2 text-sm font-medium transition",
                    isItemActive(location.pathname, item.to)
                      ? "border-emerald-300/24 bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e]"
                      : "border-white/8 bg-[#18233c] text-slate-300",
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
            </div>
          </div>

          <div key={location.pathname} className="page-stage space-y-6 pt-0 xl:pt-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
