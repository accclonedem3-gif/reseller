import type { ReactNode } from "react";
import {
  Bell,
  Bot,
  ChartColumn,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Package,
  ShoppingBag,
  UserCircle2,
  Users,
} from "lucide-react";
import { NavLink } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { cn } from "@/lib/cn";

const navigation = [
  { to: "/", label: "Tổng quan", icon: LayoutDashboard },
  { to: "/bot-config", label: "Cấu hình bot", icon: Bot },
  { to: "/products", label: "Sản phẩm", icon: Package },
  { to: "/orders/pending", label: "Đơn chờ xử lý", icon: ShoppingBag },
  { to: "/orders", label: "Đơn hàng", icon: ShoppingBag },
  { to: "/wallet", label: "Nạp rút ví", icon: CreditCard },
  { to: "/reports/top-buyers", label: "Top người mua", icon: Users },
  { to: "/reports/top-referrers", label: "Top giới thiệu", icon: Users },
  { to: "/reports/revenue", label: "Doanh thu", icon: ChartColumn },
  { to: "/broadcasts", label: "Thông báo bot", icon: Bell },
  { to: "/profile", label: "Hồ sơ", icon: UserCircle2 },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex max-w-[1600px] gap-6 px-4 py-4 lg:px-6">
        <aside className="sticky top-4 hidden h-[calc(100vh-2rem)] w-72 shrink-0 flex-col justify-between rounded-[32px] border border-white/10 bg-[#07111f] p-5 shadow-panel lg:flex">
          <div className="space-y-6">
            <div>
              <p className="font-display text-2xl font-bold tracking-tight">Reseller Bot</p>
              <p className="mt-2 text-sm text-slate-400">
                Bảng điều khiển tối màu cho seller vận hành bot bán hàng Telegram.
              </p>
            </div>
            <nav className="space-y-2">
              {navigation.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-3 rounded-2xl px-4 py-3 text-sm text-slate-300 transition hover:bg-white/5 hover:text-white",
                      isActive && "bg-white text-slate-950 shadow-lg",
                    )
                  }
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
            <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Đang đăng nhập bằng</p>
            <p className="mt-2 font-semibold text-white">
              {session?.user.displayName || session?.user.email}
            </p>
            <button
              onClick={logout}
              className="mt-4 inline-flex items-center gap-2 text-sm text-slate-300 transition hover:text-white"
            >
              <LogOut className="h-4 w-4" />
              Đăng xuất
            </button>
          </div>
        </aside>
        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  );
}
