import type { ReactNode } from "react";
import {
  Bell,
  Bot,
  ChartColumn,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Package,
  ShoppingBag,
  UserCircle2,
  Users,
} from "lucide-react";
import { NavLink } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { cn } from "@/lib/cn";
import { formatRoleLabel } from "@/lib/format";

const workspaceItems = [
  { to: "/", label: "Tổng quan", icon: LayoutDashboard },
  { to: "/bot-config", label: "Cấu hình bot", icon: Bot },
  { to: "/products", label: "Sản phẩm", icon: Package },
  { to: "/orders/pending", label: "Đơn chờ xử lý", icon: ShoppingBag },
  { to: "/orders", label: "Đơn hàng", icon: ShoppingBag },
  { to: "/wallet", label: "Ví seller", icon: CreditCard },
] as const;

const analyticsItems = [
  { to: "/reports/top-buyers", label: "Top người mua", icon: Users },
  { to: "/reports/top-referrers", label: "Top giới thiệu", icon: Users },
  { to: "/reports/revenue", label: "Doanh thu", icon: ChartColumn },
  { to: "/broadcasts", label: "Thông báo bot", icon: Bell },
  { to: "/profile", label: "Hồ sơ", icon: UserCircle2 },
] as const;

const mobileItems = [...workspaceItems, ...analyticsItems];

function NavSection({
  title,
  items,
}: {
  title: string;
  items: readonly { to: string; label: string; icon: typeof LayoutDashboard }[];
}) {
  return (
    <div className="space-y-2">
      <p className="px-3 text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-400">
        {title}
      </p>
      <div className="space-y-1.5">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                "group flex items-center gap-3 rounded-2xl border px-3 py-3 transition",
                isActive
                  ? "border-slate-900 bg-slate-900 text-white shadow-[0_16px_32px_rgba(15,23,42,0.14)]"
                  : "border-transparent bg-transparent text-slate-600 hover:border-slate-200 hover:bg-slate-50 hover:text-slate-950",
              )
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-[14px] border transition",
                    isActive
                      ? "border-white/10 bg-white/10 text-white"
                      : "border-slate-200 bg-white text-slate-500",
                  )}
                >
                  <item.icon className="h-4.5 w-4.5" />
                </span>
                <span className="text-sm font-semibold">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();
  const displayName = session?.user.displayName || session?.user.email || "Seller";

  return (
    <div className="min-h-screen bg-[#f3f6fb] text-slate-900">
      <div className="mx-auto flex max-w-[1680px] gap-6 px-4 py-4 lg:px-6">
        <aside className="hidden w-[280px] shrink-0 flex-col rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_24px_50px_rgba(15,23,42,0.06)] xl:flex">
          <div className="border-b border-slate-200 pb-5">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-900 text-white">
                <LayoutDashboard className="h-5 w-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-400">
                  Không gian seller
                </p>
                <h1 className="mt-1 text-lg font-semibold text-slate-950">
                  Reseller Platform
                </h1>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-6 overflow-y-auto py-6">
            <NavSection title="Vận hành" items={workspaceItems} />
            <NavSection title="Phân tích" items={analyticsItems} />
          </div>

          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-400">
              Phiên hiện tại
            </p>
            <p className="mt-3 text-base font-semibold text-slate-950">{displayName}</p>
            <p className="mt-1 text-sm text-slate-500">{session?.user.email}</p>
            <div className="mt-4 flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-3 py-2.5">
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">Vai trò</p>
                <p className="mt-1 text-sm font-semibold text-slate-900">
                  {formatRoleLabel(session?.user.role)}
                </p>
              </div>
              <button
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-100 hover:text-slate-950"
                onClick={logout}
                type="button"
              >
                <LogOut className="h-4 w-4" />
                Đăng xuất
              </button>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-6">
          <div className="rounded-[28px] border border-slate-200 bg-white px-5 py-4 shadow-[0_20px_45px_rgba(15,23,42,0.05)]">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-400">
                  Không gian seller
                </p>
                <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
                  Trung tâm vận hành
                </h2>
                <p className="mt-2 text-sm text-slate-500">
                  Quản lý catalog, đơn hàng, ví nội bộ và các chiến dịch broadcast từ một
                  bảng điều khiển tập trung.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-600">
                  Môi trường: Local
                </span>
                <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-600">
                  Người dùng: {displayName}
                </span>
                <span className="inline-flex items-center rounded-full border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700">
                  Hệ thống sẵn sàng
                </span>
              </div>
            </div>
          </div>

          <div className="rounded-[28px] border border-slate-200 bg-white px-4 py-3 shadow-[0_18px_40px_rgba(15,23,42,0.04)] xl:hidden">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-400">
                  Điều hướng nhanh
                </p>
                <p className="mt-1 text-sm font-semibold text-slate-900">{displayName}</p>
              </div>
              <button
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700"
                onClick={logout}
                type="button"
              >
                <LogOut className="h-4 w-4" />
                Đăng xuất
              </button>
            </div>

            <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
              {mobileItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-medium transition",
                      isActive
                        ? "border-slate-900 bg-slate-900 text-white"
                        : "border-slate-200 bg-slate-50 text-slate-600",
                    )
                  }
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
            </div>
          </div>

          <div>{children}</div>
        </main>
      </div>
    </div>
  );
}
