import type { ReactNode } from "react";
import {
  Bell,
  Bot,
  ChartColumn,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Package,
  ShieldPlus,
  ShoppingBag,
  UserCircle2,
  Users,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { StudioButton } from "@/components/studio/studio-ui";
import { cn } from "@/lib/cn";
import { formatRoleLabel } from "@/lib/format";

type NavItem = {
  to: string;
  label: string;
  description: string;
  icon: typeof LayoutDashboard;
};

const workspaceItems: readonly NavItem[] = [
  {
    to: "/",
    label: "Tổng quan",
    description: "Theo dõi sức khỏe vận hành, ví và doanh thu từ một màn hình.",
    icon: LayoutDashboard,
  },
  {
    to: "/bot-config",
    label: "Cấu hình bot",
    description: "Quản lý Telegram bot, nguồn cấp và thông tin thanh toán.",
    icon: Bot,
  },
  {
    to: "/products",
    label: "Sản phẩm",
    description: "Sắp xếp catalog, điều chỉnh giá bán và trạng thái hiển thị.",
    icon: Package,
  },
  {
    to: "/orders/pending",
    label: "Đơn chờ xử lý",
    description: "Nhóm đơn seller cần can thiệp hoặc theo dõi kỹ hơn.",
    icon: ShoppingBag,
  },
  {
    to: "/orders",
    label: "Đơn hàng",
    description: "Toàn bộ vòng đời giao dịch, thanh toán và giao account.",
    icon: ShoppingBag,
  },
  {
    to: "/wallet",
    label: "Ví seller",
    description: "Theo dõi ví nguồn Canboso, số dư nội bộ và lịch sử biến động.",
    icon: CreditCard,
  },
] as const;

const analyticsItems: readonly NavItem[] = [
  {
    to: "/reports/top-buyers",
    label: "Top người mua",
    description: "Nhìn nhanh nhóm khách tạo giá trị cao nhất cho shop.",
    icon: Users,
  },
  {
    to: "/reports/top-referrers",
    label: "Top giới thiệu",
    description: "Theo dõi nguồn referral và seller được giới thiệu.",
    icon: Users,
  },
  {
    to: "/reports/revenue",
    label: "Doanh thu",
    description: "Phân tích tăng trưởng, doanh thu gộp và biên lợi nhuận.",
    icon: ChartColumn,
  },
  {
    to: "/broadcasts",
    label: "Thông báo bot",
    description: "Soạn nội dung broadcast và xem lại lịch sử gửi.",
    icon: Bell,
  },
  {
    to: "/profile",
    label: "Hồ sơ",
    description: "Thông tin tài khoản seller và shop đang vận hành.",
    icon: UserCircle2,
  },
] as const;

const adminItems: readonly NavItem[] = [
  {
    to: "/admin/ctv",
    label: "Tài khoản CTV",
    description: "Tạo mới và theo dõi danh sách tài khoản seller/CTV trong hệ thống.",
    icon: ShieldPlus,
  },
] as const;

function isItemActive(pathname: string, itemPath: string) {
  return itemPath === "/"
    ? pathname === "/"
    : pathname === itemPath || pathname.startsWith(`${itemPath}/`);
}

function NavSection({ title, items }: { title: string; items: readonly NavItem[] }) {
  return (
    <div className="space-y-2">
      <p className="px-1 text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
        {title}
      </p>
      <div className="space-y-1.5">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                "group flex items-center gap-3 rounded-[12px] border px-3 py-2.5 transition",
                isActive
                  ? "border-orange-300/28 bg-[#171717] text-white shadow-[0_12px_24px_rgba(0,0,0,0.24)]"
                  : "border-transparent text-slate-400 hover:border-white/8 hover:bg-[#141414] hover:text-white",
              )
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-[10px] border transition",
                    isActive
                      ? "border-orange-300/28 bg-orange-500 text-[#0b0b0b]"
                      : "border-white/8 bg-[#101010] text-slate-300",
                  )}
                >
                  <item.icon className="h-4.5 w-4.5" />
                </span>
                <span className="min-w-0 text-sm font-semibold">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
}

export function AppShellStudio({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();
  const location = useLocation();
  const isSuperAdmin = session?.user.role === "super_admin";
  const displayName =
    session?.user.displayName ||
    (isSuperAdmin ? "Quản trị viên" : session?.user.email) ||
    "Seller";
  const navGroups = isSuperAdmin
    ? [{ title: "Quản trị", items: adminItems }]
    : [
        { title: "Vận hành", items: workspaceItems },
        { title: "Phân tích", items: analyticsItems },
      ];
  const mobileItems = isSuperAdmin ? [...adminItems] : [...workspaceItems, ...analyticsItems];

  return (
    <div className="dashboard-shell min-h-screen bg-transparent text-white">
      <div className="mx-auto flex max-w-[1800px] gap-6 px-4 py-5 lg:px-6 xl:py-6">
        <aside className="hidden w-[272px] shrink-0 xl:flex">
          <div className="sticky top-6 flex h-[calc(100vh-3rem)] w-full flex-col rounded-[22px] border border-white/8 bg-[linear-gradient(180deg,rgba(16,16,16,0.99),rgba(10,10,10,0.99))] p-5 shadow-[0_24px_56px_rgba(0,0,0,0.36)]">
            <div className="border-b border-white/8 pb-4">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-[12px] border border-orange-300/28 bg-orange-500 text-[#0b0b0b]">
                  <LayoutDashboard className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                    {isSuperAdmin ? "Admin mode" : "Seller mode"}
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span className="text-lg font-black uppercase tracking-tight text-white">
                      Reseller
                    </span>
                    <span className="rounded-[6px] bg-orange-500 px-2 py-0.5 text-sm font-black uppercase tracking-tight text-[#0b0b0b]">
                      Desk
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1 space-y-6 overflow-y-auto py-6">
              {navGroups.map((group) => (
                <NavSection key={group.title} title={group.title} items={group.items} />
              ))}
            </div>

            <div className="border-t border-white/8 pt-4">
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                Phiên hiện tại
              </p>
              <p className="mt-3 text-base font-semibold text-white">{displayName}</p>
              <p className="mt-1 text-sm text-slate-400">{session?.user.email}</p>
              <div className="mt-4 flex items-center justify-between gap-3 rounded-[12px] border border-white/8 bg-[#141414] px-3 py-3">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.22em] text-slate-500">Vai trò</p>
                  <p className="mt-1 text-sm font-semibold text-white">
                    {formatRoleLabel(session?.user.role)}
                  </p>
                </div>
                <StudioButton
                  size="sm"
                  variant="secondary"
                  onClick={logout}
                  type="button"
                >
                  <LogOut className="h-4 w-4" />
                  Đăng xuất
                </StudioButton>
              </div>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1">
          <div className="rounded-[18px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,18,18,0.98),rgba(10,10,10,0.98))] px-4 py-3 shadow-[0_18px_36px_rgba(0,0,0,0.28)] xl:hidden">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Điều hướng nhanh
                </p>
                <p className="mt-1 text-sm font-semibold text-white">{displayName}</p>
              </div>
              <StudioButton
                size="sm"
                variant="secondary"
                onClick={logout}
                type="button"
              >
                <LogOut className="h-4 w-4" />
                Đăng xuất
              </StudioButton>
            </div>

            <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
              {mobileItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-[10px] border px-3 py-2 text-sm font-medium transition",
                    isItemActive(location.pathname, item.to)
                      ? "border-orange-300/22 bg-orange-500 text-[#0b0b0b]"
                      : "border-white/8 bg-[#151515] text-slate-300",
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </NavLink>
              ))}
            </div>
          </div>

          <div className="space-y-6">{children}</div>
        </main>
      </div>
    </div>
  );
}
