import type { ReactNode } from "react";
import {
  Activity,
  ArrowUpRight,
  Bell,
  Bot,
  ChartColumn,
  ChevronRight,
  CreditCard,
  LayoutDashboard,
  LogOut,
  Package,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  UserCircle2,
  Users,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";

import { StatChip } from "@/components/dashboard/stat-chip";
import { useAuth } from "@/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { formatDate, formatRoleLabel } from "@/lib/format";

const navigation = [
  { to: "/", label: "Tổng quan", icon: LayoutDashboard },
  { to: "/bot-config", label: "Cấu hình bot", icon: Bot },
  { to: "/products", label: "Sản phẩm", icon: Package },
  { to: "/orders/pending", label: "Đơn chờ xử lý", icon: ShoppingBag },
  { to: "/orders", label: "Đơn hàng", icon: ShoppingBag },
  { to: "/wallet", label: "Nạp rút ví", icon: CreditCard },
  { to: "/reports/top-buyers", label: "Top người mua", icon: Users },
  { to: "/reports/top-referrers", label: "Top giới thiệu", icon: Users },
  { to: "/reports/revenue", label: "Doanh thu", icon: ChartColumn },
  { to: "/broadcasts", label: "Thông báo bot", icon: Bell },
  { to: "/profile", label: "Hồ sơ", icon: UserCircle2 },
];

function LegacyAppShell({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();
  const location = useLocation();
  const fallbackSection = navigation[0]!;
  const currentSection =
    navigation.find((item) =>
      item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to),
    ) || fallbackSection;

  return (
    <div className="dashboard-shell min-h-screen bg-background text-foreground">
      <div className="mx-auto flex max-w-[1680px] gap-5 px-4 py-4 lg:px-6">
        <aside className="sticky top-4 hidden h-[calc(100vh-2rem)] w-[308px] shrink-0 flex-col justify-between overflow-hidden rounded-[34px] border border-white/10 bg-[linear-gradient(180deg,rgba(7,13,27,0.95),rgba(5,10,22,0.92))] p-5 shadow-panel lg:flex">
          <div className="orbital-dot right-8 top-16 h-20 w-20 bg-sky-400/20" />
          <div
            className="orbital-dot bottom-24 left-6 h-14 w-14 bg-amber-300/20"
            style={{ animationDelay: "1.8s" }}
          />

          <div className="space-y-6">
            <div className="reveal-up overflow-hidden rounded-[30px] border border-white/10 bg-[linear-gradient(160deg,rgba(12,20,38,0.96),rgba(13,24,46,0.8))] p-5">
              <div className="glass-chip inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] uppercase tracking-[0.28em] text-slate-200">
                <Sparkles className="h-3.5 w-3.5" />
                Control Center
              </div>
              <div className="mt-5 space-y-3">
                <h1 className="font-display text-[2rem] font-semibold tracking-tight text-white">
                  Reseller Bot
                </h1>
                <p className="text-sm leading-6 text-slate-300">
                  Dashboard seller tối màu, tập trung vào vận hành bot Telegram, catalog,
                  ví nội bộ và tốc độ xử lý đơn.
                </p>
              </div>
              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                <div className="glass-chip rounded-2xl p-3">
                  <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
                    Trạng thái
                  </p>
                  <p className="mt-2 text-sm font-medium text-white">Online cục bộ</p>
                </div>
                <div className="glass-chip rounded-2xl p-3">
                  <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
                    Cập nhật
                  </p>
                  <p className="mt-2 text-sm font-medium text-white">
                    {formatDate(new Date())}
                  </p>
                </div>
              </div>
            </div>

            <nav className="reveal-up reveal-delay-1 space-y-2.5">
              {navigation.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "group flex items-center gap-3 rounded-[22px] border border-transparent px-4 py-3 text-sm text-slate-300 transition duration-300 hover:border-white/10 hover:bg-white/[0.045] hover:text-white",
                      isActive &&
                        "border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.96),rgba(229,231,235,0.92))] text-slate-950 shadow-[0_20px_40px_rgba(15,23,42,0.22)]",
                    )
                  }
                >
                  <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/5 text-slate-300 transition duration-300 group-hover:bg-white/10 group-hover:text-white">
                    <item.icon className="h-4 w-4" />
                  </span>
                  <span className="flex-1 font-medium">{item.label}</span>
                  <ChevronRight className="h-4 w-4 opacity-0 transition group-hover:translate-x-0.5 group-hover:opacity-100" />
                </NavLink>
              ))}
            </nav>
          </div>

          <div className="reveal-up reveal-delay-2 rounded-[28px] border border-white/10 bg-white/[0.045] p-4 backdrop-blur-xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.24em] text-slate-500">
                  Đăng nhập bằng
                </p>
                <p className="mt-2 text-lg font-semibold text-white">
                  {session?.user.displayName || session?.user.email}
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  {formatRoleLabel(session?.user.role)}
                </p>
              </div>
              <span className="glass-chip inline-flex h-11 w-11 items-center justify-center rounded-2xl text-white">
                <ShieldCheck className="h-5 w-5" />
              </span>
            </div>
            <button
              onClick={logout}
              className="mt-5 inline-flex items-center gap-2 rounded-2xl border border-white/10 px-3 py-2 text-sm text-slate-200 transition hover:border-white/20 hover:bg-white/5 hover:text-white"
            >
              <LogOut className="h-4 w-4" />
              Đăng xuất
            </button>
          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-5">
          <div className="reveal-up lg:hidden">
            <div className="overflow-hidden rounded-[28px] border border-white/10 bg-[linear-gradient(160deg,rgba(9,16,32,0.96),rgba(10,18,35,0.84))] p-4 shadow-panel">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.3em] text-slate-500">
                    Seller dashboard
                  </p>
                  <h1 className="mt-2 font-display text-3xl font-semibold text-white">
                    Reseller Bot
                  </h1>
                </div>
                <button
                  onClick={logout}
                  className="glass-chip rounded-2xl px-3 py-2 text-sm text-white"
                >
                  Đăng xuất
                </button>
              </div>
              <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
                {navigation.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) =>
                      cn(
                        "glass-chip inline-flex items-center gap-2 whitespace-nowrap rounded-full px-3 py-2 text-sm text-slate-200 transition",
                        isActive && "bg-white text-slate-950",
                      )
                    }
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </NavLink>
                ))}
              </div>
            </div>
          </div>

          <div className="reveal-up reveal-delay-1 overflow-hidden rounded-[30px] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.05),rgba(255,255,255,0.03))] px-5 py-4 backdrop-blur-xl">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.34em] text-slate-500">
                  Thiết lập và vận hành
                </p>
                <div className="mt-2 flex items-center gap-3">
                  <h2 className="font-display text-3xl font-semibold text-white">
                    {currentSection.label}
                  </h2>
                  <span className="glass-chip hidden items-center gap-2 rounded-full px-3 py-1 text-xs uppercase tracking-[0.26em] text-slate-200 sm:inline-flex">
                    <Activity className="h-3.5 w-3.5" />
                    Live local
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="glass-chip flex items-center gap-3 rounded-[20px] px-4 py-3 text-sm text-slate-200">
                  <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-white/10">
                    <Sparkles className="h-4.5 w-4.5" />
                  </span>
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.24em] text-slate-500">
                      Phiên hiện tại
                    </p>
                    <p className="font-medium text-white">
                      {session?.user.displayName || session?.user.email}
                    </p>
                  </div>
                </div>
                <div className="glass-chip flex items-center gap-3 rounded-[20px] px-4 py-3 text-sm text-slate-200">
                  <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-white/10">
                    <ArrowUpRight className="h-4.5 w-4.5" />
                  </span>
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.24em] text-slate-500">
                      Môi trường
                    </p>
                    <p className="font-medium text-white">Local operations</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="reveal-up reveal-delay-2">{children}</div>
        </main>
      </div>
    </div>
  );
}

const appNavigation = [
  {
    to: "/",
    label: "Tổng quan",
    icon: LayoutDashboard,
    eyebrow: "Command deck",
    description: "Theo dõi doanh thu, ví nội bộ và sức khỏe vận hành từ một màn hình trung tâm.",
  },
  {
    to: "/bot-config",
    label: "Cấu hình bot",
    icon: Bot,
    eyebrow: "Automation setup",
    description: "Quản lý shop, Telegram, provider upstream và cấu hình thanh toán của seller.",
  },
  {
    to: "/products",
    label: "Sản phẩm",
    icon: Package,
    eyebrow: "Catalog studio",
    description: "Điều chỉnh tên hiển thị, giá bán, khuyến mại và trạng thái của catalog.",
  },
  {
    to: "/orders/pending",
    label: "Đơn chờ xử lý",
    icon: ShoppingBag,
    eyebrow: "Risk monitor",
    description: "Giám sát các đơn đang chờ stock, cần theo dõi sát để giữ trải nghiệm khách hàng.",
  },
  {
    to: "/orders",
    label: "Đơn hàng",
    icon: ShoppingBag,
    eyebrow: "Order ledger",
    description: "Xem toàn bộ vòng đời đơn hàng, thanh toán, trạng thái giao account và lỗi phát sinh.",
  },
  {
    to: "/wallet",
    label: "Nạp rút ví",
    icon: CreditCard,
    eyebrow: "Treasury",
    description: "Quản lý số dư seller, ledger giao dịch, lệnh nạp tiền và yêu cầu rút tiền.",
  },
  {
    to: "/reports/top-buyers",
    label: "Top người mua",
    icon: Users,
    eyebrow: "Audience",
    description: "Nhận diện nhóm khách mua tốt nhất để chăm sóc, upsell và giữ doanh thu ổn định.",
  },
  {
    to: "/reports/top-referrers",
    label: "Top giới thiệu",
    icon: Users,
    eyebrow: "Referral",
    description: "Chuẩn bị sẵn không gian cho hệ thống giới thiệu và tăng trưởng seller giai đoạn sau.",
  },
  {
    to: "/reports/revenue",
    label: "Doanh thu",
    icon: ChartColumn,
    eyebrow: "Finance",
    description: "Phân tích doanh thu, biên lợi nhuận ước tính và nhịp bán hàng theo ngày.",
  },
  {
    to: "/broadcasts",
    label: "Thông báo bot",
    icon: Bell,
    eyebrow: "Broadcast",
    description: "Soạn thông báo, đẩy queue gửi hàng loạt và theo dõi hiệu suất từng chiến dịch.",
  },
  {
    to: "/profile",
    label: "Hồ sơ",
    icon: UserCircle2,
    eyebrow: "Identity",
    description: "Xem thông tin tài khoản seller, vai trò hiện tại và cấu hình shop đang vận hành.",
  },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { logout, session } = useAuth();
  const location = useLocation();
  const fallbackSection = appNavigation[0]!;
  const currentSection =
    appNavigation.find((item) =>
      item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to),
    ) || fallbackSection;
  const displayName = session?.user.displayName || session?.user.email || "Seller";

  return (
    <div className="dashboard-shell min-h-screen">
      <div className="mx-auto flex max-w-[1700px] gap-5 px-4 py-4 lg:px-6">
        <aside className="sticky top-4 hidden h-[calc(100vh-2rem)] w-[324px] shrink-0 flex-col justify-between overflow-hidden rounded-[34px] border border-white/10 bg-[linear-gradient(180deg,rgba(7,12,24,0.96),rgba(6,10,20,0.98))] p-5 shadow-panel xl:flex">
          <div className="orbital-dot right-8 top-16 h-20 w-20 bg-cyan-300/15" />
          <div
            className="orbital-dot bottom-24 left-8 h-16 w-16 bg-amber-300/15"
            style={{ animationDelay: "1.4s" }}
          />

          <div className="space-y-5">
            <div className="reveal-up overflow-hidden rounded-[30px] border border-white/10 bg-[linear-gradient(160deg,rgba(16,25,43,0.96),rgba(12,18,34,0.88))] p-5">
              <div className="glass-chip inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] uppercase tracking-[0.28em] text-slate-100">
                <Sparkles className="h-3.5 w-3.5" />
                Seller cockpit
              </div>
              <h1 className="mt-5 font-display text-[2.1rem] font-semibold tracking-tight text-white">
                Reseller Bot
              </h1>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                Một lớp điều khiển thống nhất cho bot Telegram, catalog, ví nội bộ và các luồng
                xử lý tự động của seller.
              </p>

              <div className="mt-6 grid gap-3">
                <StatChip
                  icon={ShieldCheck}
                  label="Phiên hiện tại"
                  value={formatRoleLabel(session?.user.role)}
                  meta="Phân quyền seller đang hoạt động"
                  tone="sky"
                />
                <StatChip
                  icon={Activity}
                  label="Cập nhật"
                  value={formatDate(new Date())}
                  meta="Giao diện sẵn sàng cho local operations"
                  tone="amber"
                />
              </div>
            </div>

            <nav className="reveal-up reveal-delay-1 space-y-2.5">
              {appNavigation.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "group block rounded-[24px] border border-transparent px-4 py-3 transition duration-300 hover:border-white/10 hover:bg-white/[0.04]",
                      isActive && "border-white/10 bg-white/[0.07] shadow-[0_16px_38px_rgba(2,6,23,0.18)]",
                    )
                  }
                >
                  {({ isActive }) => (
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          "mt-0.5 flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.04] text-slate-300 transition duration-300",
                          isActive && "bg-white text-slate-950",
                        )}
                      >
                        <item.icon className="h-4.5 w-4.5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p
                            className={cn(
                              "font-semibold text-slate-100 transition duration-300",
                              isActive && "text-white",
                            )}
                          >
                            {item.label}
                          </p>
                          <ChevronRight
                            className={cn(
                              "h-4 w-4 text-slate-500 transition duration-300",
                              isActive
                                ? "translate-x-0.5 text-slate-200"
                                : "opacity-0 group-hover:opacity-100",
                            )}
                          />
                        </div>
                        <p className="mt-1 text-sm leading-6 text-slate-500">{item.description}</p>
                      </div>
                    </div>
                  )}
                </NavLink>
              ))}
            </nav>
          </div>

          <div className="reveal-up reveal-delay-2 rounded-[28px] border border-white/10 bg-white/[0.045] p-4 backdrop-blur-xl">
            <p className="app-kicker">Đăng nhập bằng</p>
            <p className="mt-3 text-xl font-semibold text-white">{displayName}</p>
            <p className="mt-1 text-sm text-slate-400">{session?.user.email}</p>
            <div className="mt-5 app-divider" />
            <div className="mt-5 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Trạng thái</p>
                <p className="mt-2 text-sm font-semibold text-emerald-300">Ready for operations</p>
              </div>
              <Button variant="secondary" onClick={logout}>
                <LogOut className="h-4 w-4" />
                Đăng xuất
              </Button>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-5">
          <div className="reveal-up xl:hidden">
            <div className="overflow-hidden rounded-[30px] border border-white/10 bg-[linear-gradient(160deg,rgba(10,17,33,0.96),rgba(8,14,27,0.92))] p-4 shadow-panel">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="app-kicker">Seller cockpit</p>
                  <h1 className="mt-3 font-display text-3xl font-semibold text-white">
                    Reseller Bot
                  </h1>
                  <p className="mt-2 text-sm leading-6 text-slate-400">
                    Điều khiển bot, catalog, ví và chiến dịch broadcast trên cùng một dashboard.
                  </p>
                </div>
                <Button variant="secondary" size="sm" onClick={logout}>
                  <LogOut className="h-4 w-4" />
                  Thoát
                </Button>
              </div>

              <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
                {appNavigation.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) =>
                      cn(
                        "glass-chip inline-flex items-center gap-2 whitespace-nowrap rounded-full px-3 py-2 text-sm text-slate-200 transition",
                        isActive && "bg-white text-slate-950",
                      )
                    }
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </NavLink>
                ))}
              </div>
            </div>
          </div>

          <header className="reveal-up reveal-delay-1 overflow-hidden rounded-[30px] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.05),rgba(255,255,255,0.03))] px-5 py-5 backdrop-blur-xl">
            <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
              <div className="max-w-3xl">
                <p className="app-kicker">{currentSection.eyebrow}</p>
                <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight text-white">
                  {currentSection.label}
                </h2>
                <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-300 sm:text-base">
                  {currentSection.description}
                </p>
              </div>

              <div className="grid gap-3 md:grid-cols-3 xl:min-w-[620px]">
                <StatChip
                  icon={Sparkles}
                  label="Người vận hành"
                  value={displayName}
                  meta="Phiên seller hiện tại"
                  tone="sky"
                />
                <StatChip
                  icon={Activity}
                  label="Môi trường"
                  value="Local operations"
                  meta="Sẵn sàng kiểm thử end-to-end"
                  tone="amber"
                />
                <StatChip
                  icon={ShieldCheck}
                  label="Bảo mật"
                  value="Secrets encrypted"
                  meta="Khóa seller được lưu trong database"
                  tone="emerald"
                />
              </div>
            </div>
          </header>

          <div className="reveal-up reveal-delay-2">{children}</div>
        </main>
      </div>
    </div>
  );
}
