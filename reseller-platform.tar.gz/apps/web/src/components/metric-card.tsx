import { ArrowUpRight, type LucideIcon } from "lucide-react";

import { Card } from "@/components/ui/card";
import { InfoHint } from "@/components/ui/info-hint";
import { cn } from "@/lib/cn";

export function MetricCard({
  label,
  value,
  description,
  icon: Icon = ArrowUpRight,
  tone = "sky",
}: {
  label: string;
  value: string;
  description: string;
  icon?: LucideIcon;
  tone?: "sky" | "amber" | "emerald";
}) {
  return (
    <Card>
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
              {label}
            </p>
            <InfoHint
              content={description}
              className="shrink-0"
              panelClassName="max-w-[260px]"
              label={`Xem ghi chú cho ${label}`}
            />
          </div>
          <p className="text-3xl font-semibold text-white sm:text-[2rem]">{value}</p>
        </div>
        <div
          className={cn(
            "flex h-11 w-11 items-center justify-center rounded-[14px] border border-white/8 bg-[#121A2E] text-slate-50",
            tone === "sky" && "text-emerald-200",
            tone === "amber" && "text-emerald-300",
            tone === "emerald" && "text-emerald-200",
          )}
        >
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}
