import type { PropsWithChildren } from "react";

import { cn } from "@/lib/cn";

export function Badge({
  children,
  tone = "neutral",
}: PropsWithChildren<{ tone?: "neutral" | "success" | "danger" | "warning" }>) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em]",
        tone === "success" && "border-emerald-400/20 bg-emerald-500/10 text-emerald-100",
        tone === "danger" && "border-rose-400/20 bg-rose-500/10 text-rose-200",
        tone === "warning" && "border-emerald-300/20 bg-emerald-400/10 text-emerald-100",
        tone === "neutral" && "border-white/8 bg-[#18233c] text-slate-300",
      )}
    >
      {children}
    </span>
  );
}
