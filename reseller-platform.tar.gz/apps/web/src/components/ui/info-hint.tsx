import type { ReactNode } from "react";
import { useEffect, useRef, useState } from "react";
import { CircleHelp } from "lucide-react";

import { cn } from "@/lib/cn";

export function InfoHint({
  content,
  className,
  panelClassName,
  label = "Xem ghi chú",
}: {
  content?: ReactNode;
  className?: string;
  panelClassName?: string;
  label?: string;
}) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement | null>(null);

  if (!content) {
    return null;
  }

  useEffect(() => {
    if (!open) {
      return;
    }

    const handlePointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) {
        setOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
      }
    };

    window.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("keydown", handleEscape);

    return () => {
      window.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("keydown", handleEscape);
    };
  }, [open]);

  return (
    <div ref={rootRef} className={cn("relative inline-flex items-center", className)}>
      <button
        type="button"
        aria-label={open ? "An ghi chu" : label}
        title={open ? "An ghi chu" : label}
        onClick={() => setOpen((current) => !current)}
        className={cn(
          "inline-flex h-5.5 w-5.5 items-center justify-center rounded-full border border-white/10 bg-white/[0.05] text-slate-400 transition-colors duration-200 hover:border-emerald-300/35 hover:bg-emerald-400/12 hover:text-emerald-100",
          open && "border-emerald-300/35 bg-emerald-400/12 text-emerald-100",
        )}
      >
        <CircleHelp className="h-3.5 w-3.5" />
      </button>

      <div
        className={cn(
          "pointer-events-none absolute left-0 top-full z-50 mt-2 w-[min(22rem,calc(100vw-3rem))] origin-top-left transition-[opacity,transform] duration-200 ease-out",
          open ? "translate-y-0 opacity-100" : "translate-y-1 opacity-0",
        )}
      >
        <div
          className={cn(
            "pointer-events-auto rounded-[14px] border border-white/10 bg-[#0F172A]/96 px-3 py-2.5 text-sm leading-6 text-slate-300 shadow-[0_20px_50px_rgba(2,6,23,0.45)] backdrop-blur-xl",
            panelClassName,
          )}
        >
          {content}
        </div>
      </div>
    </div>
  );
}
