import type { ButtonHTMLAttributes, PropsWithChildren } from "react";

import { cn } from "@/lib/cn";

export function Button({
  children,
  className,
  type,
  variant = "primary",
  size = "md",
  ...props
}: PropsWithChildren<
  ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "ghost" | "danger";
    size?: "sm" | "md" | "lg";
  }
>) {
  return (
    <button
      type={type ?? "button"}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-[12px] border font-semibold transition duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A0F1C] disabled:cursor-not-allowed disabled:opacity-55",
        size === "sm" && "px-3.5 py-2.5 text-sm",
        size === "md" && "px-4 py-3 text-sm",
        size === "lg" && "px-5 py-3.5 text-[0.95rem]",
        variant === "primary" &&
          "border-emerald-300/24 bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e] shadow-[0_12px_28px_rgba(16,185,129,0.22)] hover:brightness-110",
        variant === "secondary" &&
          "border-white/10 bg-[#18233c] text-slate-100 hover:border-emerald-300/18 hover:bg-[#1E2A47]",
        variant === "ghost" &&
          "border-transparent bg-transparent text-slate-300 hover:bg-[#18233c] hover:text-white",
        variant === "danger" &&
          "border-rose-300/20 bg-rose-500/12 text-rose-100 hover:border-rose-200/30 hover:bg-rose-500/18",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}
