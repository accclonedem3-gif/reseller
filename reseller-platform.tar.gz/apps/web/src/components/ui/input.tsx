import type { InputHTMLAttributes } from "react";

import { cn } from "@/lib/cn";

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "w-full rounded-[20px] border border-white/10 bg-[linear-gradient(180deg,#121A2E,#18233C)] px-4 py-3.5 text-sm font-medium text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.05)] outline-none transition duration-300 placeholder:text-slate-500 focus:border-emerald-300/50 focus:bg-[#1E2A47] focus:shadow-[0_0_0_4px_rgba(16,185,129,0.14)] disabled:cursor-not-allowed disabled:opacity-60",
        props.className,
      )}
    />
  );
}
