import type { PropsWithChildren } from "react";

import { cn } from "@/lib/cn";

export function Card({
  children,
  className,
}: PropsWithChildren<{ className?: string }>) {
  return (
    <div
      className={cn(
        "rounded-[24px] border border-white/8 bg-[linear-gradient(180deg,#121A2E,#1E2A47)] p-5 shadow-[0_24px_60px_rgba(2,6,23,0.24)] backdrop-blur-xl",
        className,
      )}
    >
      {children}
    </div>
  );
}
