import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { AlertCircle, CheckCircle2, Info, TriangleAlert, X } from "lucide-react";

import { cn } from "@/lib/cn";

type ToastTone = "success" | "error" | "warning" | "info";

type ToastInput = {
  tone?: ToastTone;
  title?: string;
  message: ReactNode;
  duration?: number;
};

type ToastItem = Required<Pick<ToastInput, "tone" | "duration">> &
  Pick<ToastInput, "title" | "message"> & {
    id: string;
    leaving: boolean;
  };

type ToastContextValue = {
  showToast: (toast: ToastInput) => string;
  dismissToast: (id: string) => void;
};

const EXIT_MS = 220;
const MAX_TOASTS = 4;
const ToastContext = createContext<ToastContextValue | null>(null);
let toastSeed = 0;

const toneStyles: Record<
  ToastTone,
  {
    icon: typeof CheckCircle2;
    iconClassName: string;
    borderClassName: string;
    progressClassName: string;
  }
> = {
  success: {
    icon: CheckCircle2,
    iconClassName: "bg-emerald-400/14 text-emerald-100 ring-1 ring-emerald-300/18",
    borderClassName: "border-emerald-300/22",
    progressClassName: "bg-emerald-300/80",
  },
  error: {
    icon: AlertCircle,
    iconClassName: "bg-rose-400/14 text-rose-100 ring-1 ring-rose-300/18",
    borderClassName: "border-rose-300/22",
    progressClassName: "bg-rose-300/80",
  },
  warning: {
    icon: TriangleAlert,
    iconClassName: "bg-amber-400/14 text-amber-100 ring-1 ring-amber-300/18",
    borderClassName: "border-amber-300/22",
    progressClassName: "bg-amber-300/80",
  },
  info: {
    icon: Info,
    iconClassName: "bg-sky-400/14 text-sky-100 ring-1 ring-sky-300/18",
    borderClassName: "border-sky-300/22",
    progressClassName: "bg-sky-300/80",
  },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const timersRef = useRef(new Map<string, number[]>());

  const clearTimers = useCallback((id: string) => {
    const timers = timersRef.current.get(id) || [];
    timers.forEach((timer) => window.clearTimeout(timer));
    timersRef.current.delete(id);
  }, []);

  const removeToast = useCallback(
    (id: string) => {
      clearTimers(id);
      setToasts((current) => current.filter((toast) => toast.id !== id));
    },
    [clearTimers],
  );

  const dismissToast = useCallback(
    (id: string) => {
      setToasts((current) =>
        current.map((toast) => {
          if (toast.id !== id || toast.leaving) {
            return toast;
          }

          return { ...toast, leaving: true };
        }),
      );

      const exitTimer = window.setTimeout(() => removeToast(id), EXIT_MS);
      timersRef.current.set(id, [...(timersRef.current.get(id) || []), exitTimer]);
    },
    [removeToast],
  );

  const showToast = useCallback(
    ({ tone = "info", title, message, duration = 4400 }: ToastInput) => {
      const id = `toast-${Date.now()}-${toastSeed++}`;
      const toast: ToastItem = {
        id,
        tone,
        title,
        message,
        duration,
        leaving: false,
      };

      setToasts((current) => {
        const next = [toast, ...current];
        next.slice(MAX_TOASTS).forEach((overflowToast) => clearTimers(overflowToast.id));
        return next.slice(0, MAX_TOASTS);
      });

      const dismissTimer = window.setTimeout(() => dismissToast(id), duration);
      timersRef.current.set(id, [dismissTimer]);
      return id;
    },
    [clearTimers, dismissToast],
  );

  useEffect(
    () => () => {
      timersRef.current.forEach((timers) =>
        timers.forEach((timer) => window.clearTimeout(timer)),
      );
      timersRef.current.clear();
    },
    [],
  );

  const contextValue = useMemo(
    () => ({
      showToast,
      dismissToast,
    }),
    [dismissToast, showToast],
  );

  return (
    <ToastContext.Provider value={contextValue}>
      {children}
      <div className="pointer-events-none fixed right-4 top-4 z-[90] flex w-[calc(100vw-2rem)] max-w-[420px] flex-col gap-3 sm:right-5 sm:top-5">
        {toasts.map((toast) => {
          const styles = toneStyles[toast.tone];
          const Icon = styles.icon;

          return (
            <div
              key={toast.id}
              role={toast.tone === "error" ? "alert" : "status"}
              aria-live={toast.tone === "error" ? "assertive" : "polite"}
              className={cn(
                "toast-card pointer-events-auto relative overflow-hidden rounded-[18px] border bg-[#121A2E]/96 px-4 py-3.5 text-slate-100 shadow-[0_18px_44px_rgba(0,0,0,0.36)] backdrop-blur-xl",
                styles.borderClassName,
                toast.leaving ? "toast-card-exit" : "toast-card-enter",
              )}
            >
              <div className="flex items-start gap-3">
                <span
                  className={cn(
                    "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px]",
                    styles.iconClassName,
                  )}
                >
                  <Icon className="h-4.5 w-4.5" />
                </span>
                <div className="min-w-0 flex-1">
                  {toast.title ? (
                    <p className="text-sm font-semibold text-white">{toast.title}</p>
                  ) : null}
                  <div className="text-sm leading-6 text-slate-200">{toast.message}</div>
                </div>
                <button
                  type="button"
                  aria-label="Dong thong bao"
                  title="Dong thong bao"
                  className="rounded-[10px] p-1.5 text-slate-400 transition hover:bg-white/8 hover:text-white"
                  onClick={() => dismissToast(toast.id)}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div
                className={cn(
                  "toast-progress absolute bottom-0 left-0 h-0.5 w-full origin-left",
                  styles.progressClassName,
                )}
                style={{ animationDuration: `${toast.duration}ms` }}
              />
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);

  if (!context) {
    throw new Error("useToast must be used inside ToastProvider");
  }

  return context;
}
