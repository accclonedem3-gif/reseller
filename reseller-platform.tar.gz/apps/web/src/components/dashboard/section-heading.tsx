import type { ReactNode } from "react";

import { cn } from "@/lib/cn";
import { InfoHint } from "@/components/ui/info-hint";

export function SectionHeading({
  eyebrow,
  title,
  description,
  actions,
  className,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between",
        className,
      )}
    >
      <div className="max-w-3xl">
        <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-500">
          {eyebrow}
        </p>
        <div className="mt-3 flex max-w-full items-start gap-2">
          <h1 className="max-w-[calc(100%-2rem)] text-balance text-3xl font-semibold tracking-tight text-white sm:text-[2.2rem]">
            {title}
          </h1>
          <InfoHint
            content={description}
            className="shrink-0"
            panelClassName="max-w-xl"
            label={`Xem ghi chú cho ${title}`}
          />
        </div>
      </div>
      {actions ? <div className="flex flex-wrap gap-3">{actions}</div> : null}
    </div>
  );
}
