import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/cn";

export function StatChip({
  icon: Icon,
  label,
  value,
  meta,
  tone = "neutral",
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  meta?: string;
  tone?: "neutral" | "sky" | "amber" | "emerald";
}) {
  return (
    <div className="rounded-[20px] border border-white/8 bg-[#18233c] p-4">
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-[14px] border border-white/8 bg-[#121A2E] text-slate-100",
            tone === "sky" && "text-emerald-100",
            tone === "amber" && "text-emerald-200",
            tone === "emerald" && "text-emerald-100",
          )}
        >
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
            {label}
          </p>
          <p className="mt-2 text-lg font-semibold text-white">{value}</p>
          {meta ? <p className="mt-1 text-sm leading-6 text-slate-400">{meta}</p> : null}
        </div>
      </div>
    </div>
  );
}
