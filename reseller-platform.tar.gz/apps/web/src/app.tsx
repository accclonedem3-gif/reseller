import { Navigate, Outlet, Route, Routes } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { AppShellPrime } from "@/components/layout/app-shell-prime";
import { AdminCtvPage } from "@/pages/admin-ctv-page";
import { BotConfigPage } from "@/pages/bot-config-page-pro";
import { BroadcastsPage } from "@/pages/broadcasts-page-pro";
import { LoginPageStudio } from "@/pages/login-page-studio";
import { ManualCryptoPaymentPage } from "@/pages/manual-crypto-payment-page";
import { OrdersPageStudio } from "@/pages/orders-page-studio";
import { OverviewPagePrime } from "@/pages/overview-page-prime";
import { PendingOrdersPageStudio } from "@/pages/pending-orders-page-studio";
import { PaymentStatusPage } from "@/pages/payment-status-page-pro";
import { ProductsPageStudio } from "@/pages/products-page-studio";
import { ProfilePage } from "@/pages/profile-page-pro";
import { RevenuePagePrime } from "@/pages/revenue-page-prime";
import { ResetPasswordPageStudio } from "@/pages/reset-password-page-studio";
import { TopBuyersPage } from "@/pages/top-buyers-page-pro";
import { TopReferrersPage } from "@/pages/top-referrers-page-pro";
import { WalletPage } from "@/pages/wallet-page-pro";

function ProtectedLayout() {
  const { ready, session } = useAuth();

  if (!ready) {
    return <div className="p-10 text-slate-300">Đang tải phiên làm việc...</div>;
  }

  if (!session) {
    return <Navigate to="/login" replace />;
  }

  return (
    <AppShellPrime>
      <Outlet />
    </AppShellPrime>
  );
}

function SellerOnlyLayout() {
  const { session } = useAuth();

  if (session?.user.role === "super_admin") {
    return <Navigate to="/admin/ctv" replace />;
  }

  return <Outlet />;
}

function AdminOnlyLayout() {
  const { session } = useAuth();

  if (session?.user.role !== "super_admin") {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
}

function HomeRoute() {
  const { session } = useAuth();

  if (session?.user.role === "super_admin") {
    return <Navigate to="/admin/ctv" replace />;
  }

  return <OverviewPagePrime />;
}

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPageStudio />} />
      <Route path="/reset-password" element={<ResetPasswordPageStudio />} />
      <Route path="/payments/crypto" element={<ManualCryptoPaymentPage />} />
      <Route path="/payments/success" element={<PaymentStatusPage mode="success" />} />
      <Route path="/payments/cancel" element={<PaymentStatusPage mode="cancel" />} />
      <Route element={<ProtectedLayout />}>
        <Route path="/" element={<HomeRoute />} />
        <Route element={<SellerOnlyLayout />}>
          <Route path="/bot-config" element={<BotConfigPage />} />
          <Route path="/products" element={<ProductsPageStudio />} />
          <Route path="/orders/pending" element={<PendingOrdersPageStudio />} />
          <Route path="/orders" element={<OrdersPageStudio />} />
          <Route path="/wallet" element={<WalletPage />} />
          <Route path="/reports/top-buyers" element={<TopBuyersPage />} />
          <Route path="/reports/top-referrers" element={<TopReferrersPage />} />
          <Route path="/reports/revenue" element={<RevenuePagePrime />} />
          <Route path="/broadcasts" element={<BroadcastsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
        </Route>
        <Route element={<AdminOnlyLayout />}>
          <Route path="/admin/ctv" element={<AdminCtvPage />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
