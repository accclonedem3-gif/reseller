import { useState } from "react";
import { Navigate } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function LoginPage() {
  const { login, register, session } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("seller@example.com");
  const [password, setPassword] = useState("Seller123!");
  const [displayName, setDisplayName] = useState("Seller mẫu");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (session) {
    return <Navigate to="/" replace />;
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register(email, password, displayName);
      }
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể đăng nhập.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden px-4 py-10">
      <div className="pointer-events-none absolute inset-0 bg-grid bg-[length:42px_42px] opacity-30" />
      <div className="mx-auto grid min-h-[90vh] max-w-6xl items-center gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-8 px-4">
          <div className="inline-flex rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.3em] text-slate-400">
            Trung tâm vận hành reseller Telegram
          </div>
          <div className="space-y-5">
            <h1 className="max-w-2xl font-display text-5xl font-bold tracking-tight text-white sm:text-6xl">
              Bảng điều khiển tiếng Việt cho reseller bot bán hàng, tối ưu cho vận hành thực chiến.
            </h1>
            <p className="max-w-xl text-lg text-slate-300">
              Quản lý bot, đồng bộ sản phẩm, đơn hàng, ví nội bộ và broadcast trong
              một màn hình duy nhất. Tài khoản demo đã được seed sẵn để bạn test ngay.
            </p>
          </div>
        </div>
        <Card className="relative overflow-hidden border-white/10 bg-[#0a1223]">
          <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-brand via-emerald-400 to-amber-300" />
          <div className="mb-6 flex gap-2 rounded-2xl border border-white/10 bg-white/5 p-1">
            <button
              className={`flex-1 rounded-xl px-4 py-3 text-sm font-semibold transition ${
                mode === "login"
                  ? "bg-white text-slate-950"
                  : "text-slate-400 hover:text-white"
              }`}
              onClick={() => setMode("login")}
            >
              Đăng nhập
            </button>
            <button
              className={`flex-1 rounded-xl px-4 py-3 text-sm font-semibold transition ${
                mode === "register"
                  ? "bg-white text-slate-950"
                  : "text-slate-400 hover:text-white"
              }`}
              onClick={() => setMode("register")}
            >
              Đăng ký seller
            </button>
          </div>

          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <label className="text-sm text-slate-400">Email</label>
              <Input value={email} onChange={(event) => setEmail(event.target.value)} />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-slate-400">Mật khẩu</label>
              <Input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>
            {mode === "register" ? (
              <div className="space-y-2">
                <label className="text-sm text-slate-400">Tên shop / seller</label>
                <Input
                  value={displayName}
                  onChange={(event) => setDisplayName(event.target.value)}
                />
              </div>
            ) : null}
            {error ? (
              <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
                {error}
              </div>
            ) : null}
            <Button className="w-full rounded-2xl py-3" disabled={loading} type="submit">
              {loading
                ? "Đang xử lý..."
                : mode === "login"
                  ? "Vào dashboard"
                  : "Tạo tài khoản seller"}
            </Button>
          </form>

          <div className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-4 text-sm text-slate-400">
            Tài khoản demo: <span className="text-white">seller@example.com / Seller123!</span>
          </div>
        </Card>
      </div>
    </div>
  );
}
