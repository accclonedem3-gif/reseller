﻿import type { ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BarChart3,
  Boxes,
  ChevronDown,
  ChevronUp,
  Package,
  PackagePlus,
  RefreshCw,
  Save,
  Search,
  Trash2,
  Wallet,
} from "lucide-react";

import {
  StudioBadge,
  StudioButton,
  StudioCard,
  StudioInput,
  StudioMetric,
  StudioSectionIntro,
  StudioTextArea,
} from "@/components/studio/studio-ui";
import { InfoHint } from "@/components/ui/info-hint";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { formatCurrency, formatDate } from "@/lib/format";

type ProductFilter = "all" | "manual" | "active" | "hidden" | "paused";
type ProductPanel = "edit" | "create";

type Product = {
  id: string;
  sourceProductId: string;
  providerName: string;
  sourceName: string;
  displayName: string;
  description: string | null;
  sourcePrice: number;
  salePrice: number;
  available: number | null;
  soldCount: number;
  totalCount: number;
  enabled: boolean;
  hidden: boolean;
  promoText: string | null;
  isManual: boolean;
  deliveryText: string | null;
  syncedAt: string | null;
};

type ProductInventoryItem = {
  key: string;
  status: "available" | "delivered";
  content: string;
  orderCode?: string;
  deliveredAt?: string | null;
  customerLabel?: string | null;
};

type ProductInventory = {
  summary: {
    availableCount: number;
    deliveredCount: number;
    hiddenDeliveredCount: number;
  };
  availableItems: ProductInventoryItem[];
  deliveredItems: ProductInventoryItem[];
};

type ProductEditorForm = {
  displayName: string;
  salePrice: string;
  hidden: boolean;
  enabled: boolean;
  promoText: string;
  sourceName: string;
  sourceDescription: string;
  sourcePrice: string;
  available: string;
  deliveryText: string;
};

type ManualProductForm = {
  displayName: string;
  salePrice: string;
  sourceName: string;
  sourceDescription: string;
  sourcePrice: string;
  available: string;
  promoText: string;
  deliveryText: string;
  hidden: boolean;
  enabled: boolean;
};

type NoticeTone = "success" | "warning" | "danger";

const emptyEditorForm: ProductEditorForm = {
  displayName: "",
  salePrice: "",
  hidden: false,
  enabled: true,
  promoText: "",
  sourceName: "",
  sourceDescription: "",
  sourcePrice: "",
  available: "",
  deliveryText: "",
};

const emptyManualForm: ManualProductForm = {
  displayName: "",
  salePrice: "",
  sourceName: "",
  sourceDescription: "",
  sourcePrice: "0",
  available: "",
  promoText: "",
  deliveryText: "",
  hidden: false,
  enabled: true,
};

function Field({
  label,
  hint,
  description,
  children,
}: {
  label: string;
  hint?: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <label className="text-sm font-semibold text-white">{label}</label>
          <InfoHint
            content={description}
            className="shrink-0"
            panelClassName="max-w-sm"
            label={`Xem ghi chú cho ${label}`}
          />
        </div>
        {hint ? (
          <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
            {hint}
          </span>
        ) : null}
      </div>
      {children}
    </div>
  );
}

function Notice({
  tone,
  children,
}: {
  tone: NoticeTone;
  children: ReactNode;
}) {
  return (
    <div
      className={[
        "rounded-[18px] border px-4 py-3 text-sm leading-6",
        tone === "success" && "border-emerald-400/18 bg-emerald-500/10 text-emerald-100",
        tone === "warning" && "border-emerald-300/18 bg-emerald-400/10 text-emerald-100",
        tone === "danger" && "border-rose-400/18 bg-rose-500/10 text-rose-100",
      ]
        .filter(Boolean)
        .join(" ")}
    >
      {children}
    </div>
  );
}

function getErrorMessage(error: unknown, fallback: string) {
  if (axios.isAxiosError(error)) {
    const responseData = error.response?.data as
      | { message?: string | string[] }
      | undefined;
    const message =
      typeof responseData?.message === "string"
        ? responseData.message
        : Array.isArray(responseData?.message)
          ? responseData.message.join(", ")
          : error.message;

    if (message) {
      return message;
    }
  }

  if (error instanceof Error && error.message) {
    return error.message;
  }

  return fallback;
}

function parseRequiredNumber(value: string, label: string) {
  const trimmed = value.trim();
  if (!trimmed) {
    throw new Error(`${label} không được để trống.`);
  }

  const parsed = Number(trimmed);
  if (!Number.isFinite(parsed) || parsed < 0) {
    throw new Error(`${label} phải là số từ 0 trở lên.`);
  }

  return parsed;
}

function parseOptionalInteger(value: string, label: string) {
  const trimmed = value.trim();
  if (!trimmed) {
    return undefined;
  }

  const parsed = Number(trimmed);
  if (!Number.isInteger(parsed) || parsed < 0) {
    throw new Error(`${label} phải là số nguyên từ 0 trở lên.`);
  }

  return parsed;
}

function createEditorForm(product: Product): ProductEditorForm {
  return {
    displayName: product.displayName || "",
    salePrice: String(product.salePrice ?? ""),
    hidden: Boolean(product.hidden),
    enabled: Boolean(product.enabled),
    promoText: product.promoText || "",
    sourceName: product.sourceName || "",
    sourceDescription: product.description || "",
    sourcePrice: String(product.sourcePrice ?? 0),
    available: product.available === null ? "" : String(product.available),
    deliveryText: product.deliveryText || "",
  };
}

function ManualInventoryPanel({
  inventory,
  isLoading,
  isPurging,
  onPurgeAll,
  onPurgeOne,
}: {
  inventory?: ProductInventory;
  isLoading: boolean;
  isPurging: boolean;
  onPurgeAll: () => void;
  onPurgeOne: (entryKey: string) => void;
}) {
  return (
    <div className="border-t border-white/8 px-4 pb-4 pt-4 lg:px-5">
      <div className="rounded-[20px] border border-white/8 bg-[linear-gradient(180deg,rgba(13,16,22,0.96),rgba(10,12,16,0.96))] p-4 shadow-[0_18px_36px_rgba(0,0,0,0.24)] transition-[border-color,box-shadow,background-color] duration-300 ease-out lg:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm font-semibold text-white">Kho account của sản phẩm</p>
            <p className="mt-1 text-sm text-slate-400">
              Theo dõi account còn sẵn và account đã giao ngay tại đây.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="rounded-full border border-emerald-400/18 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-100">
              Còn sẵn {inventory?.summary.availableCount ?? 0}
            </div>
            <div className="rounded-full border border-emerald-300/18 bg-emerald-400/10 px-3 py-1.5 text-xs font-semibold text-emerald-100">
              Đã giao {inventory?.summary.deliveredCount ?? 0}
            </div>
            <div className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-semibold text-slate-300">
              Đã dọn {inventory?.summary.hiddenDeliveredCount ?? 0}
            </div>
            <StudioButton
              size="sm"
              variant="danger"
              disabled={isPurging || !inventory?.deliveredItems?.length}
              onClick={onPurgeAll}
            >
              <Trash2 className="h-4 w-4" />
              Xóa nhanh đã giao
            </StudioButton>
          </div>
        </div>

        <div className="mt-4 grid gap-4 xl:grid-cols-2">
          <div className="rounded-[18px] border border-white/8 bg-white/[0.025] p-3 transition-colors duration-300 ease-out">
            <div className="flex items-center justify-between gap-3 border-b border-white/8 pb-3">
              <p className="text-sm font-semibold text-white">Account còn sẵn</p>
              <StudioBadge tone="success">{inventory?.summary.availableCount ?? 0} account</StudioBadge>
            </div>

            {isLoading ? (
              <div className="px-1 py-4 text-sm text-slate-400">Đang tải kho account...</div>
            ) : inventory?.availableItems.length ? (
              <div className="mt-3 max-h-[360px] space-y-2 overflow-y-auto pr-1">
                {inventory.availableItems.map((item, index) => (
                  <div
                    key={item.key}
                  className="rounded-[16px] border border-white/8 bg-[#0f1319] px-3 py-3 transition-[border-color,background-color,transform] duration-300 ease-out hover:border-white/12 hover:bg-[#121922]"
                >
                    <div className="mb-2 flex items-center justify-between gap-3">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">
                        Account #{index + 1}
                      </p>
                      <StudioBadge tone="success">Sẵn sàng</StudioBadge>
                    </div>
                    <code className="block whitespace-pre-wrap break-all text-[13px] leading-6 text-slate-100">
                      {item.content}
                    </code>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-3 rounded-[16px] border border-dashed border-white/8 bg-white/[0.03] px-4 py-4 text-sm leading-6 text-slate-400">
                Chưa còn account sẵn trong kho tự động.
              </div>
            )}
          </div>

          <div className="rounded-[18px] border border-white/8 bg-white/[0.025] p-3 transition-colors duration-300 ease-out">
            <div className="flex items-center justify-between gap-3 border-b border-white/8 pb-3">
              <p className="text-sm font-semibold text-white">Account đã giao</p>
              <StudioBadge tone="neutral">{inventory?.summary.deliveredCount ?? 0} account</StudioBadge>
            </div>

            {isLoading ? (
              <div className="px-1 py-4 text-sm text-slate-400">Đang tải lịch sử đã giao...</div>
            ) : inventory?.deliveredItems.length ? (
              <div className="mt-3 max-h-[360px] space-y-2 overflow-y-auto pr-1">
                {inventory.deliveredItems.map((item) => (
                <div
                  key={item.key}
                  className="rounded-[16px] border border-white/8 bg-[#10151c] px-3 py-3 transition-[border-color,background-color,transform] duration-300 ease-out hover:border-white/12 hover:bg-[#141a22]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <StudioBadge tone="neutral">Đã giao</StudioBadge>
                        {item.orderCode ? (
                          <span className="text-[11px] text-slate-500">{item.orderCode}</span>
                        ) : null}
                      </div>
                        <p className="mt-2 text-xs text-slate-400">
                          {item.customerLabel || "Khách Telegram"} •{" "}
                          {item.deliveredAt ? formatDate(item.deliveredAt) : "-"}
                        </p>
                      </div>

                      <StudioButton
                        size="sm"
                        variant="danger"
                        disabled={isPurging}
                        onClick={() => onPurgeOne(item.key)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Xóa
                      </StudioButton>
                    </div>

                    <code className="mt-3 block whitespace-pre-wrap break-all text-[13px] leading-6 text-slate-100">
                      {item.content}
                    </code>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-3 rounded-[16px] border border-dashed border-white/8 bg-white/[0.03] px-4 py-4 text-sm leading-6 text-slate-400">
                Chưa có account nào được giao hoặc bạn đã dọn hết khỏi màn quản lý.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function ProductsPageStudio() {
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const productsQuery = useQuery<Product[]>({
    queryKey: ["products"],
    queryFn: async () => (await api.get("/products")).data,
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [keyword, setKeyword] = useState("");
  const [filter, setFilter] = useState<ProductFilter>("all");
  const [activePanel, setActivePanel] = useState<ProductPanel>("edit");
  const [editorForm, setEditorForm] = useState<ProductEditorForm>(emptyEditorForm);
  const [createForm, setCreateForm] = useState<ManualProductForm>(emptyManualForm);
  const [expandedInventoryProductId, setExpandedInventoryProductId] = useState<string | null>(null);
  const [expandedEditorProductId, setExpandedEditorProductId] = useState<string | null>(null);

  const products = productsQuery.data || [];

  const filteredProducts = useMemo(() => {
    const normalizedKeyword = keyword.trim().toLowerCase();

    return products.filter((item) => {
      const matchesKeyword =
        !normalizedKeyword ||
        [item.displayName, item.sourceName, item.description]
          .filter(Boolean)
          .some((value) => String(value).toLowerCase().includes(normalizedKeyword));

      const matchesFilter =
        filter === "all" ||
        (filter === "manual" && item.isManual) ||
        (filter === "active" && item.enabled && !item.hidden) ||
        (filter === "hidden" && item.hidden) ||
        (filter === "paused" && !item.enabled);

      return matchesKeyword && matchesFilter;
    });
  }, [filter, keyword, products]);

  useEffect(() => {
    if (filteredProducts.length === 0) {
      setSelectedId(null);
      return;
    }

    const stillExists = filteredProducts.some((item) => item.id === selectedId);
    const [firstProduct] = filteredProducts;
    if (!selectedId || !stillExists) {
      setSelectedId(firstProduct?.id ?? null);
    }
  }, [filteredProducts, selectedId]);

  const selectedProduct = products.find((item) => item.id === selectedId) || null;
  const editorUsesAutoStock =
    Boolean(selectedProduct?.isManual) && editorForm.deliveryText.trim().length > 0;
  const createUsesAutoStock = createForm.deliveryText.trim().length > 0;

  const inventoryQuery = useQuery<ProductInventory>({
    queryKey: ["products", selectedProduct?.id, "inventory"],
    enabled: Boolean(selectedProduct?.isManual),
    queryFn: async () =>
      (await api.get(`/products/${selectedProduct?.id}/inventory`)).data,
  });

  useEffect(() => {
    if (!selectedProduct) {
      setEditorForm(emptyEditorForm);
      return;
    }

    setEditorForm(createEditorForm(selectedProduct));
  }, [selectedProduct]);

  const updateMutation = useMutation({
    mutationFn: async () => {
      if (!selectedProduct) {
        throw new Error("Hãy chọn một sản phẩm trước khi lưu.");
      }

      const displayName = editorForm.displayName.trim();
      if (!displayName) {
        throw new Error("Tên hiển thị không được để trống.");
      }

      const payload: Record<string, unknown> = {
        displayName,
        salePrice: parseRequiredNumber(editorForm.salePrice, "Giá bán"),
        hidden: editorForm.hidden,
        enabled: editorForm.enabled,
        promoText: editorForm.promoText.trim(),
      };

      if (selectedProduct.isManual) {
        payload.sourceName = editorForm.sourceName.trim() || displayName;
        payload.sourceDescription = editorForm.sourceDescription.trim();
        payload.sourcePrice = parseRequiredNumber(editorForm.sourcePrice, "Chi phí nội bộ");
        payload.deliveryText = editorForm.deliveryText.trim();

        if (!editorUsesAutoStock) {
          const available = parseOptionalInteger(editorForm.available, "Tồn kho");
          if (available !== undefined) {
            payload.available = available;
          }
        }
      }

      return api.put(`/products/${selectedProduct.id}`, payload);
    },
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["products"] }),
        queryClient.invalidateQueries({ queryKey: ["products", selectedProduct?.id, "inventory"] }),
      ]);
      showToast({
        tone: "success",
        message: "Đã lưu cấu hình sản phẩm.",
      });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getErrorMessage(error, "Không thể lưu thay đổi cho sản phẩm này."),
      });
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const displayName = createForm.displayName.trim();
      if (!displayName) {
        throw new Error("Tên sản phẩm riêng không được để trống.");
      }

      const payload: Record<string, unknown> = {
        displayName,
        sourceName: createForm.sourceName.trim() || displayName,
        sourceDescription: createForm.sourceDescription.trim(),
        salePrice: parseRequiredNumber(createForm.salePrice, "Giá bán"),
        sourcePrice: parseRequiredNumber(createForm.sourcePrice, "Chi phí nội bộ"),
        promoText: createForm.promoText.trim(),
        deliveryText: createForm.deliveryText.trim(),
        hidden: createForm.hidden,
        enabled: createForm.enabled,
      };

      if (!createUsesAutoStock) {
        const available = parseOptionalInteger(createForm.available, "Tồn kho");
        if (available !== undefined) {
          payload.available = available;
        }
      }

      return api.post<Product>("/products/manual", payload);
    },
    onSuccess: async (response) => {
      await queryClient.invalidateQueries({ queryKey: ["products"] });
      setCreateForm(emptyManualForm);
      setSelectedId(response.data.id);
      setExpandedEditorProductId(response.data.id);
      setActivePanel("edit");
      showToast({
        tone: "success",
        message: `Đã tạo sản phẩm riêng "${response.data.displayName}". Bạn có thể chỉnh tiếp ngay ở bên dưới.`,
      });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getErrorMessage(error, "Không thể tạo sản phẩm riêng lúc này."),
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (productId: string) => api.delete(`/products/${productId}`),
    onSuccess: async (_, productId) => {
      await queryClient.invalidateQueries({ queryKey: ["products"] });
      if (selectedId === productId) {
        setSelectedId(null);
      }
      if (expandedEditorProductId === productId) {
        setExpandedEditorProductId(null);
      }
      if (expandedInventoryProductId === productId) {
        setExpandedInventoryProductId(null);
      }
      showToast({
        tone: "success",
        message: "Đã xóa sản phẩm riêng khỏi shop.",
      });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getErrorMessage(
          error,
          "Không thể xóa sản phẩm này. Nếu đã có đơn phát sinh, hãy ẩn hoặc tắt bán thay vì xóa.",
        ),
      });
    },
  });

  const purgeDeliveredMutation = useMutation({
    mutationFn: async (entryKeys?: string[]) =>
      (
        await api.post<ProductInventory>(
          `/products/${selectedProduct?.id}/inventory/purge-delivered`,
          entryKeys && entryKeys.length > 0 ? { entryKeys } : {},
        )
      ).data,
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["products", selectedProduct?.id, "inventory"] }),
        queryClient.invalidateQueries({ queryKey: ["products"] }),
      ]);
      showToast({
        tone: "success",
        message: "Đã dọn dữ liệu tài khoản đã giao khỏi màn quản lý sản phẩm.",
      });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getErrorMessage(error, "Không thể dọn dữ liệu tài khoản đã giao."),
      });
    },
  });

  const activeCount = products.filter((item) => item.enabled && !item.hidden).length;
  const hiddenCount = products.filter((item) => item.hidden).length;
  const manualCount = products.filter((item) => item.isManual).length;
  const pausedCount = products.filter((item) => !item.enabled).length;
  const totalSales = products.reduce((sum, item) => sum + Number(item.soldCount || 0), 0);
  const sourceCount = Math.max(products.length - manualCount, 0);
  const visibleCount = filteredProducts.length;
  const manualInventory = inventoryQuery.data;

  const filters: { value: ProductFilter; label: string }[] = [
    { value: "all", label: "Tất cả" },
    { value: "manual", label: "Sản phẩm riêng" },
    { value: "active", label: "Đang bán" },
    { value: "hidden", label: "Ẩn trên bot" },
    { value: "paused", label: "Tạm dừng" },
  ];

  const renderSelectedProductEditor = () => {
    if (!selectedProduct) {
      return null;
    }

    return (
      <div className="space-y-6 border-t border-white/8 px-4 pb-4 pt-5 lg:px-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-[22px] border border-white/8 bg-white/[0.03] p-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
              Tồn kho
            </p>
            <p className="mt-3 text-2xl font-semibold text-white">
              {selectedProduct.available ?? "∞"}
            </p>
          </div>
          <div className="rounded-[22px] border border-white/8 bg-white/[0.03] p-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
              Đã bán
            </p>
            <p className="mt-3 text-2xl font-semibold text-white">{selectedProduct.soldCount}</p>
          </div>
          <div className="rounded-[22px] border border-white/8 bg-white/[0.03] p-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
              Lợi nhuận ước tính
            </p>
            <p className="mt-3 text-2xl font-semibold text-white">
              {formatCurrency(Number(editorForm.salePrice || 0) - Number(editorForm.sourcePrice || 0))}
            </p>
          </div>
        </div>

        <Field label="Tên hiển thị" hint="Tên trên bot">
          <StudioInput
            placeholder="Tên công khai hiển thị cho khách"
            value={editorForm.displayName}
            onChange={(event) =>
              setEditorForm((current) => ({ ...current, displayName: event.target.value }))
            }
          />
        </Field>

        <Field label="Giá bán" hint="VND">
          <StudioInput
            placeholder="Giá bán cho khách"
            value={editorForm.salePrice}
            onChange={(event) =>
              setEditorForm((current) => ({ ...current, salePrice: event.target.value }))
            }
          />
        </Field>

        {selectedProduct.isManual ? (
          <>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Tên nội bộ" hint="Nguồn shop">
                <StudioInput
                  placeholder="Tên dùng để quản trị nội bộ"
                  value={editorForm.sourceName}
                  onChange={(event) =>
                    setEditorForm((current) => ({
                      ...current,
                      sourceName: event.target.value,
                    }))
                  }
                />
              </Field>

              <Field
                label="Tồn kho"
                hint={editorUsesAutoStock ? "Tự tính" : "Tùy chọn"}
                description={
                  editorUsesAutoStock
                    ? "Đang tự tính theo danh sách account ở phần nội dung giao tự động. Muốn tăng hoặc giảm kho, hãy thêm hoặc bớt account bên dưới."
                    : "Để trống nếu đây là gói không giới hạn. Nhập 0 nếu muốn báo hết hàng."
                }
              >
                <StudioInput
                  disabled={editorUsesAutoStock}
                  placeholder={editorUsesAutoStock ? "Kho tự tính theo account" : "Ví dụ: 15"}
                  value={editorForm.available}
                  onChange={(event) =>
                    setEditorForm((current) => ({
                      ...current,
                      available: event.target.value,
                    }))
                  }
                />
              </Field>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field
                label="Chi phí nội bộ"
                hint="Tùy chọn"
                description="Dùng để theo dõi lợi nhuận trong shop. Có thể để 0."
              >
                <StudioInput
                  placeholder="Mặc định có thể để 0"
                  value={editorForm.sourcePrice}
                  onChange={(event) =>
                    setEditorForm((current) => ({
                      ...current,
                      sourcePrice: event.target.value,
                    }))
                  }
                />
              </Field>

              <Field
                label="Mô tả nội bộ"
                hint="Tùy chọn"
                description="Dùng để phân biệt các gói riêng hoặc lưu ghi chú ngắn."
              >
                <StudioInput
                  placeholder="Ví dụ: combo giao bằng text"
                  value={editorForm.sourceDescription}
                  onChange={(event) =>
                    setEditorForm((current) => ({
                      ...current,
                      sourceDescription: event.target.value,
                    }))
                  }
                />
              </Field>
            </div>

            <Field
              label="Nội dung giao tự động"
              hint="Manual delivery"
              description="Mỗi dòng là một tài khoản. Ví dụ: email | mật khẩu. Nếu có sẵn dữ liệu cũ dạng JSON thì hệ thống vẫn đọc được."
            >
              <StudioTextArea
                placeholder={"Ví dụ:\nbtceuhocdt@nyawit.id | Premium@123\nabc@gmail.com | Pass456\nxyz@mail.com | Pass789"}
                value={editorForm.deliveryText}
                onChange={(event) =>
                  setEditorForm((current) => ({
                    ...current,
                    deliveryText: event.target.value,
                  }))
                }
              />
            </Field>
          </>
        ) : (
          <div className="rounded-[22px] border border-white/8 bg-white/[0.03] p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-[16px] border border-white/8 bg-slate-950/45 text-slate-200">
                  <Wallet className="h-4.5 w-4.5" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Giá nguồn hiện tại</p>
                  <p className="mt-1 text-sm text-slate-400">
                    Sản phẩm đồng bộ chỉ cho phép đổi tên hiển thị, giá bán và trạng thái.
                  </p>
                </div>
              </div>
              <p className="text-2xl font-semibold text-white">
                {formatCurrency(selectedProduct.sourcePrice)}
              </p>
            </div>
          </div>
        )}

        <Field
          label="Thông điệp khuyến mại"
          hint="Tùy chọn"
          description="Thêm ghi chú ngắn về bảo hành, ưu đãi hoặc lời nhấn giúp tăng chuyển đổi."
        >
          <StudioTextArea
            placeholder="Ví dụ: Bảo hành nhanh, hỗ trợ cài đặt hoặc quà tặng kèm."
            value={editorForm.promoText}
            onChange={(event) =>
              setEditorForm((current) => ({ ...current, promoText: event.target.value }))
            }
          />
        </Field>

        <div className="grid gap-3 sm:grid-cols-2">
          <button
            className={`rounded-[22px] border p-4 text-left transition ${
              editorForm.enabled
                ? "border-emerald-400/18 bg-emerald-500/10"
                : "border-white/8 bg-white/[0.03] hover:bg-white/[0.05]"
            }`}
            onClick={() => setEditorForm((current) => ({ ...current, enabled: !current.enabled }))}
            type="button"
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-white">Cho phép bán</p>
                <p className="mt-1 text-sm leading-6 text-slate-400">
                  Bật hoặc tắt khả năng mua sản phẩm này trên bot.
                </p>
              </div>
              <StudioBadge tone={editorForm.enabled ? "success" : "neutral"}>
                {editorForm.enabled ? "Bật" : "Tắt"}
              </StudioBadge>
            </div>
          </button>

          <button
            className={`rounded-[22px] border p-4 text-left transition ${
              editorForm.hidden
                ? "border-emerald-300/18 bg-emerald-400/10"
                : "border-white/8 bg-white/[0.03] hover:bg-white/[0.05]"
            }`}
            onClick={() => setEditorForm((current) => ({ ...current, hidden: !current.hidden }))}
            type="button"
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold text-white">Ẩn trên bot</p>
                <p className="mt-1 text-sm leading-6 text-slate-400">
                  Giữ trong catalog nhưng tạm thời gỡ khỏi menu công khai.
                </p>
              </div>
              <StudioBadge tone={editorForm.hidden ? "warning" : "neutral"}>
                {editorForm.hidden ? "Ẩn" : "Hiện"}
              </StudioBadge>
            </div>
          </button>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row">
          <StudioButton
            className="min-h-[56px] flex-1"
            disabled={updateMutation.isPending || !selectedProduct}
            onClick={() => updateMutation.mutate()}
          >
            <Save className="h-4.5 w-4.5" />
            {updateMutation.isPending ? "Đang lưu..." : "Lưu cấu hình sản phẩm"}
          </StudioButton>

          {selectedProduct.isManual ? (
            <StudioButton
              className="min-h-[56px]"
              disabled={deleteMutation.isPending}
              variant="danger"
              onClick={() => {
                const confirmed = window.confirm(
                  `Xóa sản phẩm riêng "${selectedProduct.displayName}" khỏi shop?`,
                );

                if (confirmed) {
                  deleteMutation.mutate(selectedProduct.id);
                }
              }}
            >
              <Trash2 className="h-4.5 w-4.5" />
              {deleteMutation.isPending ? "Đang xóa..." : "Xóa sản phẩm"}
            </StudioButton>
          ) : null}
        </div>
      </div>
    );
  };

  return (
      <div className="space-y-6">
        <StudioSectionIntro
          kicker="Điều phối catalog"
          title="Sản phẩm nguồn và sản phẩm riêng"
          description="CTV có thể vừa bán catalog đồng bộ từ bot nguồn, vừa tự tạo các gói riêng để bán trực tiếp trên bot của mình."
          titleClassName="max-w-3xl"
          descriptionClassName="max-w-3xl"
          actions={
            <>
              <StudioButton
              onClick={() => {
                setActivePanel("create");
              }}
            >
              <PackagePlus className="h-4 w-4" />
              Tạo sản phẩm riêng
            </StudioButton>
            <StudioButton
              disabled={productsQuery.isFetching}
              variant="secondary"
              onClick={() => {
                void productsQuery.refetch();
              }}
            >
              <RefreshCw className="h-4 w-4" />
              {productsQuery.isFetching ? "Đang làm mới..." : "Làm mới catalog"}
            </StudioButton>
          </>
        }
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StudioMetric
          label="Tổng sản phẩm"
          value={String(products.length)}
          description={`Trong đó có ${sourceCount} sản phẩm nguồn và ${manualCount} sản phẩm riêng.`}
          icon={Boxes}
          tone="sky"
        />
        <StudioMetric
          label="Sản phẩm riêng"
          value={String(manualCount)}
          description="Những gói do chính CTV tự tạo và chủ động giao tài khoản hoặc xử lý tay."
          icon={PackagePlus}
          tone="amber"
        />
        <StudioMetric
          label="Đang bán"
          value={String(activeCount)}
          description={`${hiddenCount} sản phẩm đang ẩn và ${pausedCount} sản phẩm đang tạm dừng.`}
          icon={BarChart3}
          tone="emerald"
        />
        <StudioMetric
          label="Đã bán"
          value={String(totalSales)}
          description={`Tổng lượt bán toàn catalog hiện là ${totalSales}.`}
          icon={Package}
          tone="violet"
        />
      </section>

      <section className="space-y-6">
        <StudioCard className="overflow-hidden p-0">
          <div className="border-b border-white/8 px-5 py-5 sm:px-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Danh sách sản phẩm
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-white">Catalog đang hoạt động</h2>
                <p className="mt-2 text-sm text-slate-400">
                  Chọn một sản phẩm để chỉnh nhanh giá bán, trạng thái hiển thị và nội dung giao.
                </p>
              </div>

              <div className="w-full max-w-sm space-y-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                  <StudioInput
                    className="pl-11"
                    placeholder="Tìm theo tên hiển thị hoặc tên nguồn"
                    value={keyword}
                    onChange={(event) => setKeyword(event.target.value)}
                  />
                </div>
                <p className="text-right text-xs text-slate-500">
                  Đang hiển thị {visibleCount}/{products.length} sản phẩm
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              {filters.map((item) => (
                <StudioButton
                  key={item.value}
                  size="sm"
                  type="button"
                  variant={filter === item.value ? "primary" : "secondary"}
                  onClick={() => setFilter(item.value)}
                >
                  {item.label}
                </StudioButton>
              ))}
              {(keyword || filter !== "all") && (
                <StudioButton
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setKeyword("");
                    setFilter("all");
                  }}
                >
                  Xóa lọc
                </StudioButton>
              )}
            </div>
          </div>

          <div className="px-4 py-4 sm:px-6">
            {productsQuery.isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, index) => (
                  <div
                    key={index}
                    className="h-[104px] animate-pulse rounded-[22px] border border-white/8 bg-white/[0.03]"
                  />
                ))}
              </div>
            ) : productsQuery.isError ? (
              <div className="rounded-[24px] border border-rose-400/18 bg-rose-500/10 px-6 py-12 text-center">
                <p className="text-lg font-semibold text-white">Không tải được danh sách sản phẩm</p>
                <p className="mt-2 text-sm leading-7 text-rose-100/90">
                  {getErrorMessage(productsQuery.error, "Hãy thử tải lại catalog sau ít phút nữa.")}
                </p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="rounded-[24px] border border-dashed border-white/10 bg-white/[0.03] px-6 py-12 text-center">
                <p className="text-lg font-semibold text-white">Chưa có sản phẩm phù hợp</p>
                <p className="mt-2 text-sm leading-7 text-slate-400">
                  Hãy đổi bộ lọc hoặc thêm sản phẩm riêng cho shop ở cột bên phải.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredProducts.map((product) => {
                  const isSelected = product.id === selectedId;

                  return (
                    <div
                      key={product.id}
                      className={`w-full rounded-[22px] border p-4 text-left transition-[border-color,background-color,box-shadow,transform] duration-300 ease-out lg:p-5 ${
                        isSelected
                          ? "border-white/12 bg-[linear-gradient(180deg,rgba(16,20,28,0.98),rgba(11,14,20,0.98))] shadow-[0_16px_30px_rgba(0,0,0,0.28)]"
                          : "border-white/8 bg-white/[0.03] hover:border-white/12 hover:bg-white/[0.05]"
                      }`}
                    >
                      <button
                        className="w-full text-left"
                        onClick={() => {
                          setSelectedId(product.id);
                          setActivePanel("edit");
                        }}
                        type="button"
                      >
                        <div className="flex flex-col gap-4 xl:grid xl:grid-cols-[minmax(0,1.6fr)_auto_auto] xl:items-center">
                          <div className="min-w-0">
                            <div className="flex items-start gap-3">
                              <div
                                className={`mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-[16px] border ${
                                  isSelected
            ? "border-emerald-300/18 bg-emerald-400/10 text-emerald-100"
                                    : "border-white/8 bg-slate-950/45 text-slate-200"
                                }`}
                              >
                                <Package className="h-4.5 w-4.5" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                  <p className="truncate text-base font-semibold text-white">
                                    {product.displayName}
                                  </p>
                                  <StudioBadge tone={product.isManual ? "warning" : "neutral"}>
                                    {product.isManual ? "Sản phẩm riêng" : "Đồng bộ nguồn"}
                                  </StudioBadge>
                                  {!product.enabled ? (
                                    <StudioBadge tone="neutral">Tạm dừng</StudioBadge>
                                  ) : null}
                                  {product.hidden ? (
                                    <StudioBadge tone="warning">Ẩn trên bot</StudioBadge>
                                  ) : null}
                                </div>
                                <p className="mt-1 truncate text-sm text-slate-500">
                                  {product.sourceName}
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-2 text-sm min-[520px]:grid-cols-3 xl:w-[260px]">
                            <div className="rounded-[16px] border border-white/8 bg-black/20 px-3 py-2.5">
                              <p className="text-[10px] uppercase tracking-[0.16em] text-slate-500">
                                Giá bán
                              </p>
                              <p className="mt-1 font-semibold text-white">
                                {formatCurrency(product.salePrice)}
                              </p>
                            </div>
                            <div className="rounded-[16px] border border-white/8 bg-black/20 px-3 py-2.5">
                              <p className="text-[10px] uppercase tracking-[0.16em] text-slate-500">
                                Tồn
                              </p>
                              <p className="mt-1 font-medium text-slate-200">
                                {product.available ?? "∞"}
                              </p>
                            </div>
                            <div className="rounded-[16px] border border-white/8 bg-black/20 px-3 py-2.5">
                              <p className="text-[10px] uppercase tracking-[0.16em] text-slate-500">
                                Đã bán
                              </p>
                              <p className="mt-1 font-medium text-slate-200">{product.soldCount}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 xl:justify-end">
                            <p className="text-xs font-medium text-slate-500">
                              {product.isManual
                                ? "CTV tự quản lý"
                                : `Giá nguồn ${formatCurrency(product.sourcePrice)}`}
                            </p>
                          </div>
                        </div>
                      </button>

                      {isSelected ? (
                        <>
                          <div className="mt-4 border-t border-white/8 pt-4">
                            <div className="flex items-center justify-between gap-3">
                              <p className="text-sm text-slate-400">
                                {product.isManual
                                  ? "Sản phẩm riêng cho phép xổ chỉnh sửa và kho account ngay trên card này."
                                  : "Sản phẩm nguồn cho phép xổ khung chỉnh sửa ngay trên card này."}
                              </p>
                              <div className="flex flex-wrap gap-2">
                                <StudioButton
                                  size="sm"
                                  variant="secondary"
                                  onClick={() =>
                                    setExpandedEditorProductId((current) =>
                                      current === product.id ? null : product.id,
                                    )
                                  }
                                >
                                  {expandedEditorProductId === product.id ? (
                                    <>
                                      <ChevronUp className="h-4 w-4" />
                                      Thu gọn chỉnh sửa
                                    </>
                                  ) : (
                                    <>
                                      <ChevronDown className="h-4 w-4" />
                                      Chỉnh sản phẩm
                                    </>
                                  )}
                                </StudioButton>

                                {product.isManual ? (
                                  <StudioButton
                                    size="sm"
                                    variant="secondary"
                                    onClick={() =>
                                      setExpandedInventoryProductId((current) =>
                                        current === product.id ? null : product.id,
                                      )
                                    }
                                  >
                                    {expandedInventoryProductId === product.id ? (
                                      <>
                                        <ChevronUp className="h-4 w-4" />
                                        Thu gọn kho account
                                      </>
                                    ) : (
                                      <>
                                        <ChevronDown className="h-4 w-4" />
                                        Xem kho account
                                      </>
                                    )}
                                  </StudioButton>
                                ) : null}
                              </div>
                            </div>
                          </div>

                          <div
                            className={`grid transition-[grid-template-rows,opacity,margin] duration-300 ease-out ${
                              expandedEditorProductId === product.id
                                ? "mt-2 grid-rows-[1fr] opacity-100"
                                : "grid-rows-[0fr] opacity-0"
                            }`}
                          >
                            <div className="min-h-0 overflow-hidden">
                              <div
                                className={`transition-[opacity,transform] duration-300 ease-out ${
                                  expandedEditorProductId === product.id
                                    ? "translate-y-0 opacity-100"
                                    : "-translate-y-2 opacity-0"
                                }`}
                              >
                                {renderSelectedProductEditor()}
                              </div>
                            </div>
                          </div>

                          <div
                            className={`grid transition-[grid-template-rows,opacity,margin] duration-300 ease-out ${
                              expandedInventoryProductId === product.id
                                ? "mt-2 grid-rows-[1fr] opacity-100"
                                : "grid-rows-[0fr] opacity-0"
                            }`}
                          >
                            <div className="min-h-0 overflow-hidden">
                              <div
                                className={`transition-[opacity,transform] duration-300 ease-out ${
                                  expandedInventoryProductId === product.id
                                    ? "translate-y-0 opacity-100"
                                    : "-translate-y-2 opacity-0"
                                }`}
                              >
                                <ManualInventoryPanel
                                  inventory={manualInventory}
                                  isLoading={inventoryQuery.isLoading}
                                  isPurging={purgeDeliveredMutation.isPending}
                                  onPurgeAll={() => {
                                    const confirmed = window.confirm(
                                      "Xóa nhanh toàn bộ account đã giao khỏi màn quản lý sản phẩm này?",
                                    );

                                    if (confirmed) {
                                      purgeDeliveredMutation.mutate(undefined);
                                    }
                                  }}
                                  onPurgeOne={(entryKey) => {
                                    purgeDeliveredMutation.mutate([entryKey]);
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </StudioCard>

        <div className="space-y-4">
          <StudioCard className="p-4">
            <div className="flex flex-wrap gap-2">
              <StudioButton
                size="sm"
                variant={activePanel === "create" ? "primary" : "secondary"}
                onClick={() => {
                  setActivePanel((current) => (current === "create" ? "edit" : "create"));
                }}
              >
                <PackagePlus className="h-4 w-4" />
                {activePanel === "create" ? "Thu gọn tạo sản phẩm riêng" : "Tạo sản phẩm riêng"}
              </StudioButton>
            </div>
          </StudioCard>

          {activePanel === "create" ? (
            <StudioCard>
            <div className="space-y-6">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Tự tạo catalog riêng
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-white">Tạo sản phẩm của shop</h2>
                <p className="mt-2 text-sm leading-7 text-slate-400">
                  Chỉ hiện phần cần thiết để bạn lên nhanh một gói riêng, combo nội bộ hoặc sản
                  phẩm không nằm trong catalog nguồn.
                </p>
              </div>

              <Field label="Tên hiển thị" hint="Bắt buộc">
                <StudioInput
                  placeholder="Ví dụ: Combo Canva + ChatGPT 30 ngày"
                  value={createForm.displayName}
                  onChange={(event) =>
                    setCreateForm((current) => ({ ...current, displayName: event.target.value }))
                  }
                />
              </Field>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Giá bán" hint="VND">
                  <StudioInput
                    placeholder="Giá bán cho khách"
                    value={createForm.salePrice}
                    onChange={(event) =>
                      setCreateForm((current) => ({ ...current, salePrice: event.target.value }))
                    }
                  />
                </Field>

                <Field
                  label="Chi phí nội bộ"
                  hint="Tùy chọn"
                  description="Dùng để theo dõi lợi nhuận trong shop. Có thể để 0."
                >
                  <StudioInput
                    placeholder="Mặc định có thể để 0"
                    value={createForm.sourcePrice}
                    onChange={(event) =>
                      setCreateForm((current) => ({ ...current, sourcePrice: event.target.value }))
                    }
                  />
                </Field>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field
                  label="Tên nội bộ"
                  hint="Tùy chọn"
                  description="Nếu bỏ trống, hệ thống sẽ dùng luôn tên hiển thị."
                >
                  <StudioInput
                    placeholder="Tên riêng để quản trị nội bộ"
                    value={createForm.sourceName}
                    onChange={(event) =>
                      setCreateForm((current) => ({ ...current, sourceName: event.target.value }))
                    }
                  />
                </Field>

                <Field
                  label="Tồn kho"
                  hint={createUsesAutoStock ? "Tự tính" : "Tùy chọn"}
                  description={
                    createUsesAutoStock
                      ? "Đang tự tính theo danh sách account ở phần nội dung giao tự động. Nếu muốn nhập kho tay thì để trống phần auto-giao."
                      : "Để trống nếu không muốn giới hạn. Nhập 0 nếu muốn tạo sẵn nhưng chưa bán."
                  }
                >
                  <StudioInput
                    disabled={createUsesAutoStock}
                    placeholder={createUsesAutoStock ? "Kho tự tính theo account" : "Ví dụ: 10"}
                    value={createForm.available}
                    onChange={(event) =>
                      setCreateForm((current) => ({ ...current, available: event.target.value }))
                    }
                  />
                </Field>
              </div>

              <Field
                label="Mô tả nội bộ"
                hint="Tùy chọn"
                description="Có thể dùng để ghi loại tài khoản, nguồn giao hoặc quy cách gói."
              >
                <StudioInput
                  placeholder="Ví dụ: giao bằng text, xử lý thủ công"
                  value={createForm.sourceDescription}
                  onChange={(event) =>
                    setCreateForm((current) => ({
                      ...current,
                      sourceDescription: event.target.value,
                    }))
                  }
                />
              </Field>

              <Field
                label="Thông điệp khuyến mại"
                hint="Tùy chọn"
                description="Xuất hiện cùng sản phẩm để tăng tỷ lệ chốt đơn."
              >
                <StudioTextArea
                  placeholder="Ví dụ: hỗ trợ đổi lỗi nhanh trong 24h."
                  value={createForm.promoText}
                  onChange={(event) =>
                    setCreateForm((current) => ({ ...current, promoText: event.target.value }))
                  }
                />
              </Field>

                <Field
                  label="Nội dung giao tự động"
                  hint="Manual delivery"
                  description="Mỗi dòng là một tài khoản. Ví dụ: email | mật khẩu. Nếu có sẵn dữ liệu cũ dạng JSON thì hệ thống vẫn đọc được."
                >
                  <StudioTextArea
                    placeholder={"Ví dụ:\nbtceuhocdt@nyawit.id | Premium@123\nabc@gmail.com | Pass456\nxyz@mail.com | Pass789"}
                    value={createForm.deliveryText}
                    onChange={(event) =>
                      setCreateForm((current) => ({
                      ...current,
                      deliveryText: event.target.value,
                    }))
                  }
                />
              </Field>

              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  className={`rounded-[22px] border p-4 text-left transition ${
                    createForm.enabled
                      ? "border-emerald-400/18 bg-emerald-500/10"
                      : "border-white/8 bg-white/[0.03] hover:bg-white/[0.05]"
                  }`}
                  onClick={() =>
                    setCreateForm((current) => ({ ...current, enabled: !current.enabled }))
                  }
                  type="button"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-white">Cho phép bán</p>
                      <p className="mt-1 text-sm leading-6 text-slate-400">
                        Tạo sản phẩm ở trạng thái mở bán ngay sau khi lưu.
                      </p>
                    </div>
                    <StudioBadge tone={createForm.enabled ? "success" : "neutral"}>
                      {createForm.enabled ? "Bật" : "Tắt"}
                    </StudioBadge>
                  </div>
                </button>

                <button
                  className={`rounded-[22px] border p-4 text-left transition ${
                    createForm.hidden
                      ? "border-emerald-300/18 bg-emerald-400/10"
                      : "border-white/8 bg-white/[0.03] hover:bg-white/[0.05]"
                  }`}
                  onClick={() =>
                    setCreateForm((current) => ({ ...current, hidden: !current.hidden }))
                  }
                  type="button"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-white">Ẩn trên bot</p>
                      <p className="mt-1 text-sm leading-6 text-slate-400">
                        Tạo sẵn trong catalog nhưng chưa hiển thị công khai cho khách.
                      </p>
                    </div>
                    <StudioBadge tone={createForm.hidden ? "warning" : "neutral"}>
                      {createForm.hidden ? "Ẩn" : "Hiện"}
                    </StudioBadge>
                  </div>
                </button>
              </div>

              <Notice tone="warning">
                Nếu điền nội dung giao tự động, hệ thống sẽ coi mỗi dòng là một account và tự trừ
                dần sau mỗi đơn. Nếu để trống, đơn manual sẽ chuyển sang chờ seller xử lý thủ công.
              </Notice>

              <StudioButton
                className="min-h-[56px] w-full"
                disabled={createMutation.isPending}
                onClick={() => createMutation.mutate()}
              >
                <PackagePlus className="h-4.5 w-4.5" />
                {createMutation.isPending ? "Đang tạo sản phẩm..." : "Tạo sản phẩm riêng"}
              </StudioButton>
            </div>
          </StudioCard>
          ) : null}
        </div>
      </section>
    </div>
  );
}
