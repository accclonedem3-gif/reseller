// @ts-nocheck
import { ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Navigate } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function LoginPage() {
  const { login, register, session } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("seller@example.com");
  const [password, setPassword] = useState("Seller123!");
  const [displayName, setDisplayName] = useState("Seller mẫu");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (session) {
    return <Navigate to="/" replace />;
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register(email, password, displayName);
      }
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể đăng nhập.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden px-4 py-6 sm:px-6 lg:px-8">
      <div className="orbital-dot left-[8%] top-[12%] h-28 w-28 bg-cyan-300/18" />
      <div
        className="orbital-dot right-[12%] top-[18%] h-20 w-20 bg-amber-300/18"
        style={{ animationDelay: "1.4s" }}
      />
      <div
        className="orbital-dot bottom-[16%] right-[18%] h-24 w-24 bg-emerald-300/12"
        style={{ animationDelay: "2.1s" }}
      />

      <div className="mx-auto grid min-h-[calc(100vh-3rem)] max-w-7xl items-center gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="reveal-up space-y-8 px-2 sm:px-4">
          <div className="glass-chip inline-flex items-center gap-2 rounded-full px-4 py-2 text-[11px] uppercase tracking-[0.3em] text-slate-100">
            <Sparkles className="h-3.5 w-3.5" />
            Seller operations layer
          </div>

          <div className="space-y-5">
            <h1 className="max-w-3xl text-balance font-display text-5xl font-semibold tracking-tight text-white sm:text-6xl xl:text-7xl">
              Giao diện seller mới, sắc nét và sẵn sàng vận hành bot bán hàng thật.
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-slate-300">
              Quản lý Telegram bot, catalog nguồn, wallet ledger, đơn hàng và broadcast trong một
              không gian làm việc chuyên nghiệp hơn, dễ đọc hơn và bám sát flow reseller thực tế.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <FeatureCard
              icon={Bot}
              title="Bot theo từng seller"
              description="Seller chỉ nhập BOT_TOKEN và buyer key, phần verify và orchestration để hệ thống lo."
            />
            <FeatureCard
              icon={PackageCheck}
              title="Catalog studio"
              description="Sync sản phẩm, chỉnh giá, đổi tên hiển thị và đóng mở từng mặt hàng từ dashboard."
            />
            <FeatureCard
              icon={CreditCard}
              title="Wallet có ledger"
              description="Bút toán nạp, trừ, hoàn và rút được lưu đầy đủ để seller kiểm soát tài chính."
            />
            <FeatureCard
              icon={RadioTower}
              title="Flow tự động"
              description="Payment, purchase upstream, queue worker và giao account kết nối thành một mạch."
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div className="glass-chip rounded-[24px] p-4">
              <p className="app-kicker">Auth</p>
              <p className="mt-3 text-xl font-semibold text-white">JWT + refresh</p>
            </div>
            <div className="glass-chip rounded-[24px] p-4">
              <p className="app-kicker">Infra</p>
              <p className="mt-3 text-xl font-semibold text-white">API + worker + web</p>
            </div>
            <div className="glass-chip rounded-[24px] p-4">
              <p className="app-kicker">Mode</p>
              <p className="mt-3 text-xl font-semibold text-white">Local smoke ready</p>
            </div>
          </div>
        </section>

        <section className="reveal-up reveal-delay-1">
          <Card className="overflow-hidden p-0">
            <div className="grid lg:grid-cols-[0.42fr_0.58fr]">
              <div className="border-b border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.06),rgba(255,255,255,0.02))] p-6 lg:border-b-0 lg:border-r">
                <div className="glass-chip inline-flex h-12 w-12 items-center justify-center rounded-2xl text-white">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <h2 className="mt-5 font-display text-3xl font-semibold text-white">
                  Truy cập dashboard
                </h2>
                <p className="mt-3 text-sm leading-7 text-slate-400">
                  Dùng tài khoản demo đã seed sẵn hoặc tạo seller mới ngay trong local environment.
                </p>

                <div className="mt-8 space-y-4">
                  <div className="glass-chip rounded-[22px] p-4">
                    <p className="app-kicker">Demo seller</p>
                    <p className="mt-3 font-semibold text-white">seller@example.com</p>
                    <p className="mt-1 text-sm text-slate-400">Seller123!</p>
                  </div>
                  <div className="glass-chip rounded-[22px] p-4">
                    <p className="app-kicker">Workflow</p>
                    <p className="mt-3 text-sm leading-7 text-slate-300">
                      Sau khi vào hệ thống, seller có thể cấu hình bot, sync catalog, chỉnh giá, theo dõi order và gửi broadcast.
                    </p>
                  </div>
                  <div className="glass-chip rounded-[22px] p-4">
                    <div className="flex items-center gap-2 text-slate-200">
                      <Workflow className="h-4 w-4 text-cyan-100" />
                      <span className="text-sm">Smoke flow</span>
                    </div>
                    <p className="mt-3 text-sm leading-7 text-slate-300">
                      Mock provider, mock payment và Telegram sandbox đều đã sẵn để test end-to-end.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-6 sm:p-7">
                <div className="mb-6 flex gap-2 rounded-[22px] border border-white/10 bg-white/[0.04] p-1">
                  <button
                    className={`flex-1 rounded-[18px] px-4 py-3 text-sm font-semibold transition ${
                      mode === "login"
                        ? "bg-white text-slate-950 shadow-[0_16px_36px_rgba(15,23,42,0.18)]"
                        : "text-slate-400 hover:text-white"
                    }`}
                    onClick={() => setMode("login")}
                    type="button"
                  >
                    Đăng nhập
                  </button>
                  <button
                    className={`flex-1 rounded-[18px] px-4 py-3 text-sm font-semibold transition ${
                      mode === "register"
                        ? "bg-white text-slate-950 shadow-[0_16px_36px_rgba(15,23,42,0.18)]"
                        : "text-slate-400 hover:text-white"
                    }`}
                    onClick={() => setMode("register")}
                    type="button"
                  >
                    Tạo seller
                  </button>
                </div>

                <form className="space-y-5" onSubmit={handleSubmit}>
                  <Field label="Email" hint="Required">
                    <Input value={email} onChange={(event) => setEmail(event.target.value)} />
                  </Field>

                  <Field label="Mật khẩu" hint="Required">
                    <Input
                      type="password"
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                    />
                  </Field>

                  {mode === "register" ? (
                    <Field label="Tên seller / shop" hint="Required">
                      <Input
                        value={displayName}
                        onChange={(event) => setDisplayName(event.target.value)}
                      />
                    </Field>
                  ) : null}

                  {error ? (
                    <div className="rounded-[22px] border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                      {error}
                    </div>
                  ) : null}

                  <Button className="w-full" disabled={loading} size="lg" type="submit">
                    {loading
                      ? "Đang xử lý..."
                      : mode === "login"
                        ? "Vào dashboard"
                        : "Khởi tạo seller mới"}
                  </Button>
                </form>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
}
