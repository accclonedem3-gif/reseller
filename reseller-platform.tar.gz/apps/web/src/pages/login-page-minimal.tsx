import { ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Navigate } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function LoginPageMinimal() {
  const { login, session } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (session) {
    return <Navigate to="/" replace />;
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await login(email, password);
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể đăng nhập.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-stage flex min-h-screen items-center justify-center px-6 py-10">
      <div className="auth-shell w-full max-w-md">
        <div className="mb-10 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22px] border border-white/12 bg-white/[0.06] text-white shadow-[0_24px_50px_rgba(15,23,42,0.26)]">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.34em] text-slate-500">
            Cổng seller
          </p>
          <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight text-white sm:text-[2.7rem]">
            Reseller Platform
          </h1>
          <p className="mx-auto mt-4 max-w-sm text-sm leading-7 text-slate-400">
            Đăng nhập để quản lý bot, sản phẩm, đơn hàng và ví seller trong một không gian
            làm việc tập trung.
          </p>
        </div>

        <div className="auth-panel rounded-[30px] border border-white/10 p-6 shadow-[0_32px_80px_rgba(2,6,23,0.34)] backdrop-blur-xl sm:p-7">
          <form className="space-y-5" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-200" htmlFor="email">
                Email
              </label>
              <Input
                autoComplete="email"
                id="email"
                placeholder="seller@example.com"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <label
                className="block text-sm font-medium text-slate-200"
                htmlFor="password"
              >
                Mật khẩu
              </label>
              <Input
                autoComplete="current-password"
                id="password"
                placeholder="Nhập mật khẩu"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>

            {error ? (
              <div className="rounded-[20px] border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                {error}
              </div>
            ) : null}

            <Button className="w-full" disabled={loading} size="lg" type="submit">
              {loading ? "Đang đăng nhập..." : "Đăng nhập"}
            </Button>
          </form>

          <div className="mt-5 border-t border-white/8 pt-5 text-center text-sm text-slate-500">
            Tài khoản được tạo bởi quản trị viên. Người dùng không thể tự đăng ký công khai.
          </div>
        </div>
      </div>
    </div>
  );
}
