import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  Check,
  CircleDollarSign,
  Copy,
  PackageCheck,
  ShoppingCart,
} from "lucide-react";

import {
  StudioBadge,
  StudioButton,
  StudioCard,
  StudioMetric,
  StudioSectionIntro,
} from "@/components/studio/studio-ui";
import { InfoHint } from "@/components/ui/info-hint";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function statusTone(status: string) {
  if (status === "delivered") return "success" as const;
  if (status === "failed" || status === "refunded") return "danger" as const;
  if (status === "paid_waiting_stock") return "warning" as const;
  return "neutral" as const;
}

export function OrdersPageStudio() {
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const ordersQuery = useQuery({
    queryKey: ["orders"],
    queryFn: async () => (await api.get("/orders")).data,
  });

  const orders = ordersQuery.data || [];
  const confirmManualPaymentMutation = useMutation({
    mutationFn: async (orderId: string) => api.post(`/orders/${orderId}/manual-payment-confirm`),
    onSuccess: async () => {
      showToast({
        tone: "success",
        message: "Đã xác nhận thanh toán USDT và đưa đơn vào luồng xử lý.",
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["orders"] }),
        queryClient.invalidateQueries({ queryKey: ["orders", "pending"] }),
      ]);
    },
    onError: (error: any) => {
      showToast({
        tone: "error",
        message: error?.response?.data?.message || "Không thể xác nhận thanh toán.",
      });
    },
  });
  const paidOrders = orders.filter(
    (item: any) => String(item.paymentStatus || "").toLowerCase() === "paid",
  );
  const deliveredOrders = orders.filter(
    (item: any) => String(item.status || "").toLowerCase() === "delivered",
  );
  const failedOrders = orders.filter((item: any) =>
    ["failed", "refunded"].includes(String(item.status || "").toLowerCase()),
  );

  const handleCopyDelivered = async (orderId: string, deliveredText: string) => {
    try {
      await navigator.clipboard.writeText(deliveredText);
      setCopiedOrderId(orderId);
      window.setTimeout(() => {
        setCopiedOrderId((current) => (current === orderId ? null : current));
      }, 1800);
    } catch {
      setCopiedOrderId(null);
    }
  };

  return (
    <div className="space-y-6">
      <StudioSectionIntro
        kicker="Điều phối đơn hàng"
        title="Toàn bộ giao dịch của seller"
        description="Theo dõi trạng thái thanh toán, tiến độ mua upstream, giao account và các lỗi phát sinh trên cùng một bảng đọc nhanh."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StudioMetric
          label="Tổng số đơn"
          value={String(orders.length)}
          description="Toàn bộ đơn hàng hiện có trong workspace seller."
          icon={ShoppingCart}
          tone="amber"
        />
        <StudioMetric
          label="Đơn đã thanh toán"
          value={String(paidOrders.length)}
          description="Những đơn đã ghi nhận tiền thành công trong hệ thống."
          icon={CircleDollarSign}
          tone="amber"
        />
        <StudioMetric
          label="Đơn đã giao"
          value={String(deliveredOrders.length)}
          description="Các đơn đã hoàn tất luồng giao account cho khách."
          icon={PackageCheck}
          tone="amber"
        />
        <StudioMetric
          label="Đơn lỗi"
          value={String(failedOrders.length)}
          description="Bao gồm lỗi upstream, hoàn tiền và các ca seller cần xử lý."
          icon={AlertTriangle}
          tone="violet"
        />
      </section>

      <StudioCard>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
              Nhật ký đơn hàng
            </p>
            <h2 className="mt-3 text-3xl font-semibold text-white">Bảng theo dõi 100 đơn gần nhất</h2>
          </div>
          <InfoHint
            content="Ưu tiên hiển thị đúng các thông tin seller cần để xử lý nhanh từng đơn."
            label="Xem ghi chú cho Nhật ký đơn hàng"
          />
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="min-w-full border-separate border-spacing-0">
            <thead>
              <tr className="text-left text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">
                <th className="pb-3 pr-4">Mã đơn</th>
                <th className="pb-3 pr-4">Sản phẩm</th>
                <th className="pb-3 pr-4">Khách hàng</th>
                <th className="pb-3 pr-4">Trạng thái</th>
                <th className="pb-3 pr-4">Thanh toán</th>
                <th className="pb-3 pr-4">Tạo lúc</th>
                <th className="pb-3 text-right">Tổng</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order: any) => (
                <tr key={order.id} className="text-sm text-slate-300">
                  <td className="border-t border-white/8 py-4 pr-4 align-top">
                    <p className="font-semibold text-white">{order.orderCode}</p>
                    {order.failureReason ? (
                      <p className="mt-2 max-w-[280px] text-sm leading-6 text-rose-200">
                        {order.failureReason}
                      </p>
                    ) : null}
                    {order.deliveredAccountText ? (
                      <div className="mt-3 max-w-[320px] rounded-[16px] border border-emerald-400/16 bg-emerald-500/8 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-100/90">
                            Tài khoản đã giao
                          </p>
                          <button
                            type="button"
                            className="inline-flex items-center gap-1 rounded-[10px] border border-white/10 bg-[#121A2E] px-2.5 py-1.5 text-xs font-medium text-slate-200 transition hover:border-emerald-300/28 hover:text-white"
                            onClick={() => handleCopyDelivered(order.id, order.deliveredAccountText)}
                          >
                            {copiedOrderId === order.id ? (
                              <>
                                <Check className="h-3.5 w-3.5" />
                                Đã copy
                              </>
                            ) : (
                              <>
                                <Copy className="h-3.5 w-3.5" />
                                Copy
                              </>
                            )}
                          </button>
                        </div>
                        <pre className="mt-3 overflow-x-auto whitespace-pre-wrap break-all rounded-[12px] bg-[#090909] px-3 py-3 text-xs leading-6 text-slate-100">
                          {order.deliveredAccountText}
                        </pre>
                      </div>
                    ) : null}
                  </td>
                  <td className="border-t border-white/8 py-4 pr-4 align-top">
                    <p className="font-medium text-white">{order.productName}</p>
                    <p className="mt-1 text-sm text-slate-500">{order.product?.sourceName || "-"}</p>
                  </td>
                  <td className="border-t border-white/8 py-4 pr-4 align-top">
                    <p>{order.customer?.telegramUsername || order.customer?.name || "-"}</p>
                    <p className="mt-1 text-sm text-slate-500">{order.customer?.telegramUserId || "-"}</p>
                  </td>
                  <td className="border-t border-white/8 py-4 pr-4 align-top">
                    <StudioBadge tone={statusTone(order.status)}>
                      {formatStatusLabel(order.status)}
                    </StudioBadge>
                  </td>
                  <td className="border-t border-white/8 py-4 pr-4 align-top">
                    <StudioBadge
                      tone={
                        String(order.paymentStatus || "").toLowerCase() === "paid"
                          ? "success"
                          : "neutral"
                      }
                    >
                      {formatStatusLabel(order.paymentStatus)}
                    </StudioBadge>
                    {["binance", "okx", "usdt_trc20"].includes(String(order.paymentTransaction?.provider || "").toLowerCase()) &&
                    String(order.paymentStatus || "").toLowerCase() !== "paid" ? (
                      <div className="mt-3 space-y-2">
                        <p className="text-xs text-slate-500">
                          {formatStatusLabel(order.paymentTransaction?.provider)} thanh toán thủ công
                        </p>
                        <StudioButton
                          disabled={confirmManualPaymentMutation.isPending}
                          size="sm"
                          variant="secondary"
                          onClick={() => {
                            const accepted = window.confirm(
                              `Xác nhận đã nhận USDT cho đơn ${order.orderCode}?`,
                            );

                            if (accepted) {
                              confirmManualPaymentMutation.mutate(order.id);
                            }
                          }}
                        >
                          Xác nhận đã nhận USDT
                        </StudioButton>
                      </div>
                    ) : null}
                    {order.paymentTransaction?.cryptoTxHash ? (
                      <div className="mt-3 rounded-[14px] border border-white/8 bg-white/[0.03] p-3">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">
                          TX Hash
                        </p>
                        <p className="mt-2 break-all text-xs text-slate-200">
                          {order.paymentTransaction.cryptoTxHash}
                        </p>
                      </div>
                    ) : null}
                  </td>
                  <td className="border-t border-white/8 py-4 pr-4 align-top text-slate-400">
                    {formatDate(order.createdAt)}
                  </td>
                  <td className="border-t border-white/8 py-4 text-right align-top font-semibold text-white">
                    {formatCurrency(order.totalSaleAmount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </StudioCard>
    </div>
  );
}
