import type { AxiosError } from "axios";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { BellOff, BellRing, Bot, Cable, KeyRound, ScanSearch, Send, ShieldCheck, Store, Wallet } from "lucide-react";

import { Field } from "@/components/dashboard/field";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { StatChip } from "@/components/dashboard/stat-chip";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { InfoHint } from "@/components/ui/info-hint";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { cn } from "@/lib/cn";
import { formatDate, formatStatusLabel } from "@/lib/format";

type BotConfigForm = {
  shopName: string;
  shopTagline: string;
  botToken: string;
  providerBaseUrl: string;
  providerBuyerKey: string;
  supportTelegram: string;
  supportZalo: string;
  logoUrl: string;
  sourceNotificationSyncEnabled: boolean;
  payosClientId: string;
  payosApiKey: string;
  payosChecksumKey: string;
  binanceUid: string;
  okxUid: string;
  usdtTrc20Address: string;
  usdtVndRateOverride: string;
  binancePersonalApiKey: string;
  binancePersonalSecretKey: string;
  binancePayApiKey: string;
  binancePaySecretKey: string;
  binancePayEnabled: boolean;
};

function normalizeOptionalValue(value: string) {
  const trimmed = value.trim();
  return trimmed === "" ? undefined : trimmed;
}

function buildBotConfigPayload(form: BotConfigForm) {
  const payload: Record<string, string | boolean> = {
    sourceNotificationSyncEnabled: form.sourceNotificationSyncEnabled,
  };

  const fields: Array<[Exclude<keyof BotConfigForm, "sourceNotificationSyncEnabled" | "binancePayEnabled">, string]> = [
    ["shopName", "shopName"],
    ["shopTagline", "shopTagline"],
    ["botToken", "botToken"],
    ["providerBaseUrl", "providerBaseUrl"],
    ["providerBuyerKey", "providerBuyerKey"],
    ["supportTelegram", "supportTelegram"],
    ["supportZalo", "supportZalo"],
    ["logoUrl", "logoUrl"],
    ["payosClientId", "payosClientId"],
    ["payosApiKey", "payosApiKey"],
    ["payosChecksumKey", "payosChecksumKey"],
    ["binanceUid", "binanceUid"],
    ["okxUid", "okxUid"],
    ["usdtTrc20Address", "usdtTrc20Address"],
    ["binancePersonalApiKey", "binancePersonalApiKey"],
    ["binancePersonalSecretKey", "binancePersonalSecretKey"],
    ["binancePayApiKey", "binancePayApiKey"],
    ["binancePaySecretKey", "binancePaySecretKey"],
  ];

  for (const [formKey, payloadKey] of fields) {
    const nextValue = normalizeOptionalValue(form[formKey] as string);

    if (nextValue !== undefined) {
      payload[payloadKey] = nextValue;
    }
  }

  // Explicit booleans
  payload.binancePayEnabled = form.binancePayEnabled;
  payload.usdtVndRateOverride = form.usdtVndRateOverride.trim();

  return payload;
}

function getApiErrorMessage(error: unknown) {
  const fallbackMessage = "Có lỗi xảy ra. Hãy kiểm tra lại dữ liệu rồi thử lại.";
  const axiosError = error as AxiosError<{ message?: string | string[] }>;
  const apiMessage = axiosError.response?.data?.message;

  if (Array.isArray(apiMessage)) {
    return apiMessage.join(", ");
  }

  if (typeof apiMessage === "string" && apiMessage.trim() !== "") {
    return apiMessage;
  }

  return fallbackMessage;
}

function getInitialForm(): BotConfigForm {
  return {
    shopName: "",
    shopTagline: "",
    botToken: "",
    providerBaseUrl: "https://canboso.com",
    providerBuyerKey: "",
    supportTelegram: "",
    supportZalo: "",
    logoUrl: "",
    sourceNotificationSyncEnabled: true,
    payosClientId: "",
    payosApiKey: "",
    payosChecksumKey: "",
    binanceUid: "",
    okxUid: "",
    usdtTrc20Address: "",
    usdtVndRateOverride: "",
    binancePersonalApiKey: "",
    binancePersonalSecretKey: "",
    binancePayApiKey: "",
    binancePaySecretKey: "",
    binancePayEnabled: false,
  };
}

function toneByStatus(value?: string | null) {
  const normalized = String(value || "").toLowerCase();
  if (normalized === "verified" || normalized === "active" || normalized === "mock") {
    return "success" as const;
  }
  if (normalized === "failed") {
    return "danger" as const;
  }
  if (normalized === "pending" || normalized === "polling") {
    return "warning" as const;
  }
  return "neutral" as const;
}

export function BotConfigPage() {
  const queryClient = useQueryClient();
  const configQuery = useQuery({
    queryKey: ["bot-config"],
    queryFn: async () => (await api.get("/bot-config")).data,
  });
  const [form, setForm] = useState<BotConfigForm>(getInitialForm);
  const [simulationOutput, setSimulationOutput] = useState("");
  const { showToast } = useToast();

  useEffect(() => {
    if (!configQuery.data) {
      return;
    }

    setForm({
      shopName: configQuery.data.shopName || "",
      shopTagline: configQuery.data.shopTagline || "",
      botToken: "",
      providerBaseUrl: configQuery.data.providerBaseUrl || "https://canboso.com",
      providerBuyerKey: "",
      supportTelegram: configQuery.data.supportTelegram || "",
      supportZalo: configQuery.data.supportZalo || "",
      logoUrl: configQuery.data.logoUrl || "",
      sourceNotificationSyncEnabled:
        configQuery.data.sourceNotificationSyncEnabled ?? true,
      payosClientId: "",
      payosApiKey: "",
      payosChecksumKey: "",
      binanceUid: configQuery.data.binanceUid || "",
      okxUid: configQuery.data.okxUid || "",
      usdtTrc20Address: configQuery.data.usdtTrc20Address || "",
      usdtVndRateOverride:
        configQuery.data.usdtVndRateOverride !== null &&
        configQuery.data.usdtVndRateOverride !== undefined
          ? String(configQuery.data.usdtVndRateOverride)
          : "",
      binancePersonalApiKey: "",
      binancePersonalSecretKey: "",
      binancePayApiKey: "",
      binancePaySecretKey: "",
      binancePayEnabled: configQuery.data.binancePayEnabled ?? false,
    });
  }, [configQuery.data]);

  const saveMutation = useMutation({
    mutationFn: async () => api.put("/bot-config", buildBotConfigPayload(form)),
    onSuccess: async () => {
      showToast({
        tone: "success",
        message: "Đã lưu cấu hình. Tất cả khóa bí mật seller tiếp tục được giữ trong database dưới dạng mã hóa.",
      });
      setForm((current) => ({
        ...current,
        botToken: "",
        providerBuyerKey: "",
        payosClientId: "",
        payosApiKey: "",
        payosChecksumKey: "",
        binancePersonalApiKey: "",
        binancePersonalSecretKey: "",
        binancePayApiKey: "",
        binancePaySecretKey: "",
      }));
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["bot-config"] }),
        queryClient.invalidateQueries({ queryKey: ["shop"] }),
      ]);
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const verifyTelegramMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/verify-telegram"),
    onSuccess: async (response) => {
      showToast({
        tone: "success",
        message: `Telegram đã xác thực thành công với @${response.data.telegramBotUsername || "bot"}.`,
      });
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const verifyProviderMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/verify-provider"),
    onSuccess: async (response) => {
      const sampleSize = response.data.providerSampleSize;
      showToast({
        tone: "success",
        message:
          typeof sampleSize === "number"
            ? `API nguồn đã xác thực, hiện đọc được ${sampleSize} sản phẩm từ upstream.`
            : "API nguồn đã xác thực thành công.",
      });
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const syncProductsMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/sync-products"),
    onSuccess: async (response) => {
      showToast({
        tone: "success",
        message: `Đã đồng bộ ${response.data.synced || 0} sản phẩm về shop seller.`,
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["bot-config"] }),
        queryClient.invalidateQueries({ queryKey: ["products"] }),
      ]);
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const sourceNotificationSyncMutation = useMutation({
    mutationFn: async (enabled: boolean) =>
      api.put("/bot-config", { sourceNotificationSyncEnabled: enabled }),
    onSuccess: async (_response, enabled) => {
      queryClient.setQueryData(["bot-config"], (current: any) =>
        current ? { ...current, sourceNotificationSyncEnabled: enabled } : current,
      );
      showToast({
        tone: "success",
        message: enabled
          ? "Đã bật đồng bộ thông báo từ bot nguồn."
          : "Đã tắt đồng bộ thông báo từ bot nguồn.",
      });
    },
    onError: (error, enabled) => {
      setForm((current) => ({
        ...current,
        sourceNotificationSyncEnabled: !enabled,
      }));
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  function toggleSourceNotificationSync() {
    const nextEnabled = !form.sourceNotificationSyncEnabled;

    setForm((current) => ({
      ...current,
      sourceNotificationSyncEnabled: nextEnabled,
    }));
    sourceNotificationSyncMutation.mutate(nextEnabled);
  }

  const simulateMutation = useMutation({
    mutationFn: async (payload: { text?: string; callbackData?: string }) =>
      api.post(`/dev/telegram/${configQuery.data.shopId}/simulate`, payload),
    onSuccess: (response) => {
      setSimulationOutput(JSON.stringify(response.data.actions, null, 2));
    },
    onError: (error) => {
      setSimulationOutput(getApiErrorMessage(error));
    },
  });

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Thiết lập tự động"
        title="Cấu hình bot"
        description="Seller chỉ cần nhập những khóa bắt buộc. Toàn bộ phần verify bot, verify upstream, sync catalog và thiết lập pipeline sẽ được điều phối từ cùng một mặt điều khiển."
        actions={
          <Button className="min-w-[220px]" disabled={saveMutation.isPending} onClick={() => saveMutation.mutate()}>
            {saveMutation.isPending ? "Đang lưu..." : "Lưu toàn bộ cấu hình"}
          </Button>
        }
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatChip
          icon={Store}
          label="Shop"
          value={configQuery.data?.shopName || "Chưa đặt tên"}
          meta={configQuery.data?.shopTagline || "Thiết lập định danh của seller"}
          tone="amber"
        />
        <StatChip
          icon={Bot}
          label="Telegram"
          value={formatStatusLabel(configQuery.data?.telegramWebhookStatus)}
          meta={configQuery.data?.telegramBotUsername ? `@${configQuery.data.telegramBotUsername}` : "Chưa xác thực"}
          tone="amber"
        />
        <StatChip
          icon={Cable}
          label="Provider"
          value={formatStatusLabel(configQuery.data?.providerConnectionStatus)}
          meta={configQuery.data?.providerBaseUrl || "https://canboso.com"}
          tone="amber"
        />
        <StatChip
          icon={Wallet}
          label="Thanh toán"
          value={formatStatusLabel(configQuery.data?.paymentProvider)}
          meta={`Sync gần nhất: ${formatDate(configQuery.data?.lastCatalogSyncAt)}`}
          tone="amber"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-6">
          <Card>
            <div>
              <p className="app-kicker">Định danh shop</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Thông tin shop
              </h2>
            </div>

            <div className="mt-6 grid gap-5 md:grid-cols-2">
              <Field label="Tên shop" hint="Required">
                <Input
                  value={form.shopName}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, shopName: event.target.value }))
                  }
                  placeholder="Ví dụ: Premium Hub"
                />
              </Field>
              <Field label="Logo URL" hint="Optional">
                <Input
                  value={form.logoUrl}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, logoUrl: event.target.value }))
                  }
                  placeholder="https://..."
                />
              </Field>
              <div className="md:col-span-2">
                <Field label="Tagline" hint="Optional">
                  <Textarea
                    className="min-h-[110px]"
                    value={form.shopTagline}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, shopTagline: event.target.value }))
                    }
                    placeholder="Mô tả ngắn về shop seller và lời hứa dịch vụ"
                  />
                </Field>
              </div>
            </div>
          </Card>

          <Card>
            <div>
              <p className="app-kicker">Bot và nguồn cấp</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Telegram và nguồn cấp
              </h2>
            </div>

            <div className="mt-6 grid gap-5">
              <Field
                label="BOT_TOKEN"
                hint={configQuery.data?.botTokenMasked ? "Encrypted" : "Required"}
                description="Token của bot seller. Nếu đã lưu trước đó, bạn chỉ cần nhập lại khi muốn thay mới."
              >
                <Input
                  value={form.botToken}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, botToken: event.target.value }))
                  }
                  placeholder={configQuery.data?.botTokenMasked || "Nhập BOT_TOKEN"}
                />
              </Field>

              <div className="grid gap-5 md:grid-cols-2">
                <Field label="Provider base URL" hint="Default">
                  <Input
                    value={form.providerBaseUrl}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, providerBaseUrl: event.target.value }))
                    }
                    placeholder="https://canboso.com"
                  />
                </Field>
                <Field
                  label="Buyer key"
                  hint={configQuery.data?.providerBuyerKeyMasked ? "Encrypted" : "Required"}
                >
                  <Input
                    value={form.providerBuyerKey}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, providerBuyerKey: event.target.value }))
                    }
                    placeholder={configQuery.data?.providerBuyerKeyMasked || "Nhập khóa buyer"}
                  />
                </Field>
              </div>

              <div className="glass-chip flex flex-col gap-4 rounded-[22px] px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="font-semibold text-white">Đồng bộ thông báo từ bot nguồn</p>
                  <p className="mt-1 text-sm text-slate-500">
                    Bật để bot seller gửi thông báo khi nguồn báo có thêm hàng.
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={form.sourceNotificationSyncEnabled}
                  aria-busy={sourceNotificationSyncMutation.isPending}
                  disabled={sourceNotificationSyncMutation.isPending}
                  onClick={toggleSourceNotificationSync}
                  className={cn(
                    "inline-flex h-12 w-full shrink-0 items-center justify-between gap-3 rounded-[14px] border px-3 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-55 sm:w-[164px]",
                    form.sourceNotificationSyncEnabled
                      ? "border-emerald-300/24 bg-emerald-500/14 text-emerald-100"
                      : "border-white/10 bg-[#18233c] text-slate-300",
                  )}
                >
                  <span
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-[10px] transition",
                      form.sourceNotificationSyncEnabled
                        ? "bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e]"
                        : "bg-[#121A2E] text-slate-400",
                    )}
                  >
                    {form.sourceNotificationSyncEnabled ? (
                      <BellRing className="h-4 w-4" />
                    ) : (
                      <BellOff className="h-4 w-4" />
                    )}
                  </span>
                  <span>{form.sourceNotificationSyncEnabled ? "Đang bật" : "Đang tắt"}</span>
                </button>
              </div>
            </div>
          </Card>

          <Card>
            <div>
              <p className="app-kicker">Hỗ trợ và thanh toán</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Hỗ trợ và cổng thanh toán
              </h2>
            </div>

            <div className="mt-6 grid gap-5 md:grid-cols-2">
              <Field label="Telegram hỗ trợ" hint="Contact">
                <Input
                  value={form.supportTelegram}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, supportTelegram: event.target.value }))
                  }
                  placeholder="@support_shop"
                />
              </Field>
              <Field label="Zalo hỗ trợ" hint="Contact">
                <Input
                  value={form.supportZalo}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, supportZalo: event.target.value }))
                  }
                  placeholder="Số Zalo hỗ trợ"
                />
              </Field>
              <Field
                label="PayOS Client ID"
                hint={configQuery.data?.payosClientIdMasked ? "Encrypted" : "Optional"}
              >
                <Input
                  value={form.payosClientId}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, payosClientId: event.target.value }))
                  }
                  placeholder={configQuery.data?.payosClientIdMasked || "Nhập client id"}
                />
              </Field>
              <Field
                label="PayOS API Key"
                hint={configQuery.data?.payosApiKeyMasked ? "Encrypted" : "Optional"}
              >
                <Input
                  value={form.payosApiKey}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, payosApiKey: event.target.value }))
                  }
                  placeholder={configQuery.data?.payosApiKeyMasked || "Nhập api key"}
                />
              </Field>
              <div className="md:col-span-2">
                <Field
                  label="PayOS Checksum Key"
                  hint={configQuery.data?.payosChecksumKeyMasked ? "Encrypted" : "Optional"}
                >
                  <Input
                    value={form.payosChecksumKey}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, payosChecksumKey: event.target.value }))
                    }
                    placeholder={configQuery.data?.payosChecksumKeyMasked || "Nhập checksum key"}
                  />
                </Field>
              </div>
              <Field
                label="Binance UID"
                hint="USDT"
                description="UID nhận USDT thủ công trên Binance. Bot sẽ hiển thị UID này kèm số USDT quy đổi cho khách."
              >
                <Input
                  value={form.binanceUid}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, binanceUid: event.target.value }))
                  }
                  placeholder="Nhập Binance UID"
                />
              </Field>
              <Field
                label="OKX UID"
                hint="USDT"
                description="UID nhận USDT thủ công trên OKX. Bot sẽ hiển thị UID này kèm số USDT quy đổi cho khách."
              >
                <Input
                  value={form.okxUid}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, okxUid: event.target.value }))
                  }
                  placeholder="Nhập OKX UID"
                />
              </Field>
              <div className="md:col-span-2">
                <Field
                  label="USDT TRC20 Address"
                  hint="Tron"
                  description="Dia chi vi TRC20 de khach chuyen USDT on-chain. Nen dung mot dia chi TRON da active san; dia chi TRON moi khong the duoc active chi bang lenh chuyen TRC20."
                >
                  <Input
                    value={form.usdtTrc20Address}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, usdtTrc20Address: event.target.value }))
                    }
                    placeholder="Nhập địa chỉ ví USDT TRC20"
                  />
                </Field>
              </div>
              <Field
                label="USDT/VND Rate Override"
                hint="Optional"
                description={`Ty gia quy doi rieng cho shop nay khi bot hien gia o che do English. De trong de dung flow mac dinh hien tai (${configQuery.data?.defaultUsdtVndRate || 26000} VND = 1 USDT).`}
              >
                <Input
                  inputMode="decimal"
                  value={form.usdtVndRateOverride}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, usdtVndRateOverride: event.target.value }))
                  }
                  placeholder={`Vi du: ${configQuery.data?.defaultUsdtVndRate || 26000}`}
                />
              </Field>
              <Field
                label="Binance Personal API Key"
                hint={configQuery.data?.binancePersonalApiKeyMasked ? "Encrypted" : "Optional"}
                description="Chi can khi muon bot tu check giao dich Binance UID sau khi khach bam 'Da chuyen tien'. Dung Spot API key co quyen doc Pay transactions, khong cap quyen withdraw."
              >
                <Input
                  value={form.binancePersonalApiKey}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, binancePersonalApiKey: event.target.value }))
                  }
                  placeholder={configQuery.data?.binancePersonalApiKeyMasked || "Nhap Binance personal API key"}
                />
              </Field>
              <Field
                label="Binance Personal Secret Key"
                hint={configQuery.data?.binancePersonalSecretKeyMasked ? "Encrypted" : "Optional"}
                description="Secret key di kem voi personal API key. Khi nhap du ca key va secret, bot co the doi chieu lich su Pay de auto verify theo so USDT da gan rieng cho tung don."
              >
                <Input
                  value={form.binancePersonalSecretKey}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, binancePersonalSecretKey: event.target.value }))
                  }
                  placeholder={configQuery.data?.binancePersonalSecretKeyMasked || "Nhap Binance personal secret key"}
                />
              </Field>
            </div>
          </Card>

          {/* ── Binance Pay Merchant (Auto) ───────────────────────────── */}
          <Card>
            <div>
              <p className="app-kicker">Tự động — Không cần xác nhận thủ công</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Binance Pay Merchant
              </h2>
            </div>

            <div className="mt-4">
              <InfoHint
                content="Khi bật Binance Pay Merchant, bot tự tạo checkout link và nhận webhook xác nhận thanh toán tự động. Khách không cần gửi mã giao dịch."
                label="Xem ghi chú Binance Pay Auto"
              />
            </div>

            <div className="mt-6 grid gap-5">
              {/* Toggle bật/tắt */}
              <div className="glass-chip flex flex-col gap-4 rounded-[22px] px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="font-semibold text-white">Binance Pay Auto</p>
                  <p className="mt-1 text-sm text-slate-500">
                    Bật để dùng Binance Pay Merchant API thay cho chuyển USDT thủ công.
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={form.binancePayEnabled}
                  onClick={() =>
                    setForm((current) => ({ ...current, binancePayEnabled: !current.binancePayEnabled }))
                  }
                  className={cn(
                    "inline-flex h-12 w-full shrink-0 items-center justify-between gap-3 rounded-[14px] border px-3 text-sm font-semibold transition sm:w-[164px]",
                    form.binancePayEnabled
                      ? "border-yellow-300/24 bg-yellow-500/14 text-yellow-100"
                      : "border-white/10 bg-[#18233c] text-slate-300",
                  )}
                >
                  <span
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-[10px] transition",
                      form.binancePayEnabled
                        ? "bg-[linear-gradient(135deg,#F59E0B,#D97706)] text-[#07131e]"
                        : "bg-[#121A2E] text-slate-400",
                    )}
                  >
                    🟡
                  </span>
                  <span>{form.binancePayEnabled ? "Đang bật" : "Đang tắt"}</span>
                </button>
              </div>

              {/* API Key + Secret */}
              <Field
                label="Binance Pay API Key"
                hint={configQuery.data?.binancePayApiKeyMasked ? "Encrypted" : "Optional"}
                description="Certificate SN (API Key) từ Merchant Admin Portal của Binance."
              >
                <Input
                  value={form.binancePayApiKey}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, binancePayApiKey: event.target.value }))
                  }
                  placeholder={configQuery.data?.binancePayApiKeyMasked || "Nhập API Key"}
                />
              </Field>
              <Field
                label="Binance Pay Secret Key"
                hint={configQuery.data?.binancePaySecretKeyMasked ? "Encrypted" : "Optional"}
                description="Secret Key tương ứng. Được mã hóa trước khi lưu vào database."
              >
                <Input
                  value={form.binancePaySecretKey}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, binancePaySecretKey: event.target.value }))
                  }
                  placeholder={configQuery.data?.binancePaySecretKeyMasked || "Nhập Secret Key"}
                />
              </Field>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
              <p className="app-kicker">Trạng thái kết nối</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Tình trạng kết nối
                </h2>
              </div>
              <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
                <ShieldCheck className="h-5 w-5 text-emerald-100" />
              </span>
            </div>

            <div className="mt-6 space-y-3">
              <div className="glass-chip flex items-center justify-between rounded-[22px] px-4 py-4">
                <div>
                  <p className="font-semibold text-white">Telegram bot</p>
                  <p className="mt-1 text-sm text-slate-500">
                    {configQuery.data?.telegramBotUsername
                      ? `@${configQuery.data.telegramBotUsername}`
                      : "Chưa xác thực"}
                  </p>
                </div>
                <Badge tone={toneByStatus(configQuery.data?.telegramWebhookStatus)}>
                  {formatStatusLabel(configQuery.data?.telegramWebhookStatus)}
                </Badge>
              </div>

              <div className="glass-chip flex items-center justify-between rounded-[22px] px-4 py-4">
                <div>
                  <p className="font-semibold text-white">Kết nối nguồn</p>
                  <p className="mt-1 text-sm text-slate-500">{configQuery.data?.providerBaseUrl}</p>
                </div>
                <Badge tone={toneByStatus(configQuery.data?.providerConnectionStatus)}>
                  {formatStatusLabel(configQuery.data?.providerConnectionStatus)}
                </Badge>
              </div>

              <div className="glass-chip flex items-center justify-between rounded-[22px] px-4 py-4">
                <div>
                  <p className="font-semibold text-white">Chế độ thanh toán</p>
                  <p className="mt-1 text-sm text-slate-500">
                    Last sync {formatDate(configQuery.data?.lastCatalogSyncAt)}
                  </p>
                </div>
                <Badge tone={toneByStatus(configQuery.data?.paymentProvider)}>
                  {formatStatusLabel(configQuery.data?.paymentProvider)}
                </Badge>
              </div>
            </div>

            <div className="mt-6 grid gap-3">
              <Button
                variant="secondary"
                disabled={verifyTelegramMutation.isPending}
                onClick={() => verifyTelegramMutation.mutate()}
              >
                <ScanSearch className="h-4 w-4" />
                {verifyTelegramMutation.isPending ? "Đang kiểm tra Telegram..." : "Kiểm tra Telegram"}
              </Button>
              <Button
                variant="secondary"
                disabled={verifyProviderMutation.isPending}
                onClick={() => verifyProviderMutation.mutate()}
              >
                <Cable className="h-4 w-4" />
                {verifyProviderMutation.isPending ? "Đang kiểm tra nguồn..." : "Kiểm tra nguồn"}
              </Button>
              <Button
                variant="secondary"
                disabled={syncProductsMutation.isPending}
                onClick={() => syncProductsMutation.mutate()}
              >
                <KeyRound className="h-4 w-4" />
                {syncProductsMutation.isPending ? "Đang đồng bộ..." : "Đồng bộ sản phẩm"}
              </Button>
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
              <p className="app-kicker">Mô phỏng Telegram</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Khu test bot
                </h2>
              </div>
              <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
                <Send className="h-5 w-5 text-emerald-100" />
              </span>
            </div>

            <div className="mt-4">
              <InfoHint
                content="Dùng để mô phỏng vài nhánh phổ biến của bot seller trong môi trường local trước khi test end-to-end bằng Telegram thật."
                label="Xem ghi chú cho Khu test bot"
              />
            </div>

            <div className="mt-6 grid gap-3 md:grid-cols-3">
              <Button variant="secondary" onClick={() => simulateMutation.mutate({ text: "/start" })}>
                /start
              </Button>
              <Button
                variant="secondary"
                onClick={() => simulateMutation.mutate({ callbackData: "home:products" })}
              >
                Xem sản phẩm
              </Button>
              <Button
                variant="secondary"
                onClick={() => simulateMutation.mutate({ callbackData: "home:support" })}
              >
                Hỗ trợ
              </Button>
            </div>

            <div className="mt-5">
              <Textarea
                className="min-h-[220px] font-mono text-xs"
                readOnly
                value={simulationOutput}
                placeholder="Kết quả action từ bot mô phỏng sẽ hiển thị tại đây."
              />
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
