import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Line,
} from "recharts";
import {
  BarChart3,
  CalendarRange,
  CircleDollarSign,
  PackageCheck,
  TrendingUp,
} from "lucide-react";

import { SectionHeading } from "@/components/dashboard/section-heading";
import { MetricCard } from "@/components/metric-card";
import { Card } from "@/components/ui/card";
import { InfoHint } from "@/components/ui/info-hint";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

type RevenuePoint = {
  label: string;
  grossRevenue: number;
  estimatedProfit: number;
  deliveredOrders: number;
};

type RevenueResponse = {
  summary: {
    grossRevenue: number;
    estimatedProfit: number;
    deliveredOrders: number;
  };
  series: RevenuePoint[];
};

const compactDayFormatter = new Intl.DateTimeFormat("vi-VN", {
  day: "2-digit",
  month: "2-digit",
});

const fullDayFormatter = new Intl.DateTimeFormat("vi-VN", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

function formatChartDayLabel(label: string) {
  const parsed = new Date(`${label}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? label : compactDayFormatter.format(parsed);
}

function formatFullDayLabel(label: string) {
  const parsed = new Date(`${label}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? label : fullDayFormatter.format(parsed);
}

function formatTrend(delta: number) {
  if (delta === 0) {
    return "Giữ nguyên so với mốc trước";
  }

  const sign = delta > 0 ? "+" : "";
  return `${sign}${delta.toFixed(1)}% so với mốc trước`;
}

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ dataKey?: string; value?: number }>;
  label?: string;
}) {
  if (!active || !payload?.length || !label) {
    return null;
  }

  const grossRevenue = Number(
    payload.find((entry) => entry.dataKey === "grossRevenue")?.value || 0,
  );
  const estimatedProfit = Number(
    payload.find((entry) => entry.dataKey === "estimatedProfit")?.value || 0,
  );

  return (
    <div className="min-w-[220px] rounded-[22px] border border-white/10 bg-[#0a1220]/95 p-4 shadow-[0_24px_70px_rgba(2,6,23,0.42)] backdrop-blur-xl">
      <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-400">
        {formatFullDayLabel(label)}
      </p>
      <div className="mt-4 space-y-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-slate-300">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-300" />
            Doanh thu
          </div>
          <span className="text-sm font-semibold text-white">{formatCurrency(grossRevenue)}</span>
        </div>
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-slate-300">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
            Lợi nhuận ước tính
          </div>
          <span className="text-sm font-semibold text-white">
            {formatCurrency(estimatedProfit)}
          </span>
        </div>
      </div>
    </div>
  );
}

export function RevenuePagePrime() {
  const query = useQuery<RevenueResponse>({
    queryKey: ["reports", "revenue"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });

  const series = query.data?.series || [];

  const chartData = useMemo(
    () =>
      series.map((item) => ({
        ...item,
        shortLabel: formatChartDayLabel(item.label),
        fullLabel: formatFullDayLabel(item.label),
      })),
    [series],
  );

  const chartRenderData = useMemo(() => {
    if (chartData.length !== 1) {
      return chartData;
    }

    const [onlyPoint] = chartData;

    return [
      {
        ...onlyPoint,
        shortLabel: "",
        axisKey: "lead",
        isSynthetic: true,
      },
      {
        ...onlyPoint,
        axisKey: "main",
        isSynthetic: false,
      },
      {
        ...onlyPoint,
        shortLabel: "",
        axisKey: "tail",
        isSynthetic: true,
      },
    ];
  }, [chartData]);

  const averageRevenue =
    chartData.length > 0
      ? Math.round(
          chartData.reduce((sum, item) => sum + Number(item.grossRevenue || 0), 0) /
            chartData.length,
        )
      : 0;

  const averageProfit =
    chartData.length > 0
      ? Math.round(
          chartData.reduce((sum, item) => sum + Number(item.estimatedProfit || 0), 0) /
            chartData.length,
        )
      : 0;

  const bestDay = useMemo(
    () =>
      chartData.reduce<(typeof chartData)[number] | null>(
        (current, item) =>
          !current || item.grossRevenue > current.grossRevenue ? item : current,
        null,
      ),
    [chartData],
  );

  const latestDay = chartData.at(-1) || null;
  const previousDay = chartData.at(-2) || null;

  const revenueTrend =
    latestDay && previousDay && previousDay.grossRevenue > 0
      ? ((latestDay.grossRevenue - previousDay.grossRevenue) / previousDay.grossRevenue) * 100
      : 0;

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Phân tích tài chính"
        title="Doanh thu"
        description="Theo dõi nhịp bán hàng theo ngày bằng biểu đồ đường rõ ràng hơn, giúp seller nhìn nhanh xu hướng tiền về và biên lợi nhuận."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Doanh thu gộp"
          value={formatCurrency(query.data?.summary?.grossRevenue || 0)}
          description="Tổng doanh thu từ các đơn thanh toán thành công trong kỳ dữ liệu hiện tại."
          icon={CircleDollarSign}
          tone="amber"
        />
        <MetricCard
          label="Lợi nhuận ước tính"
          value={formatCurrency(query.data?.summary?.estimatedProfit || 0)}
          description="Phần còn lại sau khi trừ chi phí nguồn theo snapshot của từng đơn đã trả tiền."
          icon={BarChart3}
          tone="amber"
        />
        <MetricCard
          label="Đơn đã giao"
          value={String(query.data?.summary?.deliveredOrders || 0)}
          description="Số đơn đã giao xong để seller nhìn được hiệu quả vận hành thực tế."
          icon={PackageCheck}
          tone="amber"
        />
        <MetricCard
          label="Trung bình mỗi ngày"
          value={formatCurrency(averageRevenue)}
          description="Mức doanh thu trung bình trên mỗi ngày có phát sinh giao dịch trong tháng."
          icon={CalendarRange}
          tone="amber"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-[minmax(0,1.25fr)_360px]">
        <Card className="overflow-hidden">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-xl">
              <p className="app-kicker">Biểu đồ đường</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Doanh thu và lợi nhuận theo ngày
              </h2>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:min-w-[260px]">
              <div className="rounded-[20px] border border-white/10 bg-slate-950/35 px-4 py-3">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Mốc tốt nhất
                </p>
                <p className="mt-3 text-lg font-semibold text-white">
                  {bestDay ? formatCurrency(bestDay.grossRevenue) : formatCurrency(0)}
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  {bestDay ? bestDay.fullLabel : "Chưa có dữ liệu"}
                </p>
              </div>
              <div className="rounded-[20px] border border-white/10 bg-slate-950/35 px-4 py-3">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Nhịp gần nhất
                </p>
                <p className="mt-3 text-lg font-semibold text-white">
                  {latestDay ? formatCurrency(latestDay.grossRevenue) : formatCurrency(0)}
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  {latestDay ? formatTrend(revenueTrend) : "Chưa đủ dữ liệu so sánh"}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <InfoHint
              content="Biểu đồ gom doanh thu gộp và lợi nhuận ước tính trên cùng một mặt để seller nhìn xu hướng nhanh hơn."
              label="Xem ghi chú cho biểu đồ doanh thu"
            />
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-3 text-sm">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-slate-950/35 px-3 py-1.5 text-slate-200">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-300" />
              Doanh thu
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-slate-950/35 px-3 py-1.5 text-slate-200">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
              Lợi nhuận ước tính
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-slate-950/35 px-3 py-1.5 text-slate-400">
              Đường đứt là mức doanh thu trung bình: {formatCurrency(averageRevenue)}
            </div>
          </div>

          <div className="mt-6 h-[380px]">
            {chartData.length === 0 ? (
              <div className="flex h-full items-center justify-center rounded-[24px] border border-dashed border-white/10 bg-slate-950/25 text-center">
                <div className="space-y-3 px-6">
                  <p className="text-lg font-semibold text-white">Chưa có dữ liệu doanh thu</p>
                  <p className="max-w-md text-sm leading-6 text-slate-400">
                    Khi shop có đơn thanh toán thành công, biểu đồ đường sẽ tự hiện để bạn theo
                    dõi xu hướng doanh thu theo ngày.
                  </p>
                </div>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={chartRenderData}
                  margin={{ top: 12, right: 18, left: -16, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="revenueFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#34D399" stopOpacity="0.32" />
                      <stop offset="100%" stopColor="#34D399" stopOpacity="0.02" />
                    </linearGradient>
                    <linearGradient id="profitFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10B981" stopOpacity="0.22" />
                      <stop offset="100%" stopColor="#10B981" stopOpacity="0.02" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="rgba(148,163,184,0.10)" vertical={false} />
                  <XAxis
                    dataKey="shortLabel"
                    stroke="rgba(148,163,184,0.72)"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => value || ""}
                  />
                  <YAxis
                    stroke="rgba(148,163,184,0.72)"
                    tickLine={false}
                    axisLine={false}
                    width={70}
                    tickFormatter={(value) =>
                      value >= 1000000
                        ? `${(value / 1000000).toFixed(1)}tr`
                        : value >= 1000
                          ? `${Math.round(value / 1000)}k`
                          : `${value}`
                    }
                  />
                  <ReferenceLine
                    y={averageRevenue}
                    stroke="rgba(52,211,153,0.28)"
                    strokeDasharray="6 6"
                  />
                  <Tooltip content={<ChartTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="grossRevenue"
                    fill="url(#revenueFill)"
                    stroke="none"
                    isAnimationActive={false}
                  />
                  <Area
                    type="monotone"
                    dataKey="estimatedProfit"
                    fill="url(#profitFill)"
                    stroke="none"
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="grossRevenue"
                    stroke="#34D399"
                    strokeWidth={3.5}
                    dot={{ r: 4.5, fill: "#34D399", stroke: "#121A2E", strokeWidth: 2 }}
                    activeDot={{ r: 7, fill: "#34D399", stroke: "#ffffff", strokeWidth: 2 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="estimatedProfit"
                    stroke="#10B981"
                    strokeWidth={2.8}
                    dot={{ r: 3.8, fill: "#10B981", stroke: "#121A2E", strokeWidth: 2 }}
                    activeDot={{ r: 6, fill: "#10B981", stroke: "#ffffff", strokeWidth: 2 }}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="app-kicker">Điểm nhấn kỳ này</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Bức tranh ngắn gọn
                </h2>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-[14px] border border-white/10 bg-slate-950/40 text-emerald-200">
                <TrendingUp className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-6 space-y-3">
              <div className="rounded-[22px] border border-white/10 bg-slate-950/30 px-4 py-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Ngày tốt nhất
                </p>
                <p className="mt-2 text-2xl font-semibold text-white">
                  {bestDay ? formatCurrency(bestDay.grossRevenue) : formatCurrency(0)}
                </p>
                <p className="mt-1 text-sm text-slate-400">
                  {bestDay ? `Rơi vào ngày ${bestDay.fullLabel}` : "Chưa có dữ liệu để kết luận"}
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
                <div className="rounded-[22px] border border-white/10 bg-slate-950/30 px-4 py-4">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                    Lợi nhuận trung bình
                  </p>
                  <p className="mt-2 text-xl font-semibold text-white">
                    {formatCurrency(averageProfit)}
                  </p>
                </div>
                <div className="rounded-[22px] border border-white/10 bg-slate-950/30 px-4 py-4">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                    Số ngày có phát sinh
                  </p>
                  <p className="mt-2 text-xl font-semibold text-white">{chartData.length} ngày</p>
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Chi tiết theo ngày</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Breakdown theo ngày
                </h2>
              </div>
              <div className="rounded-full border border-white/10 bg-slate-950/35 px-3 py-1.5 text-xs font-medium text-slate-300">
                {chartData.length} mốc dữ liệu
              </div>
            </div>

            <div className="mt-6 space-y-3">
              {chartData.length === 0 ? (
                <div className="rounded-[22px] border border-dashed border-white/10 bg-slate-950/25 px-4 py-5 text-sm leading-6 text-slate-400">
                  Khi có doanh thu phát sinh, từng ngày sẽ hiện ở đây kèm số đơn đã giao và lợi
                  nhuận ước tính.
                </div>
              ) : (
                [...chartData].reverse().map((item) => (
                  <div
                    key={item.label}
                    className="rounded-[22px] border border-white/10 bg-slate-950/30 px-4 py-4"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="font-semibold text-white">{item.fullLabel}</p>
                        <p className="mt-1 text-sm text-slate-400">
                          {item.deliveredOrders} đơn đã giao • Lợi nhuận ước tính{" "}
                          {formatCurrency(item.estimatedProfit || 0)}
                        </p>
                      </div>
                      <p className="font-display text-2xl font-semibold text-emerald-100">
                        {formatCurrency(item.grossRevenue || 0)}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
