import { useQuery } from "@tanstack/react-query";

import { useAuth } from "@/auth/auth-provider";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatRoleLabel } from "@/lib/format";

export function ProfilePage() {
  const { session } = useAuth();
  const shopQuery = useQuery({
    queryKey: ["shop", "profile"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });

  return (
    <div className="space-y-6">
      <h1 className="font-display text-4xl font-bold text-white">Hồ sơ / đổi mật khẩu</h1>
      <div className="grid gap-6 xl:grid-cols-2">
        <Card className="space-y-3">
          <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Tài khoản</p>
          <p className="text-xl font-semibold text-white">{session?.user.displayName || "Seller"}</p>
          <p className="text-slate-400">{session?.user.email}</p>
          <p className="text-sm text-slate-500">Vai trò: {formatRoleLabel(session?.user.role)}</p>
        </Card>
        <Card className="space-y-3">
          <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Shop</p>
          <p className="text-xl font-semibold text-white">{shopQuery.data?.name}</p>
          <p className="text-slate-400">{shopQuery.data?.tagline || "Chưa đặt tagline"}</p>
          <p className="text-sm text-slate-500">
            Giao diện đổi mật khẩu chưa mở trong MVP, nhưng lớp auth và refresh token đã sẵn sàng.
          </p>
        </Card>
      </div>
    </div>
  );
}
