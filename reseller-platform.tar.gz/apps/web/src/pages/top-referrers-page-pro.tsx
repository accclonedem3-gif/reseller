import { useQuery } from "@tanstack/react-query";
import { Link2, Rocket, Sparkles } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { StatChip } from "@/components/dashboard/stat-chip";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";

export function TopReferrersPage() {
  const query = useQuery({
    queryKey: ["reports", "top-referrers"],
    queryFn: async () => (await api.get("/reports/top-referrers")).data,
  });

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Referral readiness"
        title="Top người giới thiệu"
        description="Giao diện đã được chuẩn bị để seller có thể mở rộng sang referral hoặc affiliate ở giai đoạn tiếp theo. MVP hiện tại giữ schema và vùng hiển thị sẵn sàng cho tương lai."
      />

      <section className="grid gap-4 md:grid-cols-3">
        <StatChip
          icon={Link2}
          label="Schema"
          value="Đã sẵn sàng"
          meta="Database đã có bảng referral links và events"
          tone="amber"
        />
        <StatChip
          icon={Rocket}
          label="MVP"
          value="Chưa ghi nhận"
          meta="Chưa có sự kiện referral thật được phát sinh"
          tone="amber"
        />
        <StatChip
          icon={Sparkles}
          label="UI"
          value="Đã dựng trước"
          meta="Có thể nối logic referral sau mà không phải làm lại dashboard"
          tone="amber"
        />
      </section>

      <Card>
        <EmptyState
          title="Chưa có bảng xếp hạng referral"
          description={query.data?.message || "Phần referral đang ở mức MVP. Khi hệ thống bắt đầu ghi nhận event giới thiệu, bảng xếp hạng sẽ tự xuất hiện tại đây."}
        />
      </Card>
    </div>
  );
}
