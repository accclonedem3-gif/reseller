import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

export function ProductsPage() {
  const queryClient = useQueryClient();
  const productsQuery = useQuery({
    queryKey: ["products"],
    queryFn: async () => (await api.get("/products")).data,
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [form, setForm] = useState({
    displayName: "",
    salePrice: "",
    hidden: false,
    enabled: true,
    promoText: "",
  });

  useEffect(() => {
    const firstId = productsQuery.data?.[0]?.id;
    if (!selectedId && firstId) {
      setSelectedId(firstId);
    }
  }, [productsQuery.data, selectedId]);

  const selectedProduct = (productsQuery.data || []).find((item: any) => item.id === selectedId);

  useEffect(() => {
    if (!selectedProduct) {
      return;
    }

    setForm({
      displayName: selectedProduct.displayName || "",
      salePrice: String(selectedProduct.salePrice || ""),
      hidden: Boolean(selectedProduct.hidden),
      enabled: Boolean(selectedProduct.enabled),
      promoText: selectedProduct.promoText || "",
    });
  }, [selectedProduct?.id]);

  const updateMutation = useMutation({
    mutationFn: async () =>
      api.put(`/products/${selectedId}`, {
        displayName: form.displayName,
        salePrice: Number(form.salePrice || 0),
        hidden: form.hidden,
        enabled: form.enabled,
        promoText: form.promoText,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Điều khiển catalog</p>
        <h1 className="mt-3 font-display text-4xl font-bold text-white">Sản phẩm</h1>
      </div>
      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="overflow-hidden">
          <div className="mb-4">
            <h2 className="font-display text-2xl font-bold text-white">Danh sách sản phẩm</h2>
            <p className="text-sm text-slate-400">
              Danh sách hợp nhất giữa sản phẩm nguồn và cấu hình override của seller.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3">Tên hiển thị</th>
                  <th className="pb-3">Tên nguồn</th>
                  <th className="pb-3">Giá gốc</th>
                  <th className="pb-3">Giá bán</th>
                  <th className="pb-3">Tồn kho</th>
                  <th className="pb-3">Đã bán</th>
                </tr>
              </thead>
              <tbody>
                {(productsQuery.data || []).map((product: any) => (
                  <tr
                    key={product.id}
                    className={`cursor-pointer border-t border-white/5 text-slate-300 transition ${
                      selectedId === product.id ? "bg-white/5" : ""
                    }`}
                    onClick={() => setSelectedId(product.id)}
                  >
                    <td className="py-3">{product.displayName}</td>
                    <td className="py-3 text-slate-400">{product.sourceName}</td>
                    <td className="py-3">{formatCurrency(product.sourcePrice)}</td>
                    <td className="py-3 text-emerald-300">{formatCurrency(product.salePrice)}</td>
                    <td className="py-3">{product.available ?? "-"}</td>
                    <td className="py-3">{product.soldCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <div className="mb-4">
            <h2 className="font-display text-2xl font-bold text-white">Chỉnh sửa override</h2>
          </div>
          {selectedProduct ? (
            <div className="space-y-4">
              <Input
                value={form.displayName}
                onChange={(event) =>
                  setForm((current) => ({ ...current, displayName: event.target.value }))
                }
                placeholder="Tên hiển thị trên bot"
              />
              <Input
                value={form.salePrice}
                onChange={(event) =>
                  setForm((current) => ({ ...current, salePrice: event.target.value }))
                }
                placeholder="Giá bán"
              />
              <Textarea
                value={form.promoText}
                onChange={(event) =>
                  setForm((current) => ({ ...current, promoText: event.target.value }))
                }
                placeholder="Thông điệp khuyến mãi / mô tả ngắn"
              />
              <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-300">
                <input
                  checked={form.enabled}
                  type="checkbox"
                  onChange={(event) =>
                    setForm((current) => ({ ...current, enabled: event.target.checked }))
                  }
                />
                Hiển thị để bán
              </label>
              <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-300">
                <input
                  checked={form.hidden}
                  type="checkbox"
                  onChange={(event) =>
                    setForm((current) => ({ ...current, hidden: event.target.checked }))
                  }
                />
                Ẩn trên bot
              </label>
              <Button
                className="w-full"
                disabled={updateMutation.isPending || !selectedId}
                onClick={() => updateMutation.mutate()}
              >
                {updateMutation.isPending ? "Đang lưu..." : "Lưu override"}
              </Button>
            </div>
          ) : (
            <p className="text-slate-400">Chọn một sản phẩm để chỉnh sửa.</p>
          )}
        </Card>
      </div>
    </div>
  );
}
