import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

export function WalletPage() {
  const queryClient = useQueryClient();
  const [depositAmount, setDepositAmount] = useState("500000");
  const [withdrawAmount, setWithdrawAmount] = useState("150000");
  const [bankName, setBankName] = useState("Vietcombank");
  const [bankAccountNumber, setBankAccountNumber] = useState("0123456789");
  const [bankAccountName, setBankAccountName] = useState("Seller mẫu");

  const walletQuery = useQuery({
    queryKey: ["wallet"],
    queryFn: async () => (await api.get("/wallet")).data,
  });
  const ledgersQuery = useQuery({
    queryKey: ["wallet", "ledgers"],
    queryFn: async () => (await api.get("/wallet/ledgers")).data,
  });
  const depositRequestsQuery = useQuery({
    queryKey: ["wallet", "deposits"],
    queryFn: async () => (await api.get("/wallet/deposit-requests")).data,
  });
  const withdrawRequestsQuery = useQuery({
    queryKey: ["wallet", "withdraws"],
    queryFn: async () => (await api.get("/wallet/withdraw-requests")).data,
  });

  const depositMutation = useMutation({
    mutationFn: async () =>
      api.post("/wallet/deposit-requests", {
        amount: Number(depositAmount),
        note: "Yêu cầu nạp từ dashboard",
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["wallet", "deposits"] });
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async () =>
      api.post("/wallet/withdraw-requests", {
        amount: Number(withdrawAmount),
        bankName,
        bankAccountNumber,
        bankAccountName,
        note: "Yêu cầu rút từ dashboard",
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["wallet", "withdraws"] });
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Vận hành ví</p>
        <h1 className="mt-3 font-display text-4xl font-bold text-white">Nạp vào ví / Rút ví</h1>
      </div>
      <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-6">
          <Card>
            <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Số dư hiện tại</p>
            <p className="mt-4 font-display text-4xl font-bold text-white">
              {formatCurrency(walletQuery.data?.balance || 0)}
            </p>
          </Card>

          <Card className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">Nạp ví</h2>
            <Input
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              placeholder="Số tiền muốn nạp"
            />
            <Button className="w-full" onClick={() => depositMutation.mutate()}>
              {depositMutation.isPending ? "Đang gửi..." : "Tạo lệnh nạp"}
            </Button>
          </Card>

          <Card className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">Rút ví</h2>
            <Input
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              placeholder="Số tiền muốn rút"
            />
            <Input
              value={bankName}
              onChange={(e) => setBankName(e.target.value)}
              placeholder="Tên ngân hàng"
            />
            <Input
              value={bankAccountNumber}
              onChange={(e) => setBankAccountNumber(e.target.value)}
              placeholder="Số tài khoản"
            />
            <Input
              value={bankAccountName}
              onChange={(e) => setBankAccountName(e.target.value)}
              placeholder="Tên chủ tài khoản"
            />
            <Button className="w-full" onClick={() => withdrawMutation.mutate()}>
              {withdrawMutation.isPending ? "Đang gửi..." : "Tạo yêu cầu rút"}
            </Button>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <h2 className="mb-4 font-display text-2xl font-bold text-white">Lịch sử ví</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="text-slate-500">
                  <tr>
                    <th className="pb-3">Loại</th>
                    <th className="pb-3">Số tiền</th>
                    <th className="pb-3">Trước</th>
                    <th className="pb-3">Sau</th>
                    <th className="pb-3">Thời gian</th>
                  </tr>
                </thead>
                <tbody>
                  {(ledgersQuery.data || []).map((ledger: any) => (
                    <tr key={ledger.id} className="border-t border-white/5 text-slate-300">
                      <td className="py-3 uppercase tracking-[0.18em] text-xs text-slate-500">
                        {formatStatusLabel(ledger.type)}
                      </td>
                      <td className="py-3">{formatCurrency(ledger.amount)}</td>
                      <td className="py-3">{formatCurrency(ledger.balanceBefore)}</td>
                      <td className="py-3">{formatCurrency(ledger.balanceAfter)}</td>
                      <td className="py-3">{formatDate(ledger.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <h2 className="mb-4 font-display text-2xl font-bold text-white">Lịch sử nạp</h2>
              <div className="space-y-3">
                {(depositRequestsQuery.data || []).map((item: any) => (
                  <div key={item.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                    <p className="font-semibold text-white">{formatCurrency(item.amount)}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.18em] text-slate-500">
                      {formatStatusLabel(item.status)}
                    </p>
                  </div>
                ))}
              </div>
            </Card>
            <Card>
              <h2 className="mb-4 font-display text-2xl font-bold text-white">Lịch sử rút</h2>
              <div className="space-y-3">
                {(withdrawRequestsQuery.data || []).map((item: any) => (
                  <div key={item.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                    <p className="font-semibold text-white">{formatCurrency(item.amount)}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.18em] text-slate-500">
                      {formatStatusLabel(item.status)}
                    </p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
