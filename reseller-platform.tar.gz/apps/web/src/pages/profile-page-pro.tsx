import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ShieldCheck, Store, UserCircle2 } from "lucide-react";

import { useAuth } from "@/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { StatChip } from "@/components/dashboard/stat-chip";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/api";
import { formatRoleLabel } from "@/lib/format";

export function ProfilePage() {
  const { session, changePassword, updateRecoveryEmail } = useAuth();
  const shopQuery = useQuery({
    queryKey: ["shop", "profile"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [recoveryEmail, setRecoveryEmail] = useState(session?.user.recoveryEmail || "");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [emailSuccess, setEmailSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [emailSubmitting, setEmailSubmitting] = useState(false);

  useEffect(() => {
    setRecoveryEmail(session?.user.recoveryEmail || "");
  }, [session?.user.recoveryEmail]);

  async function handleUpdateRecoveryEmail(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setEmailError(null);
    setEmailSuccess(null);

    const normalizedEmail = recoveryEmail.trim();

    if (normalizedEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      setEmailError("Email khôi phục không hợp lệ.");
      return;
    }

    try {
      setEmailSubmitting(true);
      await updateRecoveryEmail(normalizedEmail || null);
      setEmailSuccess(normalizedEmail ? "Đã lưu email khôi phục." : "Đã xóa email khôi phục.");
    } catch (submissionError: any) {
      setEmailError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể cập nhật email khôi phục.",
      );
    } finally {
      setEmailSubmitting(false);
    }
  }

  async function handleChangePassword(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError("Vui lòng điền đầy đủ thông tin.");
      return;
    }

    if (newPassword.length < 6) {
      setError("Mật khẩu mới phải có ít nhất 6 ký tự.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setError("Mật khẩu xác nhận không khớp.");
      return;
    }

    if (currentPassword === newPassword) {
      setError("Mật khẩu mới phải khác mật khẩu hiện tại.");
      return;
    }

    try {
      setSubmitting(true);
      await changePassword(currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setSuccess("Đổi mật khẩu thành công. Phiên đăng nhập đã được làm mới.");
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể đổi mật khẩu lúc này.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Tài khoản & bảo mật"
        title="Hồ sơ seller"
        description="Quản lý thông tin tài khoản đang đăng nhập, shop hiện tại và cập nhật mật khẩu trực tiếp trong dashboard."
      />

      <section className="grid gap-4 md:grid-cols-3">
        <StatChip
          icon={UserCircle2}
          label="Tài khoản"
          value={session?.user.displayName || "Seller"}
          meta={session?.user.email}
          tone="amber"
        />
        <StatChip
          icon={Store}
          label="Shop"
          value={shopQuery.data?.name || "Chưa đặt tên"}
          meta={shopQuery.data?.tagline || "Chưa có tagline"}
          tone="amber"
        />
        <StatChip
          icon={ShieldCheck}
          label="Quyền hiện tại"
          value={formatRoleLabel(session?.user.role)}
          meta="Phiên seller đang hoạt động"
          tone="amber"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-2">
        <Card>
          <p className="app-kicker">Thông tin tài khoản</p>
          <h2 className="mt-3 font-display text-3xl font-semibold text-white">Tài khoản</h2>
          <div className="mt-6 space-y-4">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.04] px-4 py-4">
              <p className="app-kicker">Tên hiển thị</p>
              <p className="mt-2 text-lg font-semibold text-white">
                {session?.user.displayName || "Seller"}
              </p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.04] px-4 py-4">
              <p className="app-kicker">Username</p>
              <p className="mt-2 text-lg font-semibold text-white">{session?.user.email}</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.04] px-4 py-4">
              <p className="app-kicker">Email khôi phục</p>
              <p className="mt-2 text-lg font-semibold text-white">
                {session?.user.recoveryEmail || "Chưa thêm"}
              </p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.04] px-4 py-4">
              <p className="app-kicker">Vai trò</p>
              <p className="mt-2 text-lg font-semibold text-white">
                {formatRoleLabel(session?.user.role)}
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <p className="app-kicker">Thông tin shop</p>
          <h2 className="mt-3 font-display text-3xl font-semibold text-white">Shop đang vận hành</h2>
          <div className="mt-6 space-y-4">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.04] px-4 py-4">
              <p className="app-kicker">Tên shop</p>
              <p className="mt-2 text-lg font-semibold text-white">{shopQuery.data?.name || "-"}</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.04] px-4 py-4">
              <p className="app-kicker">Tagline</p>
              <p className="mt-2 text-lg font-semibold text-white">
                {shopQuery.data?.tagline || "Chưa có tagline"}
              </p>
            </div>
          </div>
        </Card>
      </section>

      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="app-kicker">Khôi phục tài khoản</p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-white">
              Email khôi phục
            </h2>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-400">
              Email này dùng để nhận link đặt lại mật khẩu khi quên mật khẩu đăng nhập.
            </p>
          </div>
          <div className="rounded-[18px] border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-slate-400">
            Có thể để trống
          </div>
        </div>

        <form className="mt-6 space-y-4" onSubmit={handleUpdateRecoveryEmail}>
          <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-200" htmlFor="recoveryEmail">
                Email khôi phục
              </label>
              <Input
                id="recoveryEmail"
                placeholder="name@example.com"
                type="email"
                value={recoveryEmail}
                onChange={(event) => setRecoveryEmail(event.target.value)}
              />
            </div>
            <Button disabled={emailSubmitting} size="lg" type="submit">
              {emailSubmitting ? "Đang lưu..." : "Lưu email"}
            </Button>
          </div>

          {emailError ? (
            <div className="rounded-[20px] border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
              {emailError}
            </div>
          ) : null}

          {emailSuccess ? (
            <div className="rounded-[20px] border border-emerald-400/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100">
              {emailSuccess}
            </div>
          ) : null}
        </form>
      </Card>

      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="app-kicker">Bảo mật tài khoản</p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-white">
              Đổi mật khẩu
            </h2>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-400">
              Nhập mật khẩu hiện tại và thiết lập mật khẩu mới. Sau khi đổi thành công, hệ thống sẽ
              làm mới phiên đăng nhập hiện tại và thu hồi refresh token cũ.
            </p>
          </div>
          <div className="rounded-[18px] border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-slate-400">
            Tối thiểu 6 ký tự
          </div>
        </div>

        <form className="mt-6 space-y-4" onSubmit={handleChangePassword}>
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-200" htmlFor="currentPassword">
                Mật khẩu hiện tại
              </label>
              <Input
                id="currentPassword"
                type="password"
                value={currentPassword}
                onChange={(event) => setCurrentPassword(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-200" htmlFor="newPassword">
                Mật khẩu mới
              </label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(event) => setNewPassword(event.target.value)}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-200" htmlFor="confirmPassword">
                Xác nhận mật khẩu mới
              </label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
              />
            </div>
          </div>

          {error ? (
            <div className="rounded-[20px] border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
              {error}
            </div>
          ) : null}

          {success ? (
            <div className="rounded-[20px] border border-emerald-400/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100">
              {success}
            </div>
          ) : null}

          <div className="flex justify-end">
            <Button disabled={submitting} size="lg" type="submit">
              {submitting ? "Đang cập nhật..." : "Cập nhật mật khẩu"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
