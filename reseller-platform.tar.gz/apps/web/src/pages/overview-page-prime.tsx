import { useQuery } from "@tanstack/react-query";
import { Bot, CircleDollarSign, PackageCheck, RefreshCw, Wallet } from "lucide-react";

import {
  StudioBadge,
  StudioButton,
  StudioCard,
  StudioMetric,
  StudioSectionIntro,
} from "@/components/studio/studio-ui";
import { InfoHint } from "@/components/ui/info-hint";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function getStatusTone(status: string) {
  if (status === "delivered") return "success" as const;
  if (status === "paid_waiting_stock") return "warning" as const;
  if (status === "failed" || status === "refunded") return "danger" as const;
  return "neutral" as const;
}

export function OverviewPagePrime() {
  const shopQuery = useQuery({
    queryKey: ["shop"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });
  const sourceWalletQuery = useQuery({
    queryKey: ["wallet", "source-balance", "overview"],
    queryFn: async () => (await api.get("/wallet/source-balance")).data,
    retry: false,
  });
  const ordersQuery = useQuery({
    queryKey: ["orders", "overview"],
    queryFn: async () => (await api.get("/orders")).data,
  });
  const revenueQuery = useQuery({
    queryKey: ["revenue", "overview"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });
  const topBuyersQuery = useQuery({
    queryKey: ["top-buyers", "overview"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  const orders = ordersQuery.data || [];
  const topBuyers = topBuyersQuery.data || [];
  const deliveredOrders = orders.filter(
    (item: any) => String(item.status || "").toLowerCase() === "delivered",
  );
  const watchOrders = orders.filter((item: any) =>
    ["awaiting_payment", "paid", "processing_purchase", "paid_waiting_stock"].includes(
      String(item.status || "").toLowerCase(),
    ),
  );
  const latestOrder = orders[0];

  const sourceWalletValue =
    sourceWalletQuery.data?.walletCurrency === "VND"
      ? formatCurrency(Number(sourceWalletQuery.data?.balance || 0))
      : sourceWalletQuery.data?.balanceText ||
        `${Number(sourceWalletQuery.data?.balance || 0)} ${
          sourceWalletQuery.data?.walletCurrency || ""
        }`.trim();

  const refreshAll = () => {
    void Promise.all([
      shopQuery.refetch(),
      sourceWalletQuery.refetch(),
      ordersQuery.refetch(),
      revenueQuery.refetch(),
      topBuyersQuery.refetch(),
    ]);
  };

  return (
    <div className="space-y-6">
      <StudioSectionIntro
        kicker="Trung tâm vận hành"
        title="Tổng quan bán hàng"
        description={`Theo dõi bot, ví nguồn, đơn gần đây và nhịp bán của ${
          shopQuery.data?.name || "shop hiện tại"
        } từ một màn hình gọn và dễ quét.`}
        actions={
          <>
            <StudioBadge tone="neutral">
              Shop: {shopQuery.data?.name || "Chưa đặt tên"}
            </StudioBadge>
            <StudioBadge tone="success">
              {shopQuery.data?.status ? formatStatusLabel(shopQuery.data.status) : "Đang hoạt động"}
            </StudioBadge>
            <StudioButton variant="secondary" onClick={refreshAll}>
              <RefreshCw className="h-4 w-4" />
              Làm mới
            </StudioButton>
          </>
        }
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StudioMetric
          label="Trạng thái bot"
          value={shopQuery.data?.status ? formatStatusLabel(shopQuery.data.status) : "Đang chờ"}
          description={`Lần đồng bộ gần nhất: ${formatDate(shopQuery.data?.lastCatalogSyncAt)}`}
          icon={Bot}
          tone="sky"
        />
        <StudioMetric
          label="Ví nguồn Canboso"
          value={sourceWalletValue}
          description="Số dư thật của buyer key đang dùng để mua nguồn."
          icon={Wallet}
          tone="amber"
        />
        <StudioMetric
          label="Doanh thu tháng"
          value={formatCurrency(revenueQuery.data?.summary?.grossRevenue || 0)}
          description={`${deliveredOrders.length} đơn đã giao thành công trong kỳ hiện tại.`}
          icon={CircleDollarSign}
          tone="emerald"
        />
        <StudioMetric
          label="Đơn cần theo dõi"
          value={String(watchOrders.length)}
          description="Bao gồm đơn chờ thanh toán, chờ hàng hoặc đang xử lý mua nguồn."
          icon={PackageCheck}
          tone="violet"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.35fr_0.65fr]">
        <StudioCard>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                Luồng đơn gần đây
              </p>
              <h2 className="mt-3 text-3xl font-semibold text-white">Đơn mới nhất</h2>
            </div>
            <InfoHint
              content="Hiển thị các đơn mới nhất để seller quét nhanh mã đơn, trạng thái và tổng tiền."
              label="Xem ghi chú cho Đơn mới nhất"
            />
          </div>

          <div className="app-table-wrap mt-6">
            <table className="app-table">
              <thead>
                <tr>
                  <th>Mã đơn</th>
                  <th>Sản phẩm</th>
                  <th>Khách</th>
                  <th>Trạng thái</th>
                  <th className="text-right">Tổng tiền</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 6).map((order: any) => (
                  <tr key={order.id}>
                    <td>
                      <p className="font-semibold text-white">{order.orderCode}</p>
                      <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">
                        {formatDate(order.createdAt)}
                      </p>
                    </td>
                    <td>
                      <p className="font-medium text-white">{order.productName}</p>
                      <p className="mt-1 text-sm text-slate-500">{order.product?.sourceName || "-"}</p>
                    </td>
                    <td>{order.customer?.telegramUsername || order.customer?.name || "-"}</td>
                    <td>
                      <StudioBadge tone={getStatusTone(order.status)}>
                        {formatStatusLabel(order.status)}
                      </StudioBadge>
                    </td>
                    <td className="text-right font-semibold text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </td>
                  </tr>
                ))}
                {!orders.length ? (
                  <tr>
                    <td colSpan={5} className="text-sm text-slate-400">
                      Chưa có đơn hàng nào để hiển thị.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </StudioCard>

        <div className="space-y-6">
          <StudioCard>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Đơn mới nhất
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-white">
                  {latestOrder?.orderCode || "Chưa có dữ liệu"}
                </h2>
                <p className="mt-2 text-sm text-slate-400">
                  {latestOrder
                    ? `${latestOrder.productName} • ${formatDate(latestOrder.createdAt)}`
                    : "Chưa có đơn mới"}
                </p>
              </div>
              {latestOrder ? (
                <StudioBadge tone={getStatusTone(latestOrder.status)}>
                  {formatStatusLabel(latestOrder.status)}
                </StudioBadge>
              ) : null}
            </div>

            <div className="mt-6 grid gap-3">
              <div className="rounded-[20px] border border-white/8 bg-white/[0.03] p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Giá trị đơn
                </p>
                <p className="mt-2 text-lg font-semibold text-white">
                  {latestOrder ? formatCurrency(latestOrder.totalSaleAmount) : "-"}
                </p>
              </div>
              <div className="rounded-[20px] border border-white/8 bg-white/[0.03] p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Khách mua
                </p>
                <p className="mt-2 text-lg font-semibold text-white">
                  {latestOrder?.customer?.telegramUsername || latestOrder?.customer?.name || "-"}
                </p>
              </div>
            </div>
          </StudioCard>

          <StudioCard>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Top người mua
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-white">Khách giá trị cao</h2>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-emerald-300/20 bg-emerald-400/10 text-emerald-100">
                <CircleDollarSign className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-6 space-y-3">
              {topBuyers.slice(0, 4).map((buyer: any, index: number) => (
                <div
                  key={buyer.customerId}
                  className="flex items-center justify-between rounded-[22px] border border-white/8 bg-white/[0.03] px-4 py-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-white/8 bg-slate-950/45 text-sm font-semibold text-white">
                      {String(index + 1).padStart(2, "0")}
                    </div>
                    <div>
                      <p className="font-medium text-white">{buyer.name}</p>
                      <p className="mt-1 text-sm text-slate-500">{buyer.totalOrders} đơn đã mua</p>
                    </div>
                  </div>
                  <p className="font-semibold text-emerald-200">{formatCurrency(buyer.totalSpent)}</p>
                </div>
              ))}
              {!topBuyers.length ? (
                <div className="rounded-[22px] border border-dashed border-white/10 bg-white/[0.02] px-4 py-6 text-sm text-slate-400">
                  Chưa có dữ liệu người mua nổi bật.
                </div>
              ) : null}
            </div>
          </StudioCard>
        </div>
      </section>
    </div>
  );
}
