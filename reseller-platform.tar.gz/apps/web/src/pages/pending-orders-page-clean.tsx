import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Clock3, RefreshCw, Wallet } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { MetricCard } from "@/components/metric-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

export function PendingOrdersPageClean() {
  const ordersQuery = useQuery({
    queryKey: ["orders", "pending"],
    queryFn: async () =>
      (await api.get("/orders", { params: { status: "PAID_WAITING_STOCK" } })).data,
  });

  const orders = ordersQuery.data || [];
  const totalValue = orders.reduce(
    (sum: number, order: any) => sum + Number(order.totalSaleAmount || 0),
    0,
  );
  const paidOrders = orders.filter((order: any) => order.paymentStatus === "PAID").length;

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Theo dõi xử lý"
        title="Đơn chờ xử lý"
        description="Theo dõi các đơn đang chờ có hàng, ưu tiên những trường hợp seller cần can thiệp và cập nhật lại cho khách."
        actions={
          <Button
            variant="secondary"
            onClick={() => {
              void ordersQuery.refetch();
            }}
          >
            <RefreshCw className="h-4 w-4" />
            Làm mới
          </Button>
        }
      />

      <div className="grid gap-4 xl:grid-cols-3">
        <MetricCard
          label="Đơn đang mở"
          value={String(orders.length)}
          description="Tổng số đơn seller đang cần theo dõi ở trạng thái chờ xử lý."
          icon={AlertTriangle}
          tone="amber"
        />
        <MetricCard
          label="Giá trị đơn"
          value={formatCurrency(totalValue)}
          description="Tổng giá trị doanh thu hiện nằm trong nhóm đơn chờ có hàng."
          icon={Wallet}
          tone="sky"
        />
        <MetricCard
          label="Đã thanh toán"
          value={String(paidOrders)}
          description="Số đơn đã thanh toán và cần tiếp tục giám sát để giao hàng."
          icon={Clock3}
          tone="emerald"
        />
      </div>

      {ordersQuery.isLoading ? (
        <div className="grid gap-4">
          {Array.from({ length: 3 }).map((_, index) => (
            <Card key={index} className="animate-pulse">
              <div className="h-5 w-28 rounded-full bg-white/8" />
              <div className="mt-4 h-8 w-72 rounded-xl bg-white/8" />
              <div className="mt-3 h-5 w-full max-w-2xl rounded-xl bg-white/8" />
              <div className="mt-6 grid gap-3 md:grid-cols-3">
                <div className="h-24 rounded-[18px] bg-white/8" />
                <div className="h-24 rounded-[18px] bg-white/8" />
                <div className="h-24 rounded-[18px] bg-white/8" />
              </div>
            </Card>
          ))}
        </div>
      ) : orders.length === 0 ? (
        <EmptyState
          title="Không có đơn chờ xử lý"
          description="Khi có đơn chờ có hàng hoặc cần seller theo dõi thêm, danh sách này sẽ tự động cập nhật."
        />
      ) : (
        <Card className="overflow-hidden p-0">
          <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
            <div>
              <p className="text-sm font-semibold text-white">Danh sách cần theo dõi</p>
              <p className="mt-1 text-sm text-slate-400">
                Các đơn ưu tiên mà seller cần bám sát để giữ trải nghiệm khách hàng.
              </p>
            </div>
            <Badge tone="warning">{orders.length} đơn mở</Badge>
          </div>

          <div className="divide-y divide-white/8">
            {orders.map((order: any) => (
              <div
                key={order.id}
                className="flex flex-col gap-5 px-5 py-5 xl:flex-row xl:items-center xl:gap-6"
              >
                <div className="min-w-0 xl:w-[34%]">
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge tone="warning">{formatStatusLabel(order.status)}</Badge>
                    <span className="text-sm text-slate-500">{formatDate(order.createdAt)}</span>
                  </div>
                  <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">
                    {order.orderCode}
                  </h3>
                  <p className="mt-2 text-sm leading-7 text-slate-400">
                    {order.productName} •{" "}
                    {order.customer?.telegramUsername || order.customer?.name || "-"}
                  </p>
                </div>

                <div className="xl:min-w-0 xl:flex-1">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                    Tóm tắt vấn đề
                  </p>
                  <p className="mt-3 rounded-[18px] border border-amber-400/18 bg-amber-500/8 px-4 py-3 text-sm leading-7 text-slate-200">
                    {order.failureReason ||
                      "Đơn đang chờ hệ thống thử mua lại khi upstream có hàng trở lại."}
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 xl:w-[320px]">
                  <div className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                      Giá trị đơn
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </p>
                  </div>
                  <div className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                      Thanh toán
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-white">
                      {formatStatusLabel(order.paymentStatus)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
