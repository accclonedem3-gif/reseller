import type { AxiosError } from "axios";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUpFromLine, Landmark, ReceiptText, Wallet } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { Field } from "@/components/dashboard/field";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { MetricCard } from "@/components/metric-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { InfoHint } from "@/components/ui/info-hint";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function getApiErrorMessage(error: unknown) {
  const fallbackMessage = "Co loi xay ra. Vui long kiem tra lai du lieu va thu lai.";
  const axiosError = error as AxiosError<{ message?: string | string[] }>;
  const apiMessage = axiosError.response?.data?.message;

  if (Array.isArray(apiMessage)) {
    return apiMessage.join(", ");
  }

  if (typeof apiMessage === "string" && apiMessage.trim() !== "") {
    return apiMessage;
  }

  return fallbackMessage;
}

export function WalletPage() {
  const queryClient = useQueryClient();
  const [withdrawAmount, setWithdrawAmount] = useState("150000");
  const [bankName, setBankName] = useState("");
  const [bankAccountNumber, setBankAccountNumber] = useState("");
  const [bankAccountName, setBankAccountName] = useState("");

  const { showToast } = useToast();

  const walletQuery = useQuery({
    queryKey: ["wallet"],
    queryFn: async () => (await api.get("/wallet")).data,
    refetchInterval: 5000,
  });
  const sourceWalletQuery = useQuery({
    queryKey: ["wallet", "source-balance"],
    queryFn: async () => (await api.get("/wallet/source-balance")).data,
    refetchInterval: 15000,
    retry: false,
  });
  const ledgersQuery = useQuery({
    queryKey: ["wallet", "ledgers"],
    queryFn: async () => (await api.get("/wallet/ledgers")).data,
    refetchInterval: 5000,
  });
  const withdrawRequestsQuery = useQuery({
    queryKey: ["wallet", "withdraws"],
    queryFn: async () => (await api.get("/wallet/withdraw-requests")).data,
    refetchInterval: 5000,
  });

  const withdrawMutation = useMutation({
    mutationFn: async () =>
      api.post("/wallet/withdraw-requests", {
        amount: Number(withdrawAmount),
        bankName,
        bankAccountNumber,
        bankAccountName,
        note: "Yêu cầu rút từ dashboard",
      }),
    onSuccess: async () => {
      showToast({
        tone: "success",
        message: "Da tao yeu cau rut. So tien cho rut da duoc tru khoi han muc kha dung.",
      });
      setWithdrawAmount("");
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["wallet"] }),
        queryClient.invalidateQueries({ queryKey: ["wallet", "withdraws"] }),
      ]);
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const pendingWithdrawAmount = useMemo(
    () =>
      (withdrawRequestsQuery.data || [])
        .filter((item: any) => item.status === "PENDING")
        .reduce((sum: number, item: any) => sum + Number(item.amount || 0), 0),
    [withdrawRequestsQuery.data],
  );

  const withdrawableBalance = Number(
    walletQuery.data?.withdrawableBalance ?? walletQuery.data?.balance ?? 0,
  );
  const sourceWalletValue =
    sourceWalletQuery.data?.walletCurrency === "VND"
      ? formatCurrency(Number(sourceWalletQuery.data?.balance || 0))
      : sourceWalletQuery.data?.balanceText ||
        `${Number(sourceWalletQuery.data?.balance || 0)} ${sourceWalletQuery.data?.walletCurrency || ""}`.trim();
  const isWithdrawFormInvalid =
    !withdrawAmount.trim() ||
    !Number.isInteger(Number(withdrawAmount)) ||
    Number(withdrawAmount) < 1000 ||
    Number(withdrawAmount) > withdrawableBalance ||
    !bankName.trim() ||
    !bankAccountNumber.trim() ||
    !bankAccountName.trim();

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Ví seller"
        title="Theo dõi ví nguồn và ví nội bộ"
        description="Trang này ưu tiên hiển thị số dư ví nguồn Canboso để seller biết khả năng mua nguồn hiện tại. Tính năng nạp ví seller qua web đã được tắt để tránh nhầm với ví nguồn."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Ví nội bộ"
          value={formatCurrency(walletQuery.data?.balance || 0)}
          description="Sổ phụ nội bộ của hệ thống, không phải số dư thật ở bot nguồn."
          icon={Wallet}
          tone="amber"
        />
        <MetricCard
          label="Ví nguồn Canboso"
          value={sourceWalletValue}
          description="Số dư thật của buyer key đang dùng để mua nguồn."
          icon={Wallet}
          tone="amber"
        />
        <MetricCard
          label="Chờ rút"
          value={formatCurrency(pendingWithdrawAmount)}
          description="Số tiền seller đã yêu cầu rút và đang chờ xử lý."
          icon={ArrowUpFromLine}
          tone="amber"
        />
        <MetricCard
          label="Số bút toán"
          value={String((ledgersQuery.data || []).length)}
          description="Lượng ledger đang hiển thị trong cửa sổ theo dõi hiện tại."
          icon={ReceiptText}
          tone="amber"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-6">
          <Card>
            <p className="app-kicker">Số dư ví</p>
            <h2 className="mt-3 font-display text-4xl font-semibold text-white">
              {formatCurrency(walletQuery.data?.balance || 0)}
            </h2>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <div className="glass-chip rounded-[20px] px-4 py-4">
                <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Có thể rút</p>
                <p className="mt-2 font-semibold text-white">{formatCurrency(withdrawableBalance)}</p>
              </div>
              <div className="glass-chip rounded-[20px] px-4 py-4">
                <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Đang chờ rút</p>
                <p className="mt-2 font-semibold text-white">{formatCurrency(pendingWithdrawAmount)}</p>
              </div>
              <div className="glass-chip rounded-[20px] px-4 py-4 sm:col-span-2">
                <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Vi nguon Canboso</p>
                <p className="mt-2 font-semibold text-white">{sourceWalletValue}</p>
                <p className="mt-2 text-xs text-slate-500">
                  {sourceWalletQuery.data?.updatedAt
                    ? `Cập nhật ${formatDate(sourceWalletQuery.data.updatedAt)}`
                    : "Đang đồng bộ số dư"}
                </p>
              </div>
            </div>
            <div className="mt-3">
              <InfoHint
                content="Ví seller trên web chỉ là sổ phụ nội bộ. Muốn tăng sức mua thật, seller cần nạp trực tiếp ở bot nguồn Canboso."
                label="Xem ghi chú cho Số dư ví"
              />
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Nạp ví nguồn</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Nạp trực tiếp ở Canboso
                </h2>
              </div>
              <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
                <Wallet className="h-5 w-5 text-emerald-100" />
              </span>
            </div>

            <div className="mt-6 space-y-3 text-sm text-slate-400">
              <InfoHint
                content="Tính năng nạp ví seller qua web đã được tắt để tránh nhầm với ví nguồn thật của buyer key."
                label="Xem ghi chú cho Nạp ví nguồn"
              />
              <div className="glass-chip rounded-[20px] px-4 py-4">
                <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                  Số dư ví nguồn hiện tại
                </p>
                <p className="mt-2 font-semibold text-white">{sourceWalletValue}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Yêu cầu rút</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">Rút ví</h2>
              </div>
              <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
                <Landmark className="h-5 w-5 text-amber-100" />
              </span>
            </div>

            <div className="mt-6 grid gap-5">
              <Field label="Số tiền muốn rút" hint="VND">
                <Input
                  value={withdrawAmount}
                  onChange={(event) => setWithdrawAmount(event.target.value)}
                  placeholder="Số tiền muốn rút"
                />
              </Field>
              <p className="text-sm text-slate-500">
                Số dư khả dụng để rút hiện tại: {formatCurrency(withdrawableBalance)}.
              </p>
              <Field label="Ngân hàng" hint="Bank">
                <Input
                  value={bankName}
                  onChange={(event) => setBankName(event.target.value)}
                  placeholder="Tên ngân hàng"
                />
              </Field>
              <Field label="Số tài khoản" hint="Account">
                <Input
                  value={bankAccountNumber}
                  onChange={(event) => setBankAccountNumber(event.target.value)}
                  placeholder="Số tài khoản"
                />
              </Field>
              <Field label="Chủ tài khoản" hint="Owner">
                <Input
                  value={bankAccountName}
                  onChange={(event) => setBankAccountName(event.target.value)}
                  placeholder="Tên chủ tài khoản"
                />
              </Field>
              <Button
                className="w-full"
                disabled={withdrawMutation.isPending || isWithdrawFormInvalid}
                onClick={() => withdrawMutation.mutate()}
              >
                {withdrawMutation.isPending ? "Đang gửi yêu cầu..." : "Tạo yêu cầu rút"}
              </Button>
              <InfoHint
                content="Cần nhập đủ ngân hàng, số tài khoản và chủ tài khoản. Hệ thống sẽ từ chối nếu vượt quá số dư khả dụng."
                label="Xem ghi chú cho Rút ví"
              />
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Ledger timeline</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Lịch sử ví
                </h2>
              </div>
              <div className="glass-chip rounded-full px-3 py-1.5 text-xs text-slate-200">
                {(ledgersQuery.data || []).length} bút toán
              </div>
            </div>

            {(ledgersQuery.data || []).length === 0 ? (
              <div className="mt-6">
                <EmptyState
                  title="Chưa có bút toán"
                  description="Ledger sẽ xuất hiện tại đây khi seller có rút, debit hoặc refund từ các nghiệp vụ đơn hàng."
                />
              </div>
            ) : (
              <div className="mt-6 app-table-wrap">
                <table className="app-table">
                  <thead>
                    <tr>
                      <th>Loại</th>
                      <th>Số tiền</th>
                      <th>Trước</th>
                      <th>Sau</th>
                      <th>Thời gian</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(ledgersQuery.data || []).map((ledger: any) => (
                      <tr key={ledger.id}>
                        <td>
                          <Badge
                            tone={ledger.amount > 0 ? "success" : ledger.amount < 0 ? "warning" : "neutral"}
                          >
                            {formatStatusLabel(ledger.type)}
                          </Badge>
                        </td>
                        <td className={ledger.amount > 0 ? "text-emerald-200" : "text-emerald-100"}>
                          {formatCurrency(ledger.amount)}
                        </td>
                        <td>{formatCurrency(ledger.balanceBefore)}</td>
                        <td>{formatCurrency(ledger.balanceAfter)}</td>
                        <td>{formatDate(ledger.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card>
            <p className="app-kicker">Withdraw history</p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-white">Lịch sử rút</h2>
            <div className="mt-6 space-y-3">
              {(withdrawRequestsQuery.data || []).map((item: any) => (
                <div key={item.id} className="glass-chip rounded-[22px] px-4 py-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-semibold text-white">{formatCurrency(item.amount)}</p>
                    <Badge tone={item.status === "APPROVED" ? "success" : "warning"}>
                      {formatStatusLabel(item.status)}
                    </Badge>
                  </div>
                  <p className="mt-2 text-sm text-slate-500">
                    {item.bankName || "-"} • {item.bankAccountNumber || "-"}
                  </p>
                  <p className="mt-3 text-sm text-slate-500">{formatDate(item.createdAt)}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
