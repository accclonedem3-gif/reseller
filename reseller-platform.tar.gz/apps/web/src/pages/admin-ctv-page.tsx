import type { AxiosError } from "axios";
import { LockKeyhole, PencilLine, ShieldPlus, Store, Trash2, UnlockKeyhole, UserRoundPlus } from "lucide-react";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { EmptyState } from "@/components/dashboard/empty-state";
import { Field } from "@/components/dashboard/field";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

type SellerAccount = {
  id: string;
  username: string;
  recoveryEmail: string | null;
  role: string;
  status: string;
  createdAt: string;
  displayName: string | null;
  sellerStatus: string | null;
  shopId: string | null;
  shopName: string | null;
  shopSlug: string | null;
  shopStatus: string | null;
  walletBalance: number;
};

function getApiErrorMessage(error: unknown) {
  const fallbackMessage = "Có lỗi xảy ra. Hãy kiểm tra lại dữ liệu rồi thử lại.";
  const axiosError = error as AxiosError<{ message?: string | string[] }>;
  const apiMessage = axiosError.response?.data?.message;

  if (Array.isArray(apiMessage)) {
    return apiMessage.join(", ");
  }

  if (typeof apiMessage === "string" && apiMessage.trim() !== "") {
    return apiMessage;
  }

  return fallbackMessage;
}

export function AdminCtvPage() {
  const queryClient = useQueryClient();
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [recoveryEmail, setRecoveryEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [shopName, setShopName] = useState("");
  const [editingAccount, setEditingAccount] = useState<SellerAccount | null>(null);
  const { showToast } = useToast();

  const accountsQuery = useQuery({
    queryKey: ["admin", "ctv"],
    queryFn: async () => (await api.get<SellerAccount[]>("/admin/ctv")).data,
  });

  function resetForm() {
    setDisplayName("");
    setUsername("");
    setRecoveryEmail("");
    setPassword("");
    setConfirmPassword("");
    setShopName("");
    setEditingAccount(null);
  }

  function startEditing(account: SellerAccount) {
    setEditingAccount(account);
    setDisplayName(account.displayName || "");
    setUsername(account.username);
    setRecoveryEmail(account.recoveryEmail || "");
    setPassword("");
    setConfirmPassword("");
    setShopName(account.shopName || "");
  }

  const createMutation = useMutation({
    mutationFn: async () =>
      api.post("/admin/ctv", {
        displayName,
        username,
        recoveryEmail: recoveryEmail.trim() || undefined,
        password,
        shopName: shopName.trim() || undefined,
      }),
    onSuccess: async (response) => {
      showToast({
        tone: "success",
        message: `Đã tạo tài khoản CTV ${response.data.displayName} thành công.`,
      });
      resetForm();
      await queryClient.invalidateQueries({ queryKey: ["admin", "ctv"] });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async () =>
      api.put(`/admin/ctv/${editingAccount?.id}`, {
        displayName,
        username,
        recoveryEmail: recoveryEmail.trim() || null,
        password: password.trim() || undefined,
        shopName: shopName.trim() || undefined,
      }),
    onSuccess: async () => {
      showToast({
        tone: "success",
        message: "Đã cập nhật tài khoản CTV.",
      });
      resetForm();
      await queryClient.invalidateQueries({ queryKey: ["admin", "ctv"] });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({
      account,
      action,
    }: {
      account: SellerAccount;
      action: "lock" | "unlock";
    }) => api.post(`/admin/ctv/${account.id}/${action}`),
    onSuccess: async (response, variables) => {
      showToast({
        tone: "success",
        message:
          response.data?.message ||
          (variables.action === "lock"
            ? "Đã khóa tài khoản CTV."
            : "Đã mở khóa tài khoản CTV."),
      });
      await queryClient.invalidateQueries({ queryKey: ["admin", "ctv"] });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (account: SellerAccount) => api.delete(`/admin/ctv/${account.id}`),
    onSuccess: async (_response, account) => {
      showToast({
        tone: "success",
        message: `Đã xóa tài khoản ${account.username}.`,
      });
      if (editingAccount?.id === account.id) {
        resetForm();
      }
      await queryClient.invalidateQueries({ queryKey: ["admin", "ctv"] });
    },
    onError: (error) => {
      showToast({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const isFormInvalid = useMemo(() => {
    const normalizedRecoveryEmail = recoveryEmail.trim();
    const isRecoveryEmailInvalid =
      normalizedRecoveryEmail.length > 0 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedRecoveryEmail);

    return (
      displayName.trim().length < 2 ||
      username.trim().length < 2 ||
      isRecoveryEmailInvalid ||
      (editingAccount
        ? Boolean(password) && (password.length < 6 || confirmPassword !== password)
        : password.length < 6 || confirmPassword !== password)
    );
  }, [confirmPassword, displayName, editingAccount, password, recoveryEmail, username]);

  const accounts = accountsQuery.data || [];
  const isSubmitting = createMutation.isPending || updateMutation.isPending;
  const isEditMode = Boolean(editingAccount);

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Quản trị hệ thống"
        title="Tạo tài khoản CTV"
        description="Quản trị viên tạo trước username, mật khẩu và shop khởi tạo cho CTV. Sau khi đăng nhập, CTV sẽ tự cấu hình bot, buyer key và thanh toán của họ."
      />

      <section className="grid gap-6 xl:grid-cols-[0.92fr_1.08fr]">
        <Card>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="app-kicker">{isEditMode ? "Chỉnh sửa" : "Tạo mới"}</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                {isEditMode ? "Cập nhật tài khoản CTV" : "Cấp tài khoản cho CTV"}
              </h2>
            </div>
            <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
              {isEditMode ? (
                <PencilLine className="h-5 w-5 text-emerald-100" />
              ) : (
                <UserRoundPlus className="h-5 w-5 text-emerald-100" />
              )}
            </span>
          </div>

          <div className="mt-6 grid gap-5">
            <Field label="Tên hiển thị" hint="Required">
              <Input
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
                placeholder="Ví dụ: CTV Miền Nam"
              />
            </Field>
            <Field label="Username đăng nhập" hint="Required">
              <Input
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                placeholder="Ví dụ: ctvmiennam"
                type="text"
              />
            </Field>
            <Field
              label="Email khôi phục"
              hint="Optional"
              description="Dùng để gửi link đặt lại mật khẩu nếu CTV quên mật khẩu. Có thể bổ sung sau trong hồ sơ."
            >
              <Input
                value={recoveryEmail}
                onChange={(event) => setRecoveryEmail(event.target.value)}
                placeholder="Ví dụ: ctv@example.com"
                type="email"
              />
            </Field>
            <Field
              label="Tên shop khởi tạo"
              hint="Optional"
              description="Nếu bỏ trống, hệ thống sẽ dùng tên hiển thị làm tên shop ban đầu."
            >
              <Input
                value={shopName}
                onChange={(event) => setShopName(event.target.value)}
                placeholder="Ví dụ: CTV Miền Nam Shop"
              />
            </Field>
            <Field label="Mật khẩu tạm thời" hint="Min 6">
              <Input
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder={isEditMode ? "Bỏ trống nếu không đổi mật khẩu" : "Nhập mật khẩu"}
                type="password"
              />
            </Field>
            <Field label="Nhập lại mật khẩu" hint="Confirm">
              <Input
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                placeholder="Nhập lại mật khẩu"
                type="password"
              />
            </Field>

            <Button
              className="w-full"
              disabled={isSubmitting || isFormInvalid}
              onClick={() => {
                if (isEditMode) {
                  updateMutation.mutate();
                  return;
                }

                createMutation.mutate();
              }}
            >
              {isSubmitting
                ? isEditMode
                  ? "Đang cập nhật tài khoản..."
                  : "Đang tạo tài khoản..."
                : isEditMode
                  ? "Lưu thay đổi"
                  : "Tạo tài khoản CTV"}
            </Button>

            {isEditMode ? (
              <Button className="w-full" variant="secondary" onClick={resetForm}>
                Hủy chỉnh sửa
              </Button>
            ) : null}

            <div className="rounded-[18px] border border-white/10 bg-white/[0.03] px-4 py-4 text-sm leading-6 text-slate-400">
              Luồng công khai tự đăng ký đã tắt. Toàn bộ tài khoản CTV mới nên được tạo và quản trị từ màn này để dễ kiểm soát.
            </div>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Danh sách CTV</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Tài khoản đã tạo
                </h2>
              </div>
              <span className="glass-chip rounded-full px-3 py-1.5 text-xs text-slate-200">
                {accounts.length} tài khoản
              </span>
            </div>

            {accounts.length === 0 ? (
              <div className="mt-6">
                <EmptyState
                  title="Chưa có CTV nào"
                  description="Tạo tài khoản đầu tiên ở khung bên trái. Hệ thống sẽ tự khởi tạo seller, shop, ví và cấu hình mặc định."
                />
              </div>
            ) : (
              <div className="mt-6 space-y-3">
                {accounts.map((account) => (
                  <div key={account.id} className="glass-chip rounded-[22px] px-4 py-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-base font-semibold text-white">
                            {account.displayName || account.username}
                          </p>
                          <Badge tone="success">{formatStatusLabel(account.role)}</Badge>
                          <Badge tone={account.status === "active" ? "success" : "warning"}>
                            {formatStatusLabel(account.status)}
                          </Badge>
                        </div>
                        <p className="mt-2 text-sm text-slate-400">@{account.username}</p>
                        <p className="mt-1 text-sm text-slate-500">
                          Email khôi phục: {account.recoveryEmail || "Chưa thêm"}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs uppercase tracking-[0.18em] text-slate-500">
                          Tạo lúc
                        </p>
                        <p className="mt-1 text-sm font-medium text-slate-200">
                          {formatDate(account.createdAt)}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 grid gap-3 md:grid-cols-3">
                      <div className="rounded-[18px] border border-white/8 bg-[#111111] px-4 py-4">
                        <div className="flex items-center gap-2 text-slate-300">
                          <Store className="h-4 w-4 text-emerald-200" />
                          <span className="text-xs uppercase tracking-[0.18em] text-slate-500">
                            Shop
                          </span>
                        </div>
                        <p className="mt-2 font-semibold text-white">{account.shopName || "-"}</p>
                        <p className="mt-1 text-sm text-slate-500">{account.shopSlug || "-"}</p>
                      </div>
                      <div className="rounded-[18px] border border-white/8 bg-[#111111] px-4 py-4">
                        <div className="flex items-center gap-2 text-slate-300">
                          <ShieldPlus className="h-4 w-4 text-emerald-200" />
                          <span className="text-xs uppercase tracking-[0.18em] text-slate-500">
                            Trạng thái seller
                          </span>
                        </div>
                        <p className="mt-2 font-semibold text-white">
                          {formatStatusLabel(account.sellerStatus)}
                        </p>
                        <p className="mt-1 text-sm text-slate-500">
                          Shop: {formatStatusLabel(account.shopStatus)}
                        </p>
                      </div>
                      <div className="rounded-[18px] border border-white/8 bg-[#111111] px-4 py-4">
                        <p className="text-xs uppercase tracking-[0.18em] text-slate-500">
                          Số dư ví
                        </p>
                        <p className="mt-2 font-semibold text-white">
                          {formatCurrency(account.walletBalance)}
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-3">
                      <Button variant="secondary" onClick={() => startEditing(account)}>
                        <PencilLine className="h-4 w-4" />
                        Sửa
                      </Button>
                      <Button
                        variant="secondary"
                        onClick={() =>
                          statusMutation.mutate({
                            account,
                            action: account.status === "active" ? "lock" : "unlock",
                          })
                        }
                      >
                        {account.status === "active" ? (
                          <LockKeyhole className="h-4 w-4" />
                        ) : (
                          <UnlockKeyhole className="h-4 w-4" />
                        )}
                        {account.status === "active" ? "Khóa" : "Mở khóa"}
                      </Button>
                      <Button
                        variant="danger"
                        onClick={() => {
                          const accepted = window.confirm(
                            `Xóa tài khoản ${account.username}? Tài khoản đã phát sinh dữ liệu sẽ không thể xóa.`,
                          );

                          if (accepted) {
                            deleteMutation.mutate(account);
                          }
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                        Xóa
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </section>
    </div>
  );
}
