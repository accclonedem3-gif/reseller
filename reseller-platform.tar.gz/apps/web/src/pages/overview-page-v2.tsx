import { useQuery } from "@tanstack/react-query";
import {
  ArrowUpRight,
  Coins,
  PackageCheck,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
} from "lucide-react";

import { MetricCard } from "@/components/metric-card";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function StatusTile({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="glass-chip rounded-[22px] p-4">
      <p className="text-[11px] uppercase tracking-[0.26em] text-slate-500">{label}</p>
      <p className="mt-2 text-xl font-semibold text-white">{value}</p>
      <p className="mt-1 text-sm text-slate-400">{hint}</p>
    </div>
  );
}

export function OverviewPage() {
  const shopQuery = useQuery({
    queryKey: ["shop"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });
  const walletQuery = useQuery({
    queryKey: ["wallet"],
    queryFn: async () => (await api.get("/wallet")).data,
  });
  const ordersQuery = useQuery({
    queryKey: ["orders", "overview"],
    queryFn: async () => (await api.get("/orders")).data,
  });
  const revenueQuery = useQuery({
    queryKey: ["revenue", "overview"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });
  const topBuyersQuery = useQuery({
    queryKey: ["top-buyers", "overview"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  const orders = ordersQuery.data || [];
  const deliveredOrders = orders.filter((item: any) => item.status === "delivered");
  const pendingOrders = orders.filter((item: any) =>
    ["awaiting_payment", "paid", "processing_purchase", "paid_waiting_stock"].includes(
      item.status,
    ),
  );
  const failedOrders = orders.filter((item: any) =>
    ["failed", "refunded"].includes(String(item.status || "").toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <section className="reveal-up overflow-hidden rounded-[34px] border border-white/10 bg-[linear-gradient(135deg,rgba(56,189,248,0.18),rgba(9,14,29,0.9)_38%,rgba(14,165,233,0.06)_120%)] p-6 shadow-panel sm:p-8">
        <div className="flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
          <div className="max-w-3xl">
            <div className="glass-chip inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] uppercase tracking-[0.3em] text-slate-100">
              <Sparkles className="h-3.5 w-3.5" />
              Bảng điều khiển vận hành
            </div>
            <h1 className="mt-5 max-w-2xl text-balance font-display text-4xl font-semibold tracking-tight text-white sm:text-5xl">
              {shopQuery.data?.name || "Dashboard reseller"}
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-slate-200/90 sm:text-lg">
              Theo dõi bot, tình trạng catalog, ví nội bộ và vòng đời đơn hàng từ một màn
              hình duy nhất với giao diện tối ưu cho vận hành liên tục.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:w-[420px]">
            <StatusTile
              label="Catalog"
              value={formatDate(shopQuery.data?.lastCatalogSyncAt)}
              hint="Lần đồng bộ gần nhất"
            />
            <StatusTile
              label="Đơn chờ xử lý"
              value={String(pendingOrders.length)}
              hint="Đang chờ thanh toán hoặc mua nguồn"
            />
            <StatusTile
              label="Đơn đã giao"
              value={String(deliveredOrders.length)}
              hint="Số đơn hoàn tất hiện tại"
            />
            <StatusTile
              label="Số dư ví"
              value={formatCurrency(walletQuery.data?.balance || 0)}
              hint="Khả năng mua nguồn tức thời"
            />
          </div>
        </div>
      </section>

      <section className="reveal-up reveal-delay-1 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Số dư ví"
          value={formatCurrency(walletQuery.data?.balance || 0)}
          description="Số dư hiện tại dùng để mua hàng từ nguồn upstream."
        />
        <MetricCard
          label="Doanh thu tháng"
          value={formatCurrency(revenueQuery.data?.summary?.grossRevenue || 0)}
          description="Doanh thu từ các đơn đã thanh toán trong dữ liệu hiện tại."
        />
        <MetricCard
          label="Đơn đang chờ"
          value={String(pendingOrders.length)}
          description="Bao gồm chờ thanh toán, đang mua nguồn hoặc chờ có hàng."
        />
        <MetricCard
          label="Đơn lỗi / hoàn"
          value={String(failedOrders.length)}
          description="Dùng để theo dõi mức độ ổn định của flow mua và hoàn ví."
        />
      </section>

      <section className="reveal-up reveal-delay-2 grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <Card className="overflow-hidden">
          <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-[11px] uppercase tracking-[0.28em] text-slate-500">
                Operations feed
              </p>
              <h2 className="mt-2 font-display text-3xl font-semibold text-white">
                Đơn hàng mới nhất
              </h2>
            </div>
            <div className="glass-chip inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs text-slate-200">
              <ShieldCheck className="h-3.5 w-3.5" />
              Giám sát vòng đời đơn
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3">Mã đơn</th>
                  <th className="pb-3">Sản phẩm</th>
                  <th className="pb-3">Khách</th>
                  <th className="pb-3">Trạng thái</th>
                  <th className="pb-3 text-right">Số tiền</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 6).map((order: any, index: number) => (
                  <tr
                    key={order.id}
                    className="border-t border-white/5 text-slate-300 transition hover:bg-white/[0.03]"
                    style={{ animationDelay: `${index * 70}ms` }}
                  >
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-white/[0.06] text-slate-100">
                          <ShoppingCart className="h-4 w-4" />
                        </span>
                        <span className="font-medium text-white">{order.orderCode}</span>
                      </div>
                    </td>
                    <td className="py-4">{order.productName}</td>
                    <td className="py-4">{order.customer?.telegramUsername || "-"}</td>
                    <td className="py-4">
                      <span className="glass-chip inline-flex rounded-full px-3 py-1 text-[11px] uppercase tracking-[0.2em] text-slate-100">
                        {formatStatusLabel(order.status)}
                      </span>
                    </td>
                    <td className="py-4 text-right font-medium text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <div className="mb-5 flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.28em] text-slate-500">
                  Buyer heatmap
                </p>
                <h2 className="mt-2 font-display text-3xl font-semibold text-white">
                  Top người mua
                </h2>
              </div>
              <span className="glass-chip flex h-11 w-11 items-center justify-center rounded-2xl text-white">
                <ArrowUpRight className="h-5 w-5" />
              </span>
            </div>

            <div className="space-y-3">
              {(topBuyersQuery.data || []).slice(0, 5).map((buyer: any, index: number) => (
                <div
                  key={buyer.customerId}
                  className="glass-chip flex items-center justify-between rounded-[22px] px-4 py-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/[0.08] text-sm font-semibold text-white">
                      0{index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-white">{buyer.name}</p>
                      <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                        {buyer.totalOrders} đơn
                      </p>
                    </div>
                  </div>
                  <p className="font-semibold text-emerald-300">
                    {formatCurrency(buyer.totalSpent)}
                  </p>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div className="mb-5 flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.28em] text-slate-500">
                  Health check
                </p>
                <h2 className="mt-2 font-display text-3xl font-semibold text-white">
                  Chỉ số vận hành
                </h2>
              </div>
              <span className="glass-chip flex h-11 w-11 items-center justify-center rounded-2xl text-white">
                <Coins className="h-5 w-5" />
              </span>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="glass-chip rounded-[22px] p-4">
                <div className="flex items-center gap-2 text-slate-200">
                  <PackageCheck className="h-4 w-4 text-sky-300" />
                  <span className="text-sm">Sản phẩm đang bán</span>
                </div>
                <p className="mt-3 text-2xl font-semibold text-white">
                  {String(revenueQuery.data?.summary?.orderCount || 0)}
                </p>
              </div>
              <div className="glass-chip rounded-[22px] p-4">
                <div className="flex items-center gap-2 text-slate-200">
                  <ShoppingCart className="h-4 w-4 text-emerald-300" />
                  <span className="text-sm">Đơn hoàn tất</span>
                </div>
                <p className="mt-3 text-2xl font-semibold text-white">
                  {String(deliveredOrders.length)}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
