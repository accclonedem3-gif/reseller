import type { AxiosError } from "axios";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/api";
import { formatDate, formatStatusLabel } from "@/lib/format";

type BotConfigForm = {
  shopName: string;
  shopTagline: string;
  botToken: string;
  providerBaseUrl: string;
  providerBuyerKey: string;
  supportTelegram: string;
  supportZalo: string;
  logoUrl: string;
  payosClientId: string;
  payosApiKey: string;
  payosChecksumKey: string;
};

type FeedbackState =
  | {
      tone: "success" | "error";
      message: string;
    }
  | null;

function normalizeOptionalValue(value: string) {
  const trimmed = value.trim();
  return trimmed === "" ? undefined : trimmed;
}

function buildBotConfigPayload(form: BotConfigForm) {
  const payload: Record<string, string> = {};

  const fields: Array<[keyof BotConfigForm, string]> = [
    ["shopName", "shopName"],
    ["shopTagline", "shopTagline"],
    ["botToken", "botToken"],
    ["providerBaseUrl", "providerBaseUrl"],
    ["providerBuyerKey", "providerBuyerKey"],
    ["supportTelegram", "supportTelegram"],
    ["supportZalo", "supportZalo"],
    ["logoUrl", "logoUrl"],
    ["payosClientId", "payosClientId"],
    ["payosApiKey", "payosApiKey"],
    ["payosChecksumKey", "payosChecksumKey"],
  ];

  for (const [formKey, payloadKey] of fields) {
    const nextValue = normalizeOptionalValue(form[formKey]);

    if (nextValue !== undefined) {
      payload[payloadKey] = nextValue;
    }
  }

  return payload;
}

function getApiErrorMessage(error: unknown) {
  const fallbackMessage = "Có lỗi xảy ra. Hãy kiểm tra lại dữ liệu rồi thử lại.";
  const axiosError = error as AxiosError<{ message?: string | string[] }>;
  const apiMessage = axiosError.response?.data?.message;

  if (Array.isArray(apiMessage)) {
    return apiMessage.join(", ");
  }

  if (typeof apiMessage === "string" && apiMessage.trim() !== "") {
    return apiMessage;
  }

  return fallbackMessage;
}

function getInitialForm(): BotConfigForm {
  return {
    shopName: "",
    shopTagline: "",
    botToken: "",
    providerBaseUrl: "https://canboso.com",
    providerBuyerKey: "",
    supportTelegram: "",
    supportZalo: "",
    logoUrl: "",
    payosClientId: "",
    payosApiKey: "",
    payosChecksumKey: "",
  };
}

export function BotConfigPage() {
  const queryClient = useQueryClient();
  const configQuery = useQuery({
    queryKey: ["bot-config"],
    queryFn: async () => (await api.get("/bot-config")).data,
  });
  const [form, setForm] = useState<BotConfigForm>(getInitialForm);
  const [simulationOutput, setSimulationOutput] = useState("");
  const [feedback, setFeedback] = useState<FeedbackState>(null);

  useEffect(() => {
    if (!configQuery.data) {
      return;
    }

    setForm({
      shopName: configQuery.data.shopName || "",
      shopTagline: configQuery.data.shopTagline || "",
      botToken: "",
      providerBaseUrl: configQuery.data.providerBaseUrl || "https://canboso.com",
      providerBuyerKey: "",
      supportTelegram: configQuery.data.supportTelegram || "",
      supportZalo: configQuery.data.supportZalo || "",
      logoUrl: configQuery.data.logoUrl || "",
      payosClientId: "",
      payosApiKey: "",
      payosChecksumKey: "",
    });
  }, [configQuery.data]);

  const saveMutation = useMutation({
    mutationFn: async () => api.put("/bot-config", buildBotConfigPayload(form)),
    onMutate: () => {
      setFeedback(null);
    },
    onSuccess: async () => {
      setFeedback({
        tone: "success",
        message: "Đã lưu cấu hình. Các khóa bí mật đã được lưu an toàn.",
      });
      setForm((current) => ({
        ...current,
        botToken: "",
        providerBuyerKey: "",
        payosClientId: "",
        payosApiKey: "",
        payosChecksumKey: "",
      }));
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["bot-config"] }),
        queryClient.invalidateQueries({ queryKey: ["shop"] }),
      ]);
    },
    onError: (error) => {
      setFeedback({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const verifyTelegramMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/verify-telegram"),
    onMutate: () => {
      setFeedback(null);
    },
    onSuccess: async (response) => {
      setFeedback({
        tone: "success",
        message: `Đã xác thực Telegram thành công với @${response.data.telegramBotUsername || "bot"}.`,
      });
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
    },
    onError: (error) => {
      setFeedback({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const verifyProviderMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/verify-provider"),
    onMutate: () => {
      setFeedback(null);
    },
    onSuccess: async (response) => {
      const sampleSize = response.data.providerSampleSize;
      setFeedback({
        tone: "success",
        message:
          typeof sampleSize === "number"
            ? `Đã xác thực API nguồn. Tìm thấy ${sampleSize} sản phẩm từ nhà cung cấp.`
            : "Đã xác thực API nguồn thành công.",
      });
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
    },
    onError: (error) => {
      setFeedback({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const syncProductsMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/sync-products"),
    onMutate: () => {
      setFeedback(null);
    },
    onSuccess: async (response) => {
      setFeedback({
        tone: "success",
        message: `Đã đồng bộ ${response.data.synced || 0} sản phẩm về shop.`,
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["bot-config"] }),
        queryClient.invalidateQueries({ queryKey: ["products"] }),
      ]);
    },
    onError: (error) => {
      setFeedback({
        tone: "error",
        message: getApiErrorMessage(error),
      });
    },
  });

  const simulateMutation = useMutation({
    mutationFn: async (payload: { text?: string; callbackData?: string }) =>
      api.post(`/dev/telegram/${configQuery.data.shopId}/simulate`, payload),
    onSuccess: (response) => {
      setSimulationOutput(JSON.stringify(response.data.actions, null, 2));
    },
    onError: (error) => {
      setSimulationOutput(getApiErrorMessage(error));
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-slate-500">
          Thiết lập và vận hành
        </p>
        <h1 className="mt-3 font-display text-4xl font-bold text-white">Cấu hình bot</h1>
      </div>

      {feedback ? (
        <div
          className={`rounded-2xl border px-4 py-3 text-sm ${
            feedback.tone === "success"
              ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-200"
              : "border-rose-400/30 bg-rose-500/10 text-rose-200"
          }`}
        >
          {feedback.message}
        </div>
      ) : null}

      {configQuery.isError ? (
        <div className="rounded-2xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
          Không tải được cấu hình shop. Hãy kiểm tra API rồi tải lại trang.
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[1fr_0.9fr]">
        <Card className="space-y-4">
          <Input
            value={form.shopName}
            onChange={(event) =>
              setForm((current) => ({ ...current, shopName: event.target.value }))
            }
            placeholder="Tên shop"
          />
          <Input
            value={form.shopTagline}
            onChange={(event) =>
              setForm((current) => ({ ...current, shopTagline: event.target.value }))
            }
            placeholder="Câu giới thiệu ngắn"
          />
          <Input
            value={form.botToken}
            onChange={(event) =>
              setForm((current) => ({ ...current, botToken: event.target.value }))
            }
            placeholder={`BOT_TOKEN (${configQuery.data?.botTokenMasked || "chưa có"})`}
          />
          <Input
            value={form.providerBaseUrl}
            onChange={(event) =>
              setForm((current) => ({ ...current, providerBaseUrl: event.target.value }))
            }
            placeholder="Địa chỉ API nguồn"
          />
          <Input
            value={form.providerBuyerKey}
            onChange={(event) =>
              setForm((current) => ({ ...current, providerBuyerKey: event.target.value }))
            }
            placeholder={`Khóa buyer của nguồn (${configQuery.data?.providerBuyerKeyMasked || "chưa có"})`}
          />
          <Input
            value={form.payosClientId}
            onChange={(event) =>
              setForm((current) => ({ ...current, payosClientId: event.target.value }))
            }
            placeholder={`PayOS Client ID (${configQuery.data?.payosClientIdMasked || "chưa có"})`}
          />
          <Input
            value={form.payosApiKey}
            onChange={(event) =>
              setForm((current) => ({ ...current, payosApiKey: event.target.value }))
            }
            placeholder={`PayOS API Key (${configQuery.data?.payosApiKeyMasked || "chưa có"})`}
          />
          <Input
            value={form.payosChecksumKey}
            onChange={(event) =>
              setForm((current) => ({ ...current, payosChecksumKey: event.target.value }))
            }
            placeholder={`PayOS Checksum Key (${configQuery.data?.payosChecksumKeyMasked || "chưa có"})`}
          />
          <Input
            value={form.supportTelegram}
            onChange={(event) =>
              setForm((current) => ({ ...current, supportTelegram: event.target.value }))
            }
            placeholder="Telegram hỗ trợ"
          />
          <Input
            value={form.supportZalo}
            onChange={(event) =>
              setForm((current) => ({ ...current, supportZalo: event.target.value }))
            }
            placeholder="Zalo hỗ trợ"
          />
          <Input
            value={form.logoUrl}
            onChange={(event) =>
              setForm((current) => ({ ...current, logoUrl: event.target.value }))
            }
            placeholder="Đường dẫn logo"
          />
          <Button
            className="w-full"
            disabled={saveMutation.isPending}
            onClick={() => saveMutation.mutate()}
          >
            {saveMutation.isPending ? "Đang lưu..." : "Lưu cấu hình"}
          </Button>
        </Card>

        <div className="space-y-6">
          <Card className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">
              Tình trạng kết nối
            </h2>
            <div className="grid gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Telegram: {formatStatusLabel(configQuery.data?.telegramWebhookStatus)} | @
                {configQuery.data?.telegramBotUsername || "chưa có"}
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Nguồn cấp: {formatStatusLabel(configQuery.data?.providerConnectionStatus)}
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Cổng thanh toán: {formatStatusLabel(configQuery.data?.paymentProvider)}
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Lần đồng bộ gần nhất: {formatDate(configQuery.data?.lastCatalogSyncAt)}
              </div>
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              <Button onClick={() => verifyTelegramMutation.mutate()}>
                Kiểm tra Telegram
              </Button>
              <Button onClick={() => verifyProviderMutation.mutate()}>
                Kiểm tra nguồn
              </Button>
              <Button onClick={() => syncProductsMutation.mutate()}>
                Đồng bộ sản phẩm
              </Button>
            </div>
          </Card>

          <Card className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">Khu test bot</h2>
            <p className="text-sm text-slate-400">
              Dùng để test local khi shop đang chạy bot mô phỏng.
            </p>
            <div className="grid gap-3 md:grid-cols-3">
              <Button onClick={() => simulateMutation.mutate({ text: "/start" })}>
                /start
              </Button>
              <Button onClick={() => simulateMutation.mutate({ callbackData: "home:products" })}>
                Xem sản phẩm
              </Button>
              <Button onClick={() => simulateMutation.mutate({ callbackData: "home:support" })}>
                Hỗ trợ
              </Button>
            </div>
            <Textarea value={simulationOutput} readOnly />
          </Card>
        </div>
      </div>
    </div>
  );
}
