import { useQuery } from "@tanstack/react-query";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis } from "recharts";

import { Card } from "@/components/ui/card";
import { MetricCard } from "@/components/metric-card";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

export function RevenuePage() {
  const query = useQuery({
    queryKey: ["reports", "revenue"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });

  return (
    <div className="space-y-6">
      <h1 className="font-display text-4xl font-bold text-white">Doanh thu</h1>
      <div className="grid gap-4 md:grid-cols-3">
        <MetricCard label="Doanh thu gộp" value={formatCurrency(query.data?.summary?.grossRevenue || 0)} description="Tổng doanh thu trong tháng này." />
        <MetricCard label="Lợi nhuận ước tính" value={formatCurrency(query.data?.summary?.estimatedProfit || 0)} description="Lợi nhuận ước tính sau khi trừ giá nhập." />
        <MetricCard label="Đơn đã giao" value={String(query.data?.summary?.deliveredOrders || 0)} description="Số đơn đã giao thành công." />
      </div>
      <Card>
        <div className="mb-6">
          <h2 className="font-display text-2xl font-bold text-white">Doanh thu theo ngày</h2>
        </div>
        <div className="h-[360px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={query.data?.series || []}>
              <defs>
                <linearGradient id="revenue" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.7} />
                  <stop offset="100%" stopColor="#38bdf8" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="label" stroke="#94a3b8" />
              <Tooltip
                formatter={(value: number, name: string) => [
                  formatCurrency(Number(value || 0)),
                  name === "grossRevenue" ? "Doanh thu gộp" : name,
                ]}
                labelFormatter={(label) => `Ngày ${label}`}
              />
              <Area type="monotone" dataKey="grossRevenue" stroke="#38bdf8" fill="url(#revenue)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
