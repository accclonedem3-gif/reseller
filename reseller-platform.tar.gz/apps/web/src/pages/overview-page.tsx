import { useQuery } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { MetricCard } from "@/components/metric-card";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

export function OverviewPage() {
  const shopQuery = useQuery({
    queryKey: ["shop"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });
  const walletQuery = useQuery({
    queryKey: ["wallet"],
    queryFn: async () => (await api.get("/wallet")).data,
  });
  const ordersQuery = useQuery({
    queryKey: ["orders", "overview"],
    queryFn: async () => (await api.get("/orders")).data,
  });
  const revenueQuery = useQuery({
    queryKey: ["revenue", "overview"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });
  const topBuyersQuery = useQuery({
    queryKey: ["top-buyers", "overview"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  const orders = ordersQuery.data || [];
  const deliveredOrders = orders.filter((item: any) => item.status === "delivered");
  const pendingOrders = orders.filter((item: any) =>
    ["awaiting_payment", "paid", "processing_purchase", "paid_waiting_stock"].includes(
      item.status,
    ),
  );

  return (
    <div className="space-y-6">
      <div className="rounded-[32px] border border-white/10 bg-gradient-to-br from-brand/20 via-emerald-400/10 to-transparent p-8">
        <p className="text-xs uppercase tracking-[0.3em] text-slate-400">Tổng quan</p>
        <div className="mt-4 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <h1 className="font-display text-4xl font-bold text-white">
              {shopQuery.data?.name || "Đang tải dashboard"}
            </h1>
            <p className="mt-3 max-w-2xl text-slate-300">
              Theo dõi sức khỏe shop, ví reseller và hàng đợi đơn hàng từ một màn hình.
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-slate-300">
            Lần đồng bộ catalog gần nhất: {formatDate(shopQuery.data?.lastCatalogSyncAt)}
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Số dư ví"
          value={formatCurrency(walletQuery.data?.balance || 0)}
          description="Số dư hiện tại để mua hàng từ nguồn."
        />
        <MetricCard
          label="Doanh thu tháng"
          value={formatCurrency(revenueQuery.data?.summary?.grossRevenue || 0)}
          description="Tổng doanh thu từ các đơn đã thanh toán."
        />
        <MetricCard
          label="Đơn đang chờ"
          value={String(pendingOrders.length)}
          description="Bao gồm chờ thanh toán, đang mua hoặc chờ có hàng."
        />
        <MetricCard
          label="Đơn đã giao"
          value={String(deliveredOrders.length)}
          description="Tổng số đơn giao thành công trong dữ liệu hiện tại."
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <div className="mb-4">
            <h2 className="font-display text-2xl font-bold text-white">Đơn hàng mới nhất</h2>
            <p className="text-sm text-slate-400">Nhìn nhanh vòng đời đơn hàng gần đây.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3">Mã đơn</th>
                  <th className="pb-3">Sản phẩm</th>
                  <th className="pb-3">Khách</th>
                  <th className="pb-3">Trạng thái</th>
                  <th className="pb-3 text-right">Số tiền</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 6).map((order: any) => (
                  <tr key={order.id} className="border-t border-white/5 text-slate-300">
                    <td className="py-3">{order.orderCode}</td>
                    <td className="py-3">{order.productName}</td>
                    <td className="py-3">{order.customer?.telegramUsername || "-"}</td>
                    <td className="py-3 uppercase tracking-[0.18em] text-xs text-slate-400">
                      {formatStatusLabel(order.status)}
                    </td>
                    <td className="py-3 text-right">{formatCurrency(order.totalSaleAmount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <div className="mb-4">
            <h2 className="font-display text-2xl font-bold text-white">Top người mua</h2>
            <p className="text-sm text-slate-400">Khách hàng có tổng chi tiêu cao nhất.</p>
          </div>
          <div className="space-y-3">
            {(topBuyersQuery.data || []).slice(0, 5).map((buyer: any, index: number) => (
              <div
                key={buyer.customerId}
                className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
              >
                <div>
                  <p className="font-medium text-white">
                    {index + 1}. {buyer.name}
                  </p>
                  <p className="text-xs uppercase tracking-[0.18em] text-slate-500">
                    {buyer.totalOrders} đơn
                  </p>
                </div>
                <p className="font-semibold text-emerald-300">
                  {formatCurrency(buyer.totalSpent)}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
