import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Clock3 } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

export function PendingOrdersPage() {
  const ordersQuery = useQuery({
    queryKey: ["orders", "pending"],
    queryFn: async () =>
      (await api.get("/orders", { params: { status: "PAID_WAITING_STOCK" } })).data,
  });

  const orders = ordersQuery.data || [];

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Risk monitor"
        title="Đơn hàng chờ xử lý"
        description="Những đơn ở đây thường là các ca cần seller quan sát sát hơn: upstream hết hàng, cần mua lại sau hoặc phải giữ liên lạc hỗ trợ với khách."
      />

      {orders.length === 0 ? (
        <EmptyState
          title="Không có đơn đang chờ"
          description="Hiện tại seller chưa có đơn nào ở trạng thái chờ stock hoặc cần theo dõi lại. Khi có phát sinh, danh sách này sẽ tự cập nhật."
        />
      ) : (
        <div className="grid gap-4">
          {orders.map((order: any) => (
            <Card key={order.id}>
              <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                <div className="max-w-3xl">
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge tone="warning">{formatStatusLabel(order.status)}</Badge>
                    <span className="text-sm text-slate-500">{formatDate(order.createdAt)}</span>
                  </div>

                  <h2 className="mt-4 font-display text-2xl font-semibold text-white">
                    {order.orderCode}
                  </h2>
                  <p className="mt-2 text-sm leading-7 text-slate-300">
                    {order.productName} • {order.customer?.telegramUsername || order.customer?.name || "-"}
                  </p>
                  <p className="mt-4 rounded-[22px] border border-amber-300/20 bg-amber-500/10 px-4 py-3 text-sm leading-7 text-amber-100">
                    {order.failureReason || "Đơn đang chờ hệ thống thử mua lại khi upstream có hàng."}
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 xl:w-[360px]">
                  <div className="glass-chip rounded-[22px] p-4">
                    <div className="flex items-center gap-2 text-slate-200">
                      <Clock3 className="h-4 w-4 text-amber-200" />
                      <span className="text-sm">Giá trị đơn</span>
                    </div>
                    <p className="mt-3 text-2xl font-semibold text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </p>
                  </div>
                  <div className="glass-chip rounded-[22px] p-4">
                    <div className="flex items-center gap-2 text-slate-200">
                      <AlertTriangle className="h-4 w-4 text-rose-200" />
                      <span className="text-sm">Thanh toán</span>
                    </div>
                    <p className="mt-3 text-2xl font-semibold text-white">
                      {formatStatusLabel(order.paymentStatus)}
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
