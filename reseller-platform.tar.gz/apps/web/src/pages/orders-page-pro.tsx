import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CircleDollarSign, PackageCheck, ShoppingCart } from "lucide-react";

import { SectionHeading } from "@/components/dashboard/section-heading";
import { MetricCard } from "@/components/metric-card";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function statusTone(status: string) {
  if (status === "delivered") return "success" as const;
  if (status === "failed" || status === "refunded") return "danger" as const;
  if (status === "paid_waiting_stock") return "warning" as const;
  return "neutral" as const;
}

export function OrdersPage() {
  const ordersQuery = useQuery({
    queryKey: ["orders"],
    queryFn: async () => (await api.get("/orders")).data,
  });

  const orders = ordersQuery.data || [];
  const paidOrders = orders.filter((item: any) => item.paymentStatus === "paid");
  const deliveredOrders = orders.filter((item: any) => item.status === "delivered");
  const failedOrders = orders.filter((item: any) =>
    ["failed", "refunded"].includes(String(item.status || "").toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Order ledger"
        title="Bảng điều phối đơn hàng"
        description="Theo dõi trạng thái thanh toán, tiến độ mua upstream, giao account và các lỗi phát sinh theo từng đơn. Bề mặt này ưu tiên đọc nhanh cho seller khi cần kiểm soát vận hành."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Tổng số đơn"
          value={String(orders.length)}
          description="Toàn bộ đơn hàng hiện có trong seller workspace."
          icon={ShoppingCart}
          tone="sky"
        />
        <MetricCard
          label="Đơn đã thanh toán"
          value={String(paidOrders.length)}
          description="Những đơn đã ghi nhận tiền thành công ở hệ thống."
          icon={CircleDollarSign}
          tone="amber"
        />
        <MetricCard
          label="Đơn đã giao"
          value={String(deliveredOrders.length)}
          description="Số đơn hoàn tất toàn bộ flow và đã giao account cho khách."
          icon={PackageCheck}
          tone="emerald"
        />
        <MetricCard
          label="Đơn lỗi"
          value={String(failedOrders.length)}
          description="Bao gồm lỗi upstream, refund và các ca seller cần xử lý."
          icon={AlertTriangle}
          tone="amber"
        />
      </section>

      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="app-kicker">Full order list</p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-white">Toàn bộ đơn hàng</h2>
          </div>
          <p className="text-sm text-slate-500">Hiển thị tối đa 100 đơn gần nhất từ API seller.</p>
        </div>

        <div className="mt-6 app-table-wrap">
          <table className="app-table">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Sản phẩm</th>
                <th>Khách hàng</th>
                <th>Trạng thái</th>
                <th>Thanh toán</th>
                <th>Tạo lúc</th>
                <th className="text-right">Tổng</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order: any) => (
                <tr key={order.id}>
                  <td>
                    <p className="font-semibold text-white">{order.orderCode}</p>
                    {order.failureReason ? (
                      <p className="mt-2 max-w-[240px] text-sm leading-6 text-rose-200">
                        {order.failureReason}
                      </p>
                    ) : null}
                  </td>
                  <td>
                    <p className="font-medium text-white">{order.productName}</p>
                    <p className="mt-1 text-sm text-slate-500">{order.product?.sourceName || "-"}</p>
                  </td>
                  <td>
                    <p>{order.customer?.telegramUsername || order.customer?.name || "-"}</p>
                    <p className="mt-1 text-sm text-slate-500">{order.customer?.telegramUserId || "-"}</p>
                  </td>
                  <td>
                    <Badge tone={statusTone(order.status)}>{formatStatusLabel(order.status)}</Badge>
                  </td>
                  <td>
                    <Badge tone={order.paymentStatus === "paid" ? "success" : "neutral"}>
                      {formatStatusLabel(order.paymentStatus)}
                    </Badge>
                  </td>
                  <td>{formatDate(order.createdAt)}</td>
                  <td className="text-right font-semibold text-white">
                    {formatCurrency(order.totalSaleAmount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
