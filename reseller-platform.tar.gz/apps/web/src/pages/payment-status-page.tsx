import { useSearchParams } from "react-router-dom";

import { Card } from "@/components/ui/card";

export function PaymentStatusPage({ mode }: { mode: "success" | "cancel" }) {
  const [searchParams] = useSearchParams();

  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <Card className="max-w-xl">
        <h1 className="font-display text-3xl font-bold text-white">
          {mode === "success" ? "Thanh toán thành công" : "Thanh toán đã bị hủy"}
        </h1>
        <p className="mt-3 text-slate-300">
          Mã đơn: {searchParams.get("orderCode") || "không có"}
        </p>
        <p className="mt-3 text-slate-400">
          Bạn có thể quay lại bot Telegram hoặc dashboard để xem trạng thái đơn hàng.
        </p>
      </Card>
    </div>
  );
}
