import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Eye, EyeOff, Package, Search, Sparkles, Tags } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { Field } from "@/components/dashboard/field";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

export function ProductsPage() {
  const queryClient = useQueryClient();
  const productsQuery = useQuery({
    queryKey: ["products"],
    queryFn: async () => (await api.get("/products")).data,
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [keyword, setKeyword] = useState("");
  const [form, setForm] = useState({
    displayName: "",
    salePrice: "",
    hidden: false,
    enabled: true,
    promoText: "",
  });

  const filteredProducts = useMemo(() => {
    const items = productsQuery.data || [];
    const normalizedKeyword = keyword.trim().toLowerCase();

    if (!normalizedKeyword) {
      return items;
    }

    return items.filter((item: any) =>
      [item.displayName, item.sourceName]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(normalizedKeyword)),
    );
  }, [keyword, productsQuery.data]);

  useEffect(() => {
    const firstId = filteredProducts?.[0]?.id;
    if (!selectedId && firstId) {
      setSelectedId(firstId);
    }
  }, [filteredProducts, selectedId]);

  const selectedProduct = (productsQuery.data || []).find((item: any) => item.id === selectedId);

  useEffect(() => {
    if (!selectedProduct) {
      return;
    }

    setForm({
      displayName: selectedProduct.displayName || "",
      salePrice: String(selectedProduct.salePrice || ""),
      hidden: Boolean(selectedProduct.hidden),
      enabled: Boolean(selectedProduct.enabled),
      promoText: selectedProduct.promoText || "",
    });
  }, [selectedProduct?.id]);

  const updateMutation = useMutation({
    mutationFn: async () =>
      api.put(`/products/${selectedId}`, {
        displayName: form.displayName,
        salePrice: Number(form.salePrice || 0),
        hidden: form.hidden,
        enabled: form.enabled,
        promoText: form.promoText,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Catalog studio"
        title="Sản phẩm"
        description="Seller có thể điều chỉnh mặt hiển thị của catalog mà không đụng vào logic bot: đổi tên, chỉnh giá, ẩn sản phẩm hoặc thêm thông điệp khuyến mại."
      />

      <section className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <Card>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="app-kicker">Merged catalog</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Danh sách sản phẩm
              </h2>
            </div>
            <div className="relative w-full max-w-sm">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <Input
                className="pl-11"
                placeholder="Tìm theo tên hiển thị hoặc tên nguồn"
                value={keyword}
                onChange={(event) => setKeyword(event.target.value)}
              />
            </div>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="mt-6">
              <EmptyState
                title="Chưa có sản phẩm phù hợp"
                description="Hãy thử sync catalog hoặc đổi từ khóa tìm kiếm để hiển thị lại danh sách."
              />
            </div>
          ) : (
            <div className="mt-6 app-table-wrap">
              <table className="app-table">
                <thead>
                  <tr>
                    <th>Sản phẩm</th>
                    <th>Giá gốc</th>
                    <th>Giá bán</th>
                    <th>Tồn</th>
                    <th>Đã bán</th>
                    <th>Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product: any) => (
                    <tr
                      key={product.id}
                      className={selectedId === product.id ? "bg-white/[0.03]" : undefined}
                      onClick={() => setSelectedId(product.id)}
                    >
                      <td className="cursor-pointer">
                        <div className="flex items-center gap-3">
                          <div className="glass-chip flex h-11 w-11 items-center justify-center rounded-2xl">
                            <Package className="h-4 w-4 text-cyan-100" />
                          </div>
                          <div>
                            <p className="font-semibold text-white">{product.displayName}</p>
                            <p className="mt-1 text-sm text-slate-500">{product.sourceName}</p>
                          </div>
                        </div>
                      </td>
                      <td>{formatCurrency(product.sourcePrice)}</td>
                      <td className="font-semibold text-emerald-300">
                        {formatCurrency(product.salePrice)}
                      </td>
                      <td>{product.available ?? "-"}</td>
                      <td>{product.soldCount}</td>
                      <td>
                        <div className="flex flex-wrap gap-2">
                          <Badge tone={product.enabled ? "success" : "neutral"}>
                            {product.enabled ? "Đang bán" : "Tạm tắt"}
                          </Badge>
                          {product.hidden ? <Badge tone="warning">Ẩn trên bot</Badge> : null}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card>
          {selectedProduct ? (
            <div className="space-y-6">
              <div>
                <p className="app-kicker">Override editor</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  {selectedProduct.displayName}
                </h2>
                <p className="mt-2 text-sm leading-7 text-slate-400">
                  Dữ liệu nguồn: {selectedProduct.sourceName} • Giá gốc {formatCurrency(selectedProduct.sourcePrice)}
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="glass-chip rounded-[22px] p-4">
                  <p className="app-kicker">Tồn kho</p>
                  <p className="mt-3 text-2xl font-semibold text-white">
                    {selectedProduct.available ?? "-"}
                  </p>
                </div>
                <div className="glass-chip rounded-[22px] p-4">
                  <p className="app-kicker">Đã bán</p>
                  <p className="mt-3 text-2xl font-semibold text-white">
                    {selectedProduct.soldCount}
                  </p>
                </div>
              </div>

              <Field label="Tên hiển thị" hint="Bot name">
                <Input
                  value={form.displayName}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, displayName: event.target.value }))
                  }
                  placeholder="Tên hiện thị trên bot"
                />
              </Field>

              <Field label="Giá bán" hint="VND">
                <Input
                  value={form.salePrice}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, salePrice: event.target.value }))
                  }
                  placeholder="Giá bán cho khách"
                />
              </Field>

              <Field
                label="Thông điệp khuyến mại"
                hint="Optional"
                description="Dùng để làm nổi bật ưu đãi, bảo hành hoặc điểm khác biệt của sản phẩm."
              >
                <Textarea
                  value={form.promoText}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, promoText: event.target.value }))
                  }
                  placeholder="Ví dụ: Bảo hành 24h, đổi lỗi trong ngày, ưu đãi tháng này..."
                />
              </Field>

              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  className={`glass-chip flex items-center justify-between rounded-[24px] px-4 py-4 text-left transition ${
                    form.enabled ? "border-emerald-300/25 bg-emerald-500/10" : ""
                  }`}
                  onClick={() => setForm((current) => ({ ...current, enabled: !current.enabled }))}
                  type="button"
                >
                  <div className="flex items-center gap-3">
                    <Sparkles className="h-4.5 w-4.5 text-emerald-200" />
                    <div>
                      <p className="font-semibold text-white">Cho phép bán</p>
                      <p className="mt-1 text-sm text-slate-500">
                        {form.enabled ? "Sản phẩm đang mở" : "Sản phẩm tạm tắt"}
                      </p>
                    </div>
                  </div>
                  <Badge tone={form.enabled ? "success" : "neutral"}>
                    {form.enabled ? "Bật" : "Tắt"}
                  </Badge>
                </button>

                <button
                  className={`glass-chip flex items-center justify-between rounded-[24px] px-4 py-4 text-left transition ${
                    form.hidden ? "border-amber-300/25 bg-amber-500/10" : ""
                  }`}
                  onClick={() => setForm((current) => ({ ...current, hidden: !current.hidden }))}
                  type="button"
                >
                  <div className="flex items-center gap-3">
                    {form.hidden ? (
                      <EyeOff className="h-4.5 w-4.5 text-amber-200" />
                    ) : (
                      <Eye className="h-4.5 w-4.5 text-cyan-100" />
                    )}
                    <div>
                      <p className="font-semibold text-white">Ẩn trên bot</p>
                      <p className="mt-1 text-sm text-slate-500">
                        {form.hidden ? "Khách sẽ không thấy sản phẩm" : "Đang hiển thị bình thường"}
                      </p>
                    </div>
                  </div>
                  <Badge tone={form.hidden ? "warning" : "neutral"}>
                    {form.hidden ? "Ẩn" : "Hiện"}
                  </Badge>
                </button>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="glass-chip rounded-[22px] p-4">
                  <div className="flex items-center gap-2 text-slate-200">
                    <Tags className="h-4 w-4 text-amber-100" />
                    <span className="text-sm">Biên lợi nhuận tạm tính</span>
                  </div>
                  <p className="mt-3 text-2xl font-semibold text-white">
                    {formatCurrency(Number(form.salePrice || 0) - Number(selectedProduct.sourcePrice || 0))}
                  </p>
                </div>
                <Button
                  className="h-full min-h-[98px] w-full"
                  disabled={updateMutation.isPending || !selectedId}
                  onClick={() => updateMutation.mutate()}
                >
                  {updateMutation.isPending ? "Đang lưu..." : "Lưu cấu hình sản phẩm"}
                </Button>
              </div>
            </div>
          ) : (
            <EmptyState
              title="Chọn một sản phẩm"
              description="Khi seller chọn một dòng trong catalog, khu vực chỉnh sửa override sẽ hiển thị đầy đủ ở đây."
            />
          )}
        </Card>
      </section>
    </div>
  );
}
