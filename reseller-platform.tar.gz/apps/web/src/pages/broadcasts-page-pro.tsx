import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, ImagePlus, Send } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { Field } from "@/components/dashboard/field";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/api";
import { formatDate, formatStatusLabel } from "@/lib/format";

export function BroadcastsPage() {
  const queryClient = useQueryClient();
  const [title, setTitle] = useState("Thông báo mới");
  const [message, setMessage] = useState(
    "Shop vừa cập nhật giá tốt cho một số sản phẩm nổi bật trong hôm nay.",
  );
  const [imageUrl, setImageUrl] = useState("");

  const broadcastsQuery = useQuery({
    queryKey: ["broadcasts"],
    queryFn: async () => (await api.get("/broadcasts")).data,
  });

  const createMutation = useMutation({
    mutationFn: async () =>
      api.post("/broadcasts", {
        title,
        message,
        imageUrl,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["broadcasts"] });
    },
  });

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Trung tâm broadcast"
        title="Thông báo bot"
        description="Khu vực này dành cho seller khi cần gửi thông báo đồng loạt đến tập khách đã từng chat với bot. Giao diện mới ưu tiên rõ target, nội dung và lịch sử chạy queue."
      />

      <section className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <Card>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="app-kicker">Soạn nội dung</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Soạn broadcast
              </h2>
            </div>
            <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
              <Send className="h-5 w-5 text-emerald-100" />
            </span>
          </div>

          <div className="mt-6 space-y-5">
            <Field label="Tiêu đề" hint="Title">
              <Input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Ví dụ: Flash sale hôm nay"
              />
            </Field>

            <Field
              label="Nội dung"
              hint="Required"
              description="Hãy viết ngắn gọn, rõ CTA và dễ đọc trên giao diện Telegram."
            >
              <Textarea
                value={message}
                onChange={(event) => setMessage(event.target.value)}
                placeholder="Nội dung gửi đến khách hàng"
              />
            </Field>

            <Field
              label="Ảnh đính kèm"
              hint="Optional"
              description="MVP hiện đang lưu URL ảnh thay vì upload trực tiếp."
            >
              <Input
                value={imageUrl}
                onChange={(event) => setImageUrl(event.target.value)}
                placeholder="https://..."
              />
            </Field>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="glass-chip rounded-[22px] p-4">
                <div className="flex items-center gap-2 text-slate-200">
                  <Bell className="h-4 w-4 text-emerald-100" />
                  <span className="text-sm">Kiểu gửi</span>
                </div>
                <p className="mt-3 text-2xl font-semibold text-white">Queue nền</p>
              </div>
              <div className="glass-chip rounded-[22px] p-4">
                <div className="flex items-center gap-2 text-slate-200">
                  <ImagePlus className="h-4 w-4 text-emerald-100" />
                  <span className="text-sm">Ảnh</span>
                </div>
                <p className="mt-3 text-2xl font-semibold text-white">
                  {imageUrl ? "Có đính kèm" : "Chưa có"}
                </p>
              </div>
            </div>

            <Button className="w-full" disabled={createMutation.isPending} onClick={() => createMutation.mutate()}>
              {createMutation.isPending ? "Đang xếp hàng..." : "Đưa broadcast vào queue"}
            </Button>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="app-kicker">Lịch sử broadcast</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Lịch sử chiến dịch
              </h2>
            </div>
            <div className="glass-chip rounded-full px-3 py-1.5 text-xs text-slate-200">
              {(broadcastsQuery.data || []).length} chiến dịch
            </div>
          </div>

          {(broadcastsQuery.data || []).length === 0 ? (
            <div className="mt-6">
              <EmptyState
                title="Chưa có broadcast nào"
                description="Khi seller gửi chiến dịch đầu tiên, trạng thái queue và kết quả gửi sẽ xuất hiện đầy đủ trong khu vực này."
              />
            </div>
          ) : (
            <div className="mt-6 space-y-3">
              {(broadcastsQuery.data || []).map((item: any) => (
                <div key={item.id} className="glass-chip rounded-[24px] px-4 py-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <p className="font-semibold text-white">{item.title || "Thông báo"}</p>
                      <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-300">{item.message}</p>
                    </div>
                    <Badge tone={item.status === "completed" ? "success" : "neutral"}>
                      {formatStatusLabel(item.status)}
                    </Badge>
                  </div>

                  <div className="mt-4 grid gap-3 sm:grid-cols-3">
                    <div className="rounded-[20px] border border-white/10 bg-white/[0.04] px-4 py-3">
                      <p className="app-kicker">Người nhận</p>
                      <p className="mt-2 text-lg font-semibold text-white">{item.totalTargets}</p>
                    </div>
                    <div className="rounded-[20px] border border-white/10 bg-white/[0.04] px-4 py-3">
                      <p className="app-kicker">Đã gửi</p>
                      <p className="mt-2 text-lg font-semibold text-emerald-200">{item.sentCount}</p>
                    </div>
                    <div className="rounded-[20px] border border-white/10 bg-white/[0.04] px-4 py-3">
                      <p className="app-kicker">Lỗi</p>
                      <p className="mt-2 text-lg font-semibold text-rose-200">{item.failedCount}</p>
                    </div>
                  </div>

                  <p className="mt-4 text-sm text-slate-500">{formatDate(item.createdAt)}</p>
                </div>
              ))}
            </div>
          )}
        </Card>
      </section>
    </div>
  );
}
