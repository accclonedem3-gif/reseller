import { useQuery } from "@tanstack/react-query";
import { Crown, Users, Wallet } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import { SectionHeading } from "@/components/dashboard/section-heading";
import { MetricCard } from "@/components/metric-card";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

export function TopBuyersPage() {
  const query = useQuery({
    queryKey: ["reports", "top-buyers"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  const buyers = query.data || [];
  const leadBuyer = buyers[0];
  const totalSpent = buyers.reduce((sum: number, item: any) => sum + Number(item.totalSpent || 0), 0);
  const totalOrders = buyers.reduce((sum: number, item: any) => sum + Number(item.totalOrders || 0), 0);

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Audience intelligence"
        title="Top người mua"
        description="Danh sách khách mang lại nhiều doanh thu nhất cho seller. Dùng khu vực này để ưu tiên hỗ trợ, chăm sóc lại và lên broadcast đúng nhóm."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <MetricCard
          label="Khách dẫn đầu"
          value={leadBuyer?.name || "Chưa có"}
          description="Người mua có giá trị cao nhất trong dữ liệu seller hiện tại."
          icon={Crown}
          tone="amber"
        />
        <MetricCard
          label="Tổng doanh thu top"
          value={formatCurrency(totalSpent)}
          description="Tổng chi tiêu của nhóm khách hàng nổi bật đang được hiển thị."
          icon={Wallet}
          tone="amber"
        />
        <MetricCard
          label="Tổng số đơn"
          value={String(totalOrders)}
          description="Tổng số đơn hàng được tạo bởi nhóm top buyer hiện tại."
          icon={Users}
          tone="amber"
        />
      </section>

      {buyers.length === 0 ? (
        <EmptyState
          title="Chưa có dữ liệu top buyer"
          description="Khi seller bắt đầu có đơn thanh toán thành công, hệ thống sẽ tự xếp hạng khách mua mạnh nhất ở đây."
        />
      ) : (
        <Card>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="app-kicker">Ranked buyer list</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Bảng xếp hạng khách mua
              </h2>
            </div>
            <div className="glass-chip rounded-full px-3 py-1.5 text-xs text-slate-200">
              {buyers.length} khách nổi bật
            </div>
          </div>

          <div className="mt-6 space-y-3">
            {buyers.map((buyer: any, index: number) => (
              <div
                key={buyer.customerId}
                className="glass-chip flex flex-col gap-4 rounded-[24px] px-4 py-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/[0.07] text-sm font-semibold text-white">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <div>
                    <p className="font-semibold text-white">{buyer.name}</p>
                    <p className="mt-1 text-sm text-slate-500">
                      @{buyer.telegramUsername || "chưa-có"} • {buyer.totalOrders} đơn
                    </p>
                  </div>
                </div>
                <p className="font-display text-2xl font-semibold text-emerald-200">
                  {formatCurrency(buyer.totalSpent)}
                </p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
