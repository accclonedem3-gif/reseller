import type { ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BarChart3,
  Boxes,
  Eye,
  Package,
  RefreshCw,
  Save,
  Search,
  Wallet,
} from "lucide-react";

import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

function SummaryCard({
  label,
  value,
  meta,
  icon: Icon,
}: {
  label: string;
  value: string;
  meta: string;
  icon: typeof Package;
}) {
  return (
    <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-[0_18px_40px_rgba(15,23,42,0.05)]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-400">
            {label}
          </p>
          <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">{value}</p>
          <p className="mt-2 text-sm leading-6 text-slate-500">{meta}</p>
        </div>
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-100 text-slate-700">
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

function EditorField({
  label,
  hint,
  description,
  children,
}: {
  label: string;
  hint?: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between gap-3">
        <label className="text-sm font-semibold text-slate-900">{label}</label>
        {hint ? (
          <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-400">
            {hint}
          </span>
        ) : null}
      </div>
      {description ? <p className="text-sm leading-6 text-slate-500">{description}</p> : null}
      {children}
    </div>
  );
}

function StatusPill({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning";
}) {
  const classes =
    tone === "success"
      ? "border-emerald-200 bg-emerald-50 text-emerald-700"
      : tone === "warning"
        ? "border-amber-200 bg-amber-50 text-amber-700"
        : "border-slate-200 bg-slate-100 text-slate-600";

  return (
    <span
      className={`inline-flex items-center rounded-full border px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] ${classes}`}
    >
      {children}
    </span>
  );
}

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-2xl border border-slate-200 bg-white px-4 py-3.5 text-sm font-medium text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-300 focus:ring-4 focus:ring-slate-100 ${props.className || ""}`}
    />
  );
}

function TextAreaInput(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`min-h-[120px] w-full rounded-2xl border border-slate-200 bg-white px-4 py-3.5 text-sm font-medium text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-300 focus:ring-4 focus:ring-slate-100 ${props.className || ""}`}
    />
  );
}

export function ProductsPageEnterprise() {
  const queryClient = useQueryClient();
  const productsQuery = useQuery({
    queryKey: ["products"],
    queryFn: async () => (await api.get("/products")).data,
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [keyword, setKeyword] = useState("");
  const [form, setForm] = useState({
    displayName: "",
    salePrice: "",
    hidden: false,
    enabled: true,
    promoText: "",
  });

  const products = productsQuery.data || [];

  const filteredProducts = useMemo(() => {
    const normalizedKeyword = keyword.trim().toLowerCase();

    if (!normalizedKeyword) {
      return products;
    }

    return products.filter((item: any) =>
      [item.displayName, item.sourceName]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(normalizedKeyword)),
    );
  }, [keyword, products]);

  useEffect(() => {
    if (filteredProducts.length === 0) {
      setSelectedId(null);
      return;
    }

    const stillExists = filteredProducts.some((item: any) => item.id === selectedId);
    if (!selectedId || !stillExists) {
      setSelectedId(filteredProducts[0].id);
    }
  }, [filteredProducts, selectedId]);

  const selectedProduct = products.find((item: any) => item.id === selectedId);

  useEffect(() => {
    if (!selectedProduct) {
      return;
    }

    setForm({
      displayName: selectedProduct.displayName || "",
      salePrice: String(selectedProduct.salePrice || ""),
      hidden: Boolean(selectedProduct.hidden),
      enabled: Boolean(selectedProduct.enabled),
      promoText: selectedProduct.promoText || "",
    });
  }, [selectedProduct?.id]);

  const updateMutation = useMutation({
    mutationFn: async () =>
      api.put(`/products/${selectedId}`, {
        displayName: form.displayName,
        salePrice: Number(form.salePrice || 0),
        hidden: form.hidden,
        enabled: form.enabled,
        promoText: form.promoText,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });

  const activeCount = products.filter((item: any) => item.enabled && !item.hidden).length;
  const hiddenCount = products.filter((item: any) => item.hidden).length;
  const totalSales = products.reduce(
    (sum: number, item: any) => sum + Number(item.soldCount || 0),
    0,
  );

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
        <div className="max-w-3xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-400">
            Quản lý catalog
          </p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight text-slate-950">
            Sản phẩm
          </h1>
          <p className="mt-3 text-sm leading-7 text-slate-500 sm:text-base">
            Điều chỉnh tên hiển thị, giá bán và trạng thái xuất hiện trên bot mà không cần
            thay đổi luồng mua hàng Telegram.
          </p>
        </div>

        <button
          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-[0_12px_26px_rgba(15,23,42,0.04)] transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-950"
          onClick={() => {
            void productsQuery.refetch();
          }}
          type="button"
        >
          <RefreshCw className="h-4 w-4" />
          Làm mới catalog
        </button>
      </section>

      <div className="grid gap-4 md:grid-cols-3">
        <SummaryCard
          label="Tổng sản phẩm"
          value={String(products.length)}
          meta="Toàn bộ sản phẩm hiện có trong catalog hợp nhất của seller."
          icon={Boxes}
        />
        <SummaryCard
          label="Đang hiển thị"
          value={String(activeCount)}
          meta="Sản phẩm đang bật và hiển thị cho người mua trên bot."
          icon={Eye}
        />
        <SummaryCard
          label="Đã bán"
          value={String(totalSales)}
          meta="Tổng số lượt bán ghi nhận từ snapshot catalog hiện tại."
          icon={BarChart3}
        />
      </div>

      <section className="grid gap-6 xl:grid-cols-[minmax(0,1.18fr)_420px]">
        <div className="rounded-[28px] border border-slate-200 bg-white shadow-[0_24px_50px_rgba(15,23,42,0.05)]">
          <div className="flex flex-col gap-4 border-b border-slate-200 px-6 py-5 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-400">
                Danh mục sản phẩm
              </p>
              <h2 className="mt-3 text-2xl font-semibold tracking-tight text-slate-950">
                Danh sách sản phẩm
              </h2>
              <p className="mt-2 text-sm text-slate-500">
                Chọn một sản phẩm để chỉnh tên hiển thị, giá bán và trạng thái xuất hiện.
              </p>
            </div>

            <div className="relative w-full max-w-sm">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <TextInput
                className="pl-11"
                placeholder="Tìm theo tên hiển thị hoặc tên nguồn"
                value={keyword}
                onChange={(event) => setKeyword(event.target.value)}
              />
            </div>
          </div>

          <div className="px-4 py-4 sm:px-6">
            {productsQuery.isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, index) => (
                  <div
                    key={index}
                    className="h-[88px] animate-pulse rounded-[22px] border border-slate-200 bg-slate-50"
                  />
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 px-6 py-12 text-center">
                <p className="text-lg font-semibold text-slate-900">Không có sản phẩm phù hợp</p>
                <p className="mt-2 text-sm leading-7 text-slate-500">
                  Hãy thử từ khóa khác hoặc đồng bộ lại catalog để hiển thị lại danh sách.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="hidden grid-cols-[minmax(0,2.2fr)_0.95fr_0.95fr_0.6fr_0.6fr_auto] gap-4 px-4 pb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-400 lg:grid">
                  <span>Sản phẩm</span>
                  <span>Giá nguồn</span>
                  <span>Giá bán</span>
                  <span>Tồn kho</span>
                  <span>Đã bán</span>
                  <span>Trạng thái</span>
                </div>

                {filteredProducts.map((product: any) => {
                  const isSelected = selectedId === product.id;

                  return (
                    <button
                      key={product.id}
                      className={`w-full rounded-[22px] border p-4 text-left transition lg:p-5 ${
                        isSelected
                          ? "border-sky-200 bg-sky-50 shadow-[0_18px_36px_rgba(14,165,233,0.08)]"
                          : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"
                      }`}
                      onClick={() => setSelectedId(product.id)}
                      type="button"
                    >
                      <div className="flex flex-col gap-4 lg:grid lg:grid-cols-[minmax(0,2.2fr)_0.95fr_0.95fr_0.6fr_0.6fr_auto] lg:items-center lg:gap-4">
                        <div className="min-w-0">
                          <div className="flex items-start gap-3">
                            <div
                              className={`mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${
                                isSelected
                                  ? "bg-slate-900 text-white"
                                  : "bg-slate-100 text-slate-600"
                              }`}
                            >
                              <Package className="h-4.5 w-4.5" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-base font-semibold leading-6 text-slate-950">
                                {product.displayName}
                              </p>
                              <p className="mt-1 text-sm text-slate-500">{product.sourceName}</p>
                            </div>
                          </div>
                        </div>

                        <div>
                          <p className="text-xs uppercase tracking-[0.14em] text-slate-400 lg:hidden">
                            Giá nguồn
                          </p>
                          <p className="mt-1 text-sm font-medium text-slate-700 lg:mt-0">
                            {formatCurrency(product.sourcePrice)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs uppercase tracking-[0.14em] text-slate-400 lg:hidden">
                            Giá bán
                          </p>
                          <p className="mt-1 text-sm font-semibold text-slate-950 lg:mt-0">
                            {formatCurrency(product.salePrice)}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs uppercase tracking-[0.14em] text-slate-400 lg:hidden">
                            Tồn kho
                          </p>
                          <p className="mt-1 text-sm font-medium text-slate-700 lg:mt-0">
                            {product.available ?? "-"}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs uppercase tracking-[0.14em] text-slate-400 lg:hidden">
                            Đã bán
                          </p>
                          <p className="mt-1 text-sm font-medium text-slate-700 lg:mt-0">
                            {product.soldCount}
                          </p>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <StatusPill tone={product.enabled ? "success" : "neutral"}>
                            {product.enabled ? "Đang bán" : "Tạm dừng"}
                          </StatusPill>
                          {product.hidden ? <StatusPill tone="warning">Ẩn trên bot</StatusPill> : null}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <div className="xl:sticky xl:top-6 xl:self-start">
          <div className="rounded-[28px] border border-slate-200 bg-white shadow-[0_24px_50px_rgba(15,23,42,0.05)]">
            {selectedProduct ? (
              <div className="space-y-6 p-6">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-400">
                    Chỉnh sửa sản phẩm
                  </p>
                  <h2 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">
                    {selectedProduct.displayName}
                  </h2>
                  <p className="mt-3 text-sm leading-7 text-slate-500">
                    Dữ liệu nguồn: {selectedProduct.sourceName} / Giá gốc{" "}
                    {formatCurrency(selectedProduct.sourcePrice)}
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-400">
                      Tồn kho
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-slate-950">
                      {selectedProduct.available ?? "-"}
                    </p>
                  </div>
                  <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-400">
                      Đã bán
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-slate-950">
                      {selectedProduct.soldCount}
                    </p>
                  </div>
                  <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-400">
                      Đang ẩn
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-slate-950">
                      {hiddenCount}
                    </p>
                  </div>
                </div>

                <EditorField label="Tên hiển thị" hint="Tên trên bot">
                  <TextInput
                    placeholder="Tên công khai hiển thị cho khách"
                    value={form.displayName}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, displayName: event.target.value }))
                    }
                  />
                </EditorField>

                <EditorField label="Giá bán" hint="VND">
                  <TextInput
                    placeholder="Giá bán cho khách"
                    value={form.salePrice}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, salePrice: event.target.value }))
                    }
                  />
                </EditorField>

                <EditorField
                  label="Thông điệp khuyến mại"
                  hint="Tùy chọn"
                  description="Thêm ghi chú ngắn về bảo hành, ưu đãi tặng thêm hoặc điểm nhấn giúp tăng chuyển đổi."
                >
                  <TextAreaInput
                    placeholder="Ví dụ: Bảo hành 24h, đổi lỗi nhanh, ưu đãi riêng trong tuần này."
                    value={form.promoText}
                    onChange={(event) =>
                      setForm((current) => ({ ...current, promoText: event.target.value }))
                    }
                  />
                </EditorField>

                <div className="grid gap-3 sm:grid-cols-2">
                  <button
                    className={`rounded-[22px] border p-4 text-left transition ${
                      form.enabled
                        ? "border-emerald-200 bg-emerald-50"
                        : "border-slate-200 bg-slate-50 hover:border-slate-300"
                    }`}
                    onClick={() =>
                      setForm((current) => ({ ...current, enabled: !current.enabled }))
                    }
                    type="button"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="text-sm font-semibold text-slate-950">Cho phép bán</p>
                        <p className="mt-1 text-sm leading-6 text-slate-500">
                          Kiểm soát việc sản phẩm có thể được khách mua trên bot hay không.
                        </p>
                      </div>
                      <StatusPill tone={form.enabled ? "success" : "neutral"}>
                        {form.enabled ? "Bật" : "Tắt"}
                      </StatusPill>
                    </div>
                  </button>

                  <button
                    className={`rounded-[22px] border p-4 text-left transition ${
                      form.hidden
                        ? "border-amber-200 bg-amber-50"
                        : "border-slate-200 bg-slate-50 hover:border-slate-300"
                    }`}
                    onClick={() => setForm((current) => ({ ...current, hidden: !current.hidden }))}
                    type="button"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="text-sm font-semibold text-slate-950">Ẩn trên bot</p>
                        <p className="mt-1 text-sm leading-6 text-slate-500">
                          Giữ sản phẩm trong catalog nhưng gỡ khỏi menu công khai trên bot.
                        </p>
                      </div>
                      <StatusPill tone={form.hidden ? "warning" : "neutral"}>
                        {form.hidden ? "Ẩn" : "Hiện"}
                      </StatusPill>
                    </div>
                  </button>
                </div>

                <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-slate-700">
                        <Wallet className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-slate-950">Biên lợi nhuận ước tính</p>
                        <p className="mt-1 text-sm text-slate-500">
                          Giá bán trừ đi giá nguồn từ upstream.
                        </p>
                      </div>
                    </div>
                    <p className="text-2xl font-semibold text-slate-950">
                      {formatCurrency(
                        Number(form.salePrice || 0) - Number(selectedProduct.sourcePrice || 0),
                      )}
                    </p>
                  </div>
                </div>

                <button
                  className="inline-flex min-h-[56px] w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3.5 text-sm font-semibold text-white shadow-[0_18px_35px_rgba(15,23,42,0.18)] transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
                  disabled={updateMutation.isPending || !selectedId}
                  onClick={() => updateMutation.mutate()}
                  type="button"
                >
                  <Save className="h-4.5 w-4.5" />
                  {updateMutation.isPending ? "Đang lưu thay đổi..." : "Lưu cấu hình sản phẩm"}
                </button>
              </div>
            ) : (
              <div className="px-6 py-16 text-center">
                <p className="text-lg font-semibold text-slate-950">Chọn một sản phẩm</p>
                <p className="mt-2 text-sm leading-7 text-slate-500">
                  Thông tin chi tiết và phần chỉnh sửa sẽ hiện ở đây sau khi bạn chọn một dòng
                  trong catalog.
                </p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
