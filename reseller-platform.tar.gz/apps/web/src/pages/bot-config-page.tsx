import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/api";
import { formatDate, formatStatusLabel } from "@/lib/format";

export function BotConfigPage() {
  const queryClient = useQueryClient();
  const configQuery = useQuery({
    queryKey: ["bot-config"],
    queryFn: async () => (await api.get("/bot-config")).data,
  });
  const [form, setForm] = useState({
    shopName: "",
    shopTagline: "",
    botToken: "",
    providerBaseUrl: "https://canboso.com",
    providerBuyerKey: "",
    supportTelegram: "",
    supportZalo: "",
    logoUrl: "",
  });
  const [simulationOutput, setSimulationOutput] = useState<string>("");

  useEffect(() => {
    if (!configQuery.data) {
      return;
    }

    setForm({
      shopName: configQuery.data.shopName || "",
      shopTagline: configQuery.data.shopTagline || "",
      botToken: "",
      providerBaseUrl: configQuery.data.providerBaseUrl || "https://canboso.com",
      providerBuyerKey: "",
      supportTelegram: configQuery.data.supportTelegram || "",
      supportZalo: configQuery.data.supportZalo || "",
      logoUrl: configQuery.data.logoUrl || "",
    });
  }, [configQuery.data?.shopId]);

  const saveMutation = useMutation({
    mutationFn: async () => api.put("/bot-config", form),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
      await queryClient.invalidateQueries({ queryKey: ["shop"] });
    },
  });

  const verifyTelegramMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/verify-telegram"),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
    },
  });

  const verifyProviderMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/verify-provider"),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["bot-config"] });
    },
  });

  const syncProductsMutation = useMutation({
    mutationFn: async () => api.post("/bot-config/sync-products"),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["bot-config"] }),
        queryClient.invalidateQueries({ queryKey: ["products"] }),
      ]);
    },
  });

  const simulateMutation = useMutation({
    mutationFn: async (payload: { text?: string; callbackData?: string }) =>
      api.post(`/dev/telegram/${configQuery.data.shopId}/simulate`, payload),
    onSuccess: (response) => {
      setSimulationOutput(JSON.stringify(response.data.actions, null, 2));
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Thiết lập và vận hành</p>
        <h1 className="mt-3 font-display text-4xl font-bold text-white">Cấu hình bot</h1>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_0.9fr]">
        <Card className="space-y-4">
          <Input
            value={form.shopName}
            onChange={(event) => setForm((current) => ({ ...current, shopName: event.target.value }))}
            placeholder="Tên shop"
          />
          <Input
            value={form.shopTagline}
            onChange={(event) =>
              setForm((current) => ({ ...current, shopTagline: event.target.value }))
            }
            placeholder="Câu giới thiệu ngắn"
          />
          <Input
            value={form.botToken}
            onChange={(event) => setForm((current) => ({ ...current, botToken: event.target.value }))}
            placeholder={`BOT_TOKEN (${configQuery.data?.botTokenMasked || "chưa có"})`}
          />
          <Input
            value={form.providerBaseUrl}
            onChange={(event) =>
              setForm((current) => ({ ...current, providerBaseUrl: event.target.value }))
            }
            placeholder="Địa chỉ API nguồn"
          />
          <Input
            value={form.providerBuyerKey}
            onChange={(event) =>
              setForm((current) => ({ ...current, providerBuyerKey: event.target.value }))
            }
            placeholder={`Khóa buyer của nguồn (${configQuery.data?.providerBuyerKeyMasked || "chưa có"})`}
          />
          <Input
            value={form.supportTelegram}
            onChange={(event) =>
              setForm((current) => ({ ...current, supportTelegram: event.target.value }))
            }
            placeholder="Telegram hỗ trợ"
          />
          <Input
            value={form.supportZalo}
            onChange={(event) =>
              setForm((current) => ({ ...current, supportZalo: event.target.value }))
            }
            placeholder="Zalo hỗ trợ"
          />
          <Input
            value={form.logoUrl}
            onChange={(event) => setForm((current) => ({ ...current, logoUrl: event.target.value }))}
            placeholder="Đường dẫn logo"
          />
          <Button className="w-full" onClick={() => saveMutation.mutate()}>
            {saveMutation.isPending ? "Đang lưu..." : "Lưu cấu hình"}
          </Button>
        </Card>

        <div className="space-y-6">
          <Card className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">Tình trạng kết nối</h2>
            <div className="grid gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Telegram: {formatStatusLabel(configQuery.data?.telegramWebhookStatus)} | @{configQuery.data?.telegramBotUsername || "chưa có"}
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Nguồn cấp: {formatStatusLabel(configQuery.data?.providerConnectionStatus)}
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
                Lần đồng bộ gần nhất: {formatDate(configQuery.data?.lastCatalogSyncAt)}
              </div>
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              <Button onClick={() => verifyTelegramMutation.mutate()}>
                Kiểm tra Telegram
              </Button>
              <Button onClick={() => verifyProviderMutation.mutate()}>
                Kiểm tra nguồn
              </Button>
              <Button onClick={() => syncProductsMutation.mutate()}>Đồng bộ sản phẩm</Button>
            </div>
          </Card>

          <Card className="space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">Khu test bot</h2>
            <p className="text-sm text-slate-400">
              Dùng để test local khi shop đang chạy bot mô phỏng.
            </p>
            <div className="grid gap-3 md:grid-cols-3">
              <Button onClick={() => simulateMutation.mutate({ text: "/start" })}>/start</Button>
              <Button onClick={() => simulateMutation.mutate({ callbackData: "home:products" })}>
                Xem sản phẩm
              </Button>
              <Button onClick={() => simulateMutation.mutate({ callbackData: "home:support" })}>
                Hỗ trợ
              </Button>
            </div>
            <Textarea value={simulationOutput} readOnly />
          </Card>
        </div>
      </div>
    </div>
  );
}
