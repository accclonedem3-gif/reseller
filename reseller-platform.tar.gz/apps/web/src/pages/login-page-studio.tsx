import { MessageCircle, Send, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Navigate } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { StudioButton, StudioInput } from "@/components/studio/studio-ui";
import { api } from "@/lib/api";

export function LoginPageStudio() {
  const { login, session } = useAuth();
  const [mode, setMode] = useState<"login" | "forgot">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [recoveryEmail, setRecoveryEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [devResetLink, setDevResetLink] = useState<string | null>(null);
  const [supportOpen, setSupportOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  if (session) {
    return <Navigate to="/" replace />;
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await login(username, password);
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể đăng nhập.",
      );
    } finally {
      setLoading(false);
    }
  }

  async function handleForgotSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setNotice(null);
    setDevResetLink(null);

    try {
      const response = await api.post("/auth/forgot-password", {
        email: recoveryEmail,
      });

      setNotice(response.data?.message || "Nếu email tồn tại, hệ thống đã gửi link reset.");
      setDevResetLink(response.data?.devResetLink || null);
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể gửi link đặt lại mật khẩu.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-stage flex min-h-screen items-center justify-center px-6 py-10">
      <div className="auth-shell w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[12px] border border-emerald-300/24 bg-[linear-gradient(135deg,#34D399,#10B981)] text-[#07131e] shadow-[0_20px_44px_rgba(16,185,129,0.2)]">
            <ShieldCheck className="h-7 w-7" />
          </div>

          <div className="mt-7 flex items-center justify-center gap-2">
            <span className="text-4xl font-black uppercase tracking-tight text-white sm:text-[2.7rem]">
              Altivox
            </span>
            <span className="rounded-[8px] bg-[linear-gradient(135deg,#34D399,#10B981)] px-3 py-1 text-2xl font-black uppercase tracking-tight text-[#07131e] sm:text-[1.95rem]">
              AI
            </span>
          </div>
        </div>

        <div className="auth-panel rounded-[20px] border border-white/10 p-6 sm:p-7">
          {mode === "login" ? (
            <form className="space-y-5" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-200" htmlFor="username">
                  Username
                </label>
                <StudioInput
                  autoComplete="username"
                  id="username"
                  type="text"
                  value={username}
                  onChange={(event) => setUsername(event.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <label className="block text-sm font-medium text-slate-200" htmlFor="password">
                    Mật khẩu
                  </label>
                  <button
                    className="text-sm font-semibold text-emerald-200 transition hover:text-emerald-100"
                    type="button"
                    onClick={() => {
                      setMode("forgot");
                      setError(null);
                      setNotice(null);
                    }}
                  >
                    Quên mật khẩu?
                  </button>
                </div>
                <StudioInput
                  autoComplete="current-password"
                  id="password"
                  placeholder="Nhập mật khẩu"
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                />
              </div>

              {error ? (
                <div className="rounded-[20px] border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                  {error}
                </div>
              ) : null}

              <StudioButton className="w-full" disabled={loading} size="lg" type="submit">
                {loading ? "Đang đăng nhập..." : "Đăng nhập"}
              </StudioButton>
            </form>
          ) : (
            <form className="space-y-5" onSubmit={handleForgotSubmit}>
              <div>
                <p className="text-lg font-semibold text-white">Đặt lại mật khẩu</p>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  Nhập email khôi phục đã gắn với tài khoản.
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-200" htmlFor="recoveryEmail">
                  Email khôi phục
                </label>
                <StudioInput
                  autoComplete="email"
                  id="recoveryEmail"
                  placeholder="name@example.com"
                  type="email"
                  value={recoveryEmail}
                  onChange={(event) => setRecoveryEmail(event.target.value)}
                />
              </div>

              {error ? (
                <div className="rounded-[20px] border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                  {error}
                </div>
              ) : null}

              {notice ? (
                <div className="rounded-[20px] border border-emerald-400/20 bg-emerald-500/10 px-4 py-3 text-sm leading-6 text-emerald-100">
                  <p>{notice}</p>
                  {devResetLink ? (
                    <a
                      className="mt-2 inline-flex font-semibold underline underline-offset-4"
                      href={devResetLink}
                    >
                      Mở link reset test
                    </a>
                  ) : null}
                </div>
              ) : null}

              <StudioButton className="w-full" disabled={loading} size="lg" type="submit">
                {loading ? "Đang gửi..." : "Gửi link đặt lại mật khẩu"}
              </StudioButton>
              <StudioButton
                className="w-full"
                disabled={loading}
                size="lg"
                type="button"
                variant="secondary"
                onClick={() => {
                  setMode("login");
                  setError(null);
                  setNotice(null);
                }}
              >
                Quay lại đăng nhập
              </StudioButton>
            </form>
          )}

          <div className="mt-5 border-t border-white/8 pt-5">
            <button
              aria-expanded={supportOpen}
              className="mx-auto flex items-center gap-2 rounded-[12px] px-3 py-2 text-sm font-semibold text-emerald-200 transition hover:bg-[#18233c] hover:text-emerald-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300/70"
              type="button"
              onClick={() => setSupportOpen((current) => !current)}
            >
              Hỗ trợ
            </button>

            {supportOpen ? (
              <div className="mt-3 flex items-center justify-center gap-3">
                <a
                  aria-label="Telegram @thaidem57"
                  className="flex h-11 w-11 items-center justify-center rounded-[12px] border border-white/10 bg-[#18233c] text-emerald-100 transition hover:-translate-y-px hover:border-emerald-300/30 hover:bg-[#1E2A47]"
                  href="https://t.me/thaidem57"
                  rel="noreferrer"
                  target="_blank"
                  title="Telegram @thaidem57"
                >
                  <Send className="h-5 w-5" />
                </a>
                <a
                  aria-label="Zalo 0366566303"
                  className="flex h-11 w-11 items-center justify-center rounded-[12px] border border-white/10 bg-[#18233c] text-emerald-100 transition hover:-translate-y-px hover:border-emerald-300/30 hover:bg-[#1E2A47]"
                  href="https://zalo.me/0366566303"
                  rel="noreferrer"
                  target="_blank"
                  title="Zalo 0366566303"
                >
                  <MessageCircle className="h-5 w-5" />
                </a>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
