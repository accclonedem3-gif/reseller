import { useQuery } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

export function TopBuyersPage() {
  const query = useQuery({
    queryKey: ["reports", "top-buyers"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  return (
    <div className="space-y-6">
      <h1 className="font-display text-4xl font-bold text-white">Top người mua</h1>
      <Card>
        <div className="space-y-3">
          {(query.data || []).map((buyer: any, index: number) => (
            <div key={buyer.customerId} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
              <div>
                <p className="font-medium text-white">{index + 1}. {buyer.name}</p>
                <p className="text-sm text-slate-400">@{buyer.telegramUsername || "chưa có"}</p>
              </div>
              <div className="text-right">
                <p className="font-semibold text-emerald-300">{formatCurrency(buyer.totalSpent)}</p>
                <p className="text-xs uppercase tracking-[0.18em] text-slate-500">{buyer.totalOrders} đơn</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
