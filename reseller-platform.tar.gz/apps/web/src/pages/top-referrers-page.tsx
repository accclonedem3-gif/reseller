import { useQuery } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";

export function TopReferrersPage() {
  const query = useQuery({
    queryKey: ["reports", "top-referrers"],
    queryFn: async () => (await api.get("/reports/top-referrers")).data,
  });

  return (
    <div className="space-y-6">
      <h1 className="font-display text-4xl font-bold text-white">Top người giới thiệu</h1>
      <Card>
        <p className="text-sm text-slate-400">
          {query.data?.message || "Chưa có dữ liệu giới thiệu trong bản MVP."}
        </p>
      </Card>
    </div>
  );
}
