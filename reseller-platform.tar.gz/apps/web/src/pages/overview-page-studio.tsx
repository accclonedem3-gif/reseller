import { useQuery } from "@tanstack/react-query";
import {
  Bot,
  CircleDollarSign,
  PackageCheck,
  Wallet,
} from "lucide-react";

import {
  StudioBadge,
  StudioCard,
  StudioSectionIntro,
} from "@/components/studio/studio-ui";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function getStatusTone(status: string) {
  if (status === "delivered") return "success" as const;
  if (status === "paid_waiting_stock") return "warning" as const;
  if (status === "failed" || status === "refunded") return "danger" as const;
  return "neutral" as const;
}

export function OverviewPageStudio() {
  const shopQuery = useQuery({
    queryKey: ["shop"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });
  const sourceWalletQuery = useQuery({
    queryKey: ["wallet", "source-balance", "overview"],
    queryFn: async () => (await api.get("/wallet/source-balance")).data,
    retry: false,
  });
  const ordersQuery = useQuery({
    queryKey: ["orders", "overview"],
    queryFn: async () => (await api.get("/orders")).data,
  });
  const revenueQuery = useQuery({
    queryKey: ["revenue", "overview"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });
  const topBuyersQuery = useQuery({
    queryKey: ["top-buyers", "overview"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  const orders = ordersQuery.data || [];
  const topBuyers = topBuyersQuery.data || [];
  const deliveredOrders = orders.filter(
    (item: any) => String(item.status || "").toLowerCase() === "delivered",
  );
  const pendingOrders = orders.filter((item: any) =>
    ["awaiting_payment", "paid", "processing_purchase", "paid_waiting_stock"].includes(
      String(item.status || "").toLowerCase(),
    ),
  );
  const failedOrders = orders.filter((item: any) =>
    ["failed", "refunded"].includes(String(item.status || "").toLowerCase()),
  );
  const latestOrder = orders[0];
  const sourceWalletValue =
    sourceWalletQuery.data?.walletCurrency === "VND"
      ? formatCurrency(Number(sourceWalletQuery.data?.balance || 0))
      : sourceWalletQuery.data?.balanceText ||
        `${Number(sourceWalletQuery.data?.balance || 0)} ${
          sourceWalletQuery.data?.walletCurrency || ""
        }`.trim();

  return (
    <div className="space-y-6">
      <StudioSectionIntro
        kicker="Tổng quan"
        title="Bảng điều khiển bán hàng"
        description={`Shop ${shopQuery.data?.name || "chưa đặt tên"} đang vận hành trên cùng một bảng điều khiển gọn, tập trung vào bot, dòng tiền và các đơn cần xử lý.`}
        actions={
          <>
            <StudioBadge tone="neutral">
              Shop: {shopQuery.data?.name || "Chưa đặt tên"}
            </StudioBadge>
            <StudioBadge tone="success">
              {shopQuery.data?.status
                ? formatStatusLabel(shopQuery.data.status)
                : "Đang hoạt động"}
            </StudioBadge>
          </>
        }
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StudioCard>
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                Telegram bot
              </p>
              <p className="mt-3 text-2xl font-semibold text-white">
                {shopQuery.data?.status ? formatStatusLabel(shopQuery.data.status) : "Đang chờ"}
              </p>
              <p className="mt-2 text-sm text-slate-400">
                Sync gần nhất: {formatDate(shopQuery.data?.lastCatalogSyncAt)}
              </p>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-orange-300/20 bg-orange-400/10 text-orange-100">
              <Bot className="h-5 w-5" />
            </div>
          </div>
        </StudioCard>

        <StudioCard>
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                Ví nguồn Canboso
              </p>
              <p className="mt-3 text-2xl font-semibold text-white">
                {sourceWalletValue}
              </p>
              <p className="mt-2 text-sm text-slate-400">
                Số dư thật của buyer key đang dùng để mua nguồn.
              </p>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-amber-300/20 bg-amber-400/10 text-amber-100">
              <Wallet className="h-5 w-5" />
            </div>
          </div>
        </StudioCard>

        <StudioCard>
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                Doanh thu tháng
              </p>
              <p className="mt-3 text-2xl font-semibold text-white">
                {formatCurrency(revenueQuery.data?.summary?.grossRevenue || 0)}
              </p>
              <p className="mt-2 text-sm text-slate-400">
                {deliveredOrders.length} đơn đã giao thành công.
              </p>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-orange-300/20 bg-orange-500/10 text-orange-100">
              <CircleDollarSign className="h-5 w-5" />
            </div>
          </div>
        </StudioCard>

        <StudioCard>
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                Đơn cần theo dõi
              </p>
              <p className="mt-3 text-2xl font-semibold text-white">{pendingOrders.length}</p>
              <p className="mt-2 text-sm text-slate-400">
                {failedOrders.length} đơn lỗi hoặc hoàn cần kiểm tra thêm.
              </p>
            </div>
            <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-violet-300/18 bg-violet-500/10 text-violet-200">
              <PackageCheck className="h-5 w-5" />
            </div>
          </div>
        </StudioCard>
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.35fr_0.65fr]">
        <StudioCard>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                Luồng đơn gần đây
              </p>
              <h2 className="mt-3 text-3xl font-semibold text-white">Đơn gần đây</h2>
            </div>
            <StudioBadge tone="neutral">Cập nhật theo dữ liệu mới nhất</StudioBadge>
          </div>

          <div className="mt-6 overflow-x-auto">
            <table className="min-w-full border-separate border-spacing-0">
              <thead>
                <tr className="text-left text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">
                  <th className="pb-3 pr-4">Mã đơn</th>
                  <th className="pb-3 pr-4">Sản phẩm</th>
                  <th className="pb-3 pr-4">Khách</th>
                  <th className="pb-3 pr-4">Trạng thái</th>
                  <th className="pb-3 text-right">Tổng tiền</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 5).map((order: any) => (
                  <tr key={order.id} className="text-sm text-slate-300">
                    <td className="border-t border-white/8 py-4 pr-4">
                      <p className="font-semibold text-white">{order.orderCode}</p>
                      <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">
                        {formatDate(order.createdAt)}
                      </p>
                    </td>
                    <td className="border-t border-white/8 py-4 pr-4">
                      <p className="font-medium text-white">{order.productName}</p>
                      <p className="mt-1 text-sm text-slate-500">{order.product?.sourceName || "-"}</p>
                    </td>
                    <td className="border-t border-white/8 py-4 pr-4">
                      {order.customer?.telegramUsername || order.customer?.name || "-"}
                    </td>
                    <td className="border-t border-white/8 py-4 pr-4">
                      <StudioBadge tone={getStatusTone(order.status)}>
                        {formatStatusLabel(order.status)}
                      </StudioBadge>
                    </td>
                    <td className="border-t border-white/8 py-4 text-right font-semibold text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </td>
                  </tr>
                ))}
                {!orders.length ? (
                  <tr>
                    <td className="border-t border-white/8 py-8 text-sm text-slate-400" colSpan={5}>
                      Chưa có đơn hàng nào để hiển thị.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </StudioCard>

        <div className="space-y-6">
          <StudioCard>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Đơn mới nhất
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-white">
                  {latestOrder?.orderCode || "Chưa có dữ liệu"}
                </h2>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  {latestOrder
                    ? `${latestOrder.productName} • ${formatDate(latestOrder.createdAt)}`
                    : "Khi có đơn mới, thông tin sẽ hiển thị ở đây."}
                </p>
              </div>
              {latestOrder ? (
                <StudioBadge tone={getStatusTone(latestOrder.status)}>
                  {formatStatusLabel(latestOrder.status)}
                </StudioBadge>
              ) : null}
            </div>

            <div className="mt-6 grid gap-3">
              <div className="rounded-[20px] border border-white/8 bg-white/[0.03] p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Giá trị đơn
                </p>
                <p className="mt-2 text-lg font-semibold text-white">
                  {latestOrder ? formatCurrency(latestOrder.totalSaleAmount) : "-"}
                </p>
              </div>
              <div className="rounded-[20px] border border-white/8 bg-white/[0.03] p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Nhịp xử lý
                </p>
                <p className="mt-2 text-lg font-semibold text-white">
                  {pendingOrders.length} đơn cần theo dõi
                </p>
                <p className="mt-2 text-sm text-slate-400">
                  {failedOrders.length} đơn lỗi hoặc hoàn cần kiểm tra.
                </p>
              </div>
            </div>
          </StudioCard>

          <StudioCard>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                  Top người mua
                </p>
                <h2 className="mt-3 text-2xl font-semibold text-white">Khách giá trị cao</h2>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-orange-300/20 bg-orange-400/10 text-orange-100">
                <CircleDollarSign className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-6 space-y-3">
              {topBuyers.slice(0, 4).map((buyer: any, index: number) => (
                <div
                  key={buyer.customerId}
                  className="flex items-center justify-between rounded-[22px] border border-white/8 bg-white/[0.03] px-4 py-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-[16px] border border-white/8 bg-slate-950/45 text-sm font-semibold text-white">
                      {String(index + 1).padStart(2, "0")}
                    </div>
                    <div>
                      <p className="font-medium text-white">{buyer.name}</p>
                      <p className="mt-1 text-sm text-slate-500">{buyer.totalOrders} đơn đã mua</p>
                    </div>
                  </div>
                  <p className="font-semibold text-orange-200">{formatCurrency(buyer.totalSpent)}</p>
                </div>
              ))}
              {!topBuyers.length ? (
                <div className="rounded-[22px] border border-dashed border-white/10 bg-white/[0.02] px-4 py-6 text-sm text-slate-400">
                  Chưa có dữ liệu người mua nổi bật.
                </div>
              ) : null}
            </div>
          </StudioCard>
        </div>
      </section>
    </div>
  );
}
