import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, Clock3, RefreshCw, Wallet, XCircle } from "lucide-react";

import { EmptyState } from "@/components/dashboard/empty-state";
import {
  StudioBadge,
  StudioButton,
  StudioCard,
  StudioMetric,
  StudioSectionIntro,
} from "@/components/studio/studio-ui";
import { InfoHint } from "@/components/ui/info-hint";
import { useToast } from "@/components/ui/toast";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

export function PendingOrdersPageStudio() {
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const ordersQuery = useQuery({
    queryKey: ["orders", "pending"],
    queryFn: async () =>
      (await api.get("/orders", { params: { status: "PAID_WAITING_STOCK" } })).data,
  });

  const completeMutation = useMutation({
    mutationFn: async (orderId: string) => (await api.post(`/orders/${orderId}/manual-complete`)).data,
    onSuccess: async () => {
      showToast({ tone: "success", message: "Đơn đã được đánh dấu hoàn tất." });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["orders", "pending"] }),
        queryClient.invalidateQueries({ queryKey: ["orders"] }),
      ]);
    },
    onError: (error: any) => {
      showToast({
        tone: "error",
        message: error?.response?.data?.message || "Không thể xác nhận đơn hoàn tất.",
      });
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async (orderId: string) => (await api.post(`/orders/${orderId}/manual-cancel`)).data,
    onSuccess: async () => {
      showToast({ tone: "success", message: "Đơn đã được chuyển sang trạng thái hủy xử lý." });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["orders", "pending"] }),
        queryClient.invalidateQueries({ queryKey: ["orders"] }),
      ]);
    },
    onError: (error: any) => {
      showToast({
        tone: "error",
        message: error?.response?.data?.message || "Không thể hủy đơn hàng này.",
      });
    },
  });

  const activeOrderId = useMemo(
    () =>
      completeMutation.isPending
        ? (completeMutation.variables as string | undefined)
        : cancelMutation.isPending
          ? (cancelMutation.variables as string | undefined)
          : undefined,
    [
      cancelMutation.isPending,
      cancelMutation.variables,
      completeMutation.isPending,
      completeMutation.variables,
    ],
  );

  const orders = ordersQuery.data || [];
  const totalValue = orders.reduce(
    (sum: number, order: any) => sum + Number(order.totalSaleAmount || 0),
    0,
  );
  const paidOrders = orders.filter(
    (order: any) => String(order.paymentStatus || "").toLowerCase() === "paid",
  ).length;

  return (
    <div className="space-y-6">
      <StudioSectionIntro
        kicker="Theo dõi xử lý"
        title="Nhóm đơn cần seller bám sát"
        description="Tập trung vào các đơn đang chờ có hàng hoặc cần cập nhật lại cho khách, để seller xử lý nhanh và giữ trải nghiệm ổn định."
        actions={
          <StudioButton
            variant="secondary"
            onClick={() => {
              void ordersQuery.refetch();
            }}
          >
            <RefreshCw className="h-4 w-4" />
            Làm mới
          </StudioButton>
        }
      />

      <section className="grid gap-4 xl:grid-cols-3">
        <StudioMetric
          label="Đơn đang mở"
          value={String(orders.length)}
          description="Tổng số đơn seller đang cần theo dõi ở trạng thái chờ xử lý."
          icon={AlertTriangle}
          tone="amber"
        />
        <StudioMetric
          label="Giá trị đơn"
          value={formatCurrency(totalValue)}
          description="Tổng doanh thu hiện nằm trong nhóm đơn chờ có hàng."
          icon={Wallet}
          tone="amber"
        />
        <StudioMetric
          label="Đã thanh toán"
          value={String(paidOrders)}
          description="Những đơn đã trả tiền và cần tiếp tục giám sát để giao hàng."
          icon={Clock3}
          tone="amber"
        />
      </section>

      {ordersQuery.isLoading ? (
        <div className="grid gap-4">
          {Array.from({ length: 3 }).map((_, index) => (
            <StudioCard key={index} className="animate-pulse">
              <div className="h-5 w-28 rounded-full bg-white/8" />
              <div className="mt-4 h-8 w-72 rounded-xl bg-white/8" />
              <div className="mt-3 h-5 w-full max-w-2xl rounded-xl bg-white/8" />
              <div className="mt-6 grid gap-3 md:grid-cols-3">
                <div className="h-24 rounded-[18px] bg-white/8" />
                <div className="h-24 rounded-[18px] bg-white/8" />
                <div className="h-24 rounded-[18px] bg-white/8" />
              </div>
            </StudioCard>
          ))}
        </div>
      ) : orders.length === 0 ? (
        <EmptyState
          title="Không có đơn chờ xử lý"
          description="Khi có đơn cần theo dõi thêm, danh sách này sẽ tự động cập nhật để seller xử lý ngay."
        />
      ) : (
        <StudioCard className="overflow-hidden p-0">
          <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
            <div>
              <p className="text-sm font-semibold text-white">Danh sách cần theo dõi</p>
            </div>
            <div className="flex items-center gap-2">
              <StudioBadge tone="warning">{orders.length} đơn mở</StudioBadge>
              <InfoHint
                content="Đây là các đơn đã trả tiền nhưng còn chờ seller theo dõi hoặc xử lý tiếp."
                label="Xem ghi chú cho Danh sách cần theo dõi"
              />
            </div>
          </div>

          <div className="divide-y divide-white/8">
            {orders.map((order: any) => (
              <div
                key={order.id}
                className="flex flex-col gap-5 px-5 py-5 xl:flex-row xl:items-center xl:gap-6"
              >
                <div className="min-w-0 xl:w-[34%]">
                  <div className="flex flex-wrap items-center gap-3">
                    <StudioBadge tone="warning">{formatStatusLabel(order.status)}</StudioBadge>
                    <span className="text-sm text-slate-500">{formatDate(order.createdAt)}</span>
                  </div>
                  <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">
                    {order.orderCode}
                  </h3>
                  <p className="mt-2 text-sm leading-7 text-slate-400">
                    {order.productName} • {order.customer?.telegramUsername || order.customer?.name || "-"}
                  </p>
                </div>

                <div className="xl:min-w-0 xl:flex-1">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                    Tóm tắt vấn đề
                  </p>
                  <p className="mt-3 rounded-[18px] border border-amber-400/18 bg-amber-500/8 px-4 py-3 text-sm leading-7 text-slate-200">
                    {order.failureReason ||
                      "Đơn đang chờ hệ thống thử mua lại khi upstream có hàng trở lại."}
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 xl:w-[320px]">
                  <div className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                      Giá trị đơn
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </p>
                  </div>
                  <div className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">
                      Thanh toán
                    </p>
                    <p className="mt-3 text-2xl font-semibold text-white">
                      {formatStatusLabel(order.paymentStatus)}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 xl:w-[280px] xl:justify-end">
                  <StudioButton
                    variant="secondary"
                    onClick={() => {
                      completeMutation.mutate(order.id);
                    }}
                    disabled={
                      completeMutation.isPending ||
                      cancelMutation.isPending
                    }
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    {completeMutation.isPending && activeOrderId === order.id
                      ? "Đang xác nhận..."
                      : "Xác nhận đã xong"}
                  </StudioButton>

                  <StudioButton
                    variant="danger"
                    onClick={() => {
                      const accepted = window.confirm(
                        `Hủy xử lý đơn ${order.orderCode}? Đơn sẽ rời khỏi nhóm chờ xử lý.`,
                      );

                      if (!accepted) {
                        return;
                      }

                      cancelMutation.mutate(order.id);
                    }}
                    disabled={
                      completeMutation.isPending ||
                      cancelMutation.isPending
                    }
                  >
                    <XCircle className="h-4 w-4" />
                    {cancelMutation.isPending && activeOrderId === order.id
                      ? "Đang hủy..."
                      : "Hủy đơn"}
                  </StudioButton>
                </div>
              </div>
            ))}
          </div>
        </StudioCard>
      )}
    </div>
  );
}
