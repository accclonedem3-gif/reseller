import { CheckCircle2, LoaderCircle, XCircle } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";

export function PaymentStatusPage({ mode }: { mode: "success" | "cancel" }) {
  const [searchParams] = useSearchParams();
  const externalOrderCode = searchParams.get("orderCode") || "";
  const reconcileToken = searchParams.get("rt") || "";
  const [reconcileState, setReconcileState] = useState<{
    loading: boolean;
    message: string | null;
  }>({
    loading: mode === "success" && Boolean(externalOrderCode && reconcileToken),
    message: null,
  });

  useEffect(() => {
    if (mode !== "success" || !externalOrderCode || !reconcileToken) {
      setReconcileState({
        loading: false,
        message: null,
      });
      return;
    }

    let cancelled = false;

    void api
      .post(`/webhooks/payos/reconcile/${externalOrderCode}`, {
        token: reconcileToken,
      })
      .then((response) => {
        if (cancelled) {
          return;
        }

        const data = response.data as {
          reconciled?: boolean;
          kind?: string;
          providerStatus?: string;
          localOrderStatus?: string | null;
          failureReason?: string | null;
        };

        if (data.localOrderStatus === "FAILED" && data.failureReason) {
          setReconcileState({
            loading: false,
            message: `Thanh toan da duoc ghi nhan nhung don chua mua duoc: ${data.failureReason}`,
          });
          return;
        }

        if (data.reconciled) {
          setReconcileState({
            loading: false,
            message:
              data.kind === "order"
                ? "He thong da xac nhan thanh toan va dang xu ly giao tai khoan."
                : "He thong da xac nhan thanh toan thanh cong.",
          });
          return;
        }

        setReconcileState({
          loading: false,
          message: data.providerStatus
            ? `PayOS hien bao trang thai ${data.providerStatus}. Neu ban vua moi chuyen khoan, hay cho them vai giay roi tai lai trang.`
            : "He thong chua xac nhan duoc giao dich. Hay cho them vai giay roi tai lai trang.",
        });
      })
      .catch(() => {
        if (cancelled) {
          return;
        }

        setReconcileState({
          loading: false,
          message: "Chua the doi soat thanh toan tu dong. Hay tai lai trang sau vai giay.",
        });
      });

    return () => {
      cancelled = true;
    };
  }, [externalOrderCode, mode, reconcileToken]);

  const detailMessage = useMemo(() => {
    if (mode !== "success") {
      return "Ban co the quay lai bot Telegram hoac dashboard de tao giao dich khac.";
    }

    if (reconcileState.loading) {
      return "Dang doi soat thanh toan voi PayOS va cap nhat trang thai don hang...";
    }

    if (!reconcileToken) {
      return "Trang thanh toan nay khong co ma doi soat hop le. Hay quay lai bot hoac dashboard de kiem tra trang thai don hang.";
    }

    return (
      reconcileState.message ||
      "Ban co the quay lai bot Telegram hoac dashboard de theo doi trang thai don hang va tinh hinh giao account."
    );
  }, [mode, reconcileState, reconcileToken]);

  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <Card className="max-w-xl">
        <div className="flex items-start gap-4">
          <div className="glass-chip flex h-14 w-14 items-center justify-center rounded-2xl">
            {reconcileState.loading && mode === "success" ? (
              <LoaderCircle className="h-6 w-6 animate-spin text-amber-200" />
            ) : mode === "success" ? (
              <CheckCircle2 className="h-6 w-6 text-emerald-200" />
            ) : (
              <XCircle className="h-6 w-6 text-rose-200" />
            )}
          </div>
          <div>
            <p className="app-kicker">Ket qua thanh toan</p>
            <h1 className="mt-3 font-display text-3xl font-semibold text-white">
              {mode === "success" ? "Thanh toan thanh cong" : "Thanh toan da bi huy"}
            </h1>
            <p className="mt-3 text-sm leading-7 text-slate-300">
              Ma thanh toan: {externalOrderCode || "khong co"}
            </p>
            <p className="mt-2 text-sm leading-7 text-slate-500">{detailMessage}</p>
            <div className="mt-6">
              <Button variant="secondary" onClick={() => window.location.assign("/")}>
                Quay ve dashboard
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
