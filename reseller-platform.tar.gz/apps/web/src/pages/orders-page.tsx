import { useQuery } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function statusTone(status: string) {
  if (status === "delivered") return "success" as const;
  if (status === "failed") return "danger" as const;
  if (status === "paid_waiting_stock") return "warning" as const;
  return "neutral" as const;
}

export function OrdersPage() {
  const ordersQuery = useQuery({
    queryKey: ["orders"],
    queryFn: async () => (await api.get("/orders")).data,
  });

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Sổ đơn hàng</p>
        <h1 className="mt-3 font-display text-4xl font-bold text-white">Đơn hàng</h1>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3">Mã đơn</th>
                <th className="pb-3">Sản phẩm</th>
                <th className="pb-3">Khách</th>
                <th className="pb-3">Trạng thái</th>
                <th className="pb-3">Thanh toán</th>
                <th className="pb-3">Tạo lúc</th>
                <th className="pb-3 text-right">Tổng</th>
              </tr>
            </thead>
            <tbody>
              {(ordersQuery.data || []).map((order: any) => (
                <tr key={order.id} className="border-t border-white/5 text-slate-300">
                  <td className="py-3">{order.orderCode}</td>
                  <td className="py-3">{order.productName}</td>
                  <td className="py-3">{order.customer?.telegramUsername || "-"}</td>
                  <td className="py-3">
                    <Badge tone={statusTone(order.status)}>{formatStatusLabel(order.status)}</Badge>
                  </td>
                  <td className="py-3 uppercase tracking-[0.18em] text-xs text-slate-500">
                    {formatStatusLabel(order.paymentStatus)}
                  </td>
                  <td className="py-3">{formatDate(order.createdAt)}</td>
                  <td className="py-3 text-right">{formatCurrency(order.totalSaleAmount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
