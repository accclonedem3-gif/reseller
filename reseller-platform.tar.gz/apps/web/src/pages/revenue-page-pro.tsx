import { useQuery } from "@tanstack/react-query";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";
import { BarChart3, CircleDollarSign, PackageCheck } from "lucide-react";

import { SectionHeading } from "@/components/dashboard/section-heading";
import { MetricCard } from "@/components/metric-card";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

export function RevenuePage() {
  const query = useQuery({
    queryKey: ["reports", "revenue"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });

  const series = query.data?.series || [];
  const averageRevenue =
    series.length > 0
      ? Math.round(
          series.reduce((sum: number, item: any) => sum + Number(item.grossRevenue || 0), 0) /
            series.length,
        )
      : 0;

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Phân tích tài chính"
        title="Doanh thu"
        description="Theo dõi hiệu quả kinh doanh theo ngày, biên lợi nhuận ước tính và nhịp giao hàng để seller biết lúc nào cần đẩy broadcast, nạp ví hoặc chỉnh giá."
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Doanh thu gộp"
          value={formatCurrency(query.data?.summary?.grossRevenue || 0)}
          description="Tổng doanh thu của các đơn đã thanh toán trong kỳ dữ liệu hiện tại."
          icon={CircleDollarSign}
          tone="amber"
        />
        <MetricCard
          label="Lợi nhuận ước tính"
          value={formatCurrency(query.data?.summary?.estimatedProfit || 0)}
          description="Doanh thu sau khi trừ chi phí mua nguồn theo snapshot của từng đơn."
          icon={BarChart3}
          tone="emerald"
        />
        <MetricCard
          label="Đơn đã giao"
          value={String(query.data?.summary?.deliveredOrders || 0)}
          description="Những đơn đã hoàn tất giao account và đóng toàn bộ flow backend."
          icon={PackageCheck}
          tone="sky"
        />
        <MetricCard
          label="Trung bình / ngày"
          value={formatCurrency(averageRevenue)}
          description="Doanh thu gộp trung bình trên mỗi ngày đang có dữ liệu trong tháng."
          icon={CircleDollarSign}
          tone="amber"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="app-kicker">Biểu đồ doanh thu</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Doanh thu theo ngày
              </h2>
            </div>
            <p className="text-sm text-slate-500">Tập trung vào gross revenue để seller đọc nhanh.</p>
          </div>

          <div className="mt-6 h-[380px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={series}>
                <defs>
                  <linearGradient id="revenue-fill" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#67e8f9" stopOpacity={0.58} />
                    <stop offset="65%" stopColor="#38bdf8" stopOpacity={0.18} />
                    <stop offset="100%" stopColor="#0f172a" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(148,163,184,0.12)" vertical={false} />
                <XAxis
                  dataKey="label"
                  stroke="rgba(148,163,184,0.68)"
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: 18,
                    border: "1px solid rgba(148,163,184,0.16)",
                    background: "rgba(9,14,27,0.94)",
                    boxShadow: "0 20px 60px rgba(2,6,23,0.28)",
                  }}
                  formatter={(value: number, name: string) => [
                    formatCurrency(Number(value || 0)),
                    name === "grossRevenue" ? "Doanh thu gộp" : "Giá trị",
                  ]}
                  labelFormatter={(label) => `Ngày ${label}`}
                />
                <Area
                  type="monotone"
                  dataKey="grossRevenue"
                  stroke="#67e8f9"
                  strokeWidth={2.5}
                  fill="url(#revenue-fill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="app-kicker">Daily breakdown</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Chi tiết theo ngày
              </h2>
            </div>
            <div className="glass-chip rounded-full px-3 py-1.5 text-xs text-slate-200">
              {series.length} mốc dữ liệu
            </div>
          </div>

          <div className="mt-6 space-y-3">
            {series.map((item: any) => (
              <div
                key={item.label}
                className="glass-chip flex flex-col gap-3 rounded-[24px] px-4 py-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="font-semibold text-white">{item.label}</p>
                  <p className="mt-1 text-sm text-slate-500">
                    {item.deliveredOrders} đơn đã giao • Lợi nhuận ước tính {formatCurrency(item.estimatedProfit || 0)}
                  </p>
                </div>
                <p className="font-display text-2xl font-semibold text-orange-100">
                  {formatCurrency(item.grossRevenue || 0)}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}
