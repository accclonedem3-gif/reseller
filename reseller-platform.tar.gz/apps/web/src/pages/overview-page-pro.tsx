import { useQuery } from "@tanstack/react-query";
import {
  ArrowUpRight,
  Bot,
  CircleDollarSign,
  Coins,
  PackageCheck,
  ShieldCheck,
  ShoppingCart,
  Wallet,
} from "lucide-react";

import { SectionHeading } from "@/components/dashboard/section-heading";
import { StatChip } from "@/components/dashboard/stat-chip";
import { MetricCard } from "@/components/metric-card";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/api";
import { formatCurrency, formatDate, formatStatusLabel } from "@/lib/format";

function getStatusTone(status: string) {
  if (status === "delivered") return "success" as const;
  if (status === "paid_waiting_stock") return "warning" as const;
  if (status === "failed" || status === "refunded") return "danger" as const;
  return "neutral" as const;
}

export function OverviewPage() {
  const shopQuery = useQuery({
    queryKey: ["shop"],
    queryFn: async () => (await api.get("/shops/current")).data,
  });
  const walletQuery = useQuery({
    queryKey: ["wallet"],
    queryFn: async () => (await api.get("/wallet")).data,
  });
  const ordersQuery = useQuery({
    queryKey: ["orders", "overview"],
    queryFn: async () => (await api.get("/orders")).data,
  });
  const revenueQuery = useQuery({
    queryKey: ["revenue", "overview"],
    queryFn: async () => (await api.get("/reports/revenue")).data,
  });
  const topBuyersQuery = useQuery({
    queryKey: ["top-buyers", "overview"],
    queryFn: async () => (await api.get("/reports/top-buyers")).data,
  });

  const orders = ordersQuery.data || [];
  const deliveredOrders = orders.filter((item: any) => item.status === "delivered");
  const pendingOrders = orders.filter((item: any) =>
    ["awaiting_payment", "paid", "processing_purchase", "paid_waiting_stock"].includes(
      item.status,
    ),
  );
  const failedOrders = orders.filter((item: any) =>
    ["failed", "refunded"].includes(String(item.status || "").toLowerCase()),
  );
  const lastOrder = orders[0];

  return (
    <div className="space-y-6">
      <SectionHeading
        eyebrow="Operations overview"
        title={shopQuery.data?.name || "Trung tâm vận hành seller"}
        description="Một lớp quan sát tổng hợp cho Telegram bot, ví nội bộ, doanh thu và toàn bộ vòng đời đơn hàng. Mọi điểm nghẽn quan trọng đều được gom về cùng một bề mặt làm việc."
      />

      <section className="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
        <Card className="overflow-hidden p-0">
          <div className="relative px-6 py-6 sm:px-7">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-cyan-300 via-amber-300 to-emerald-300" />
            <div className="flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
              <div className="max-w-2xl">
                <p className="app-kicker">Seller control room</p>
                <h2 className="mt-4 text-balance font-display text-4xl font-semibold tracking-tight text-white">
                  Tối ưu vận hành bot theo nhịp bán hàng thực tế.
                </h2>
                <p className="mt-4 text-sm leading-7 text-slate-300 sm:text-base">
                  Giao diện mới ưu tiên đọc nhanh: tình trạng đồng bộ catalog, sức khỏe dòng tiền,
                  đơn chờ xử lý và doanh thu tháng đều nổi bật ngay từ fold đầu tiên.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <StatChip
                  icon={Bot}
                  label="Telegram"
                  value={shopQuery.data?.status ? formatStatusLabel(shopQuery.data.status) : "Đang chờ"}
                  meta={`Sync gần nhất: ${formatDate(shopQuery.data?.lastCatalogSyncAt)}`}
                  tone="sky"
                />
                <StatChip
                  icon={Wallet}
                  label="Số dư ví"
                  value={formatCurrency(walletQuery.data?.balance || 0)}
                  meta="Nguồn lực sẵn sàng để mua upstream"
                  tone="amber"
                />
              </div>
            </div>
          </div>
        </Card>

        <div className="grid gap-4">
          <Card>
            <p className="app-kicker">Đơn mới nhất</p>
            <div className="mt-4 flex items-start justify-between gap-3">
              <div>
                <p className="font-display text-2xl font-semibold text-white">
                  {lastOrder?.orderCode || "Chưa có đơn"}
                </p>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  {lastOrder
                    ? `${lastOrder.productName} • ${formatCurrency(lastOrder.totalSaleAmount)}`
                    : "Dữ liệu đơn mới sẽ xuất hiện ngay khi seller có phát sinh giao dịch."}
                </p>
              </div>
              {lastOrder ? (
                <Badge tone={getStatusTone(lastOrder.status)}>
                  {formatStatusLabel(lastOrder.status)}
                </Badge>
              ) : null}
            </div>
          </Card>

          <Card>
            <p className="app-kicker">Nhịp doanh thu</p>
            <div className="mt-4 flex items-end justify-between gap-4">
              <div>
                <p className="font-display text-3xl font-semibold text-white">
                  {formatCurrency(revenueQuery.data?.summary?.grossRevenue || 0)}
                </p>
                <p className="mt-2 text-sm text-slate-400">Doanh thu gộp trong tháng hiện tại.</p>
              </div>
              <div className="glass-chip rounded-2xl px-3 py-2 text-sm text-emerald-200">
                {deliveredOrders.length} đơn đã giao
              </div>
            </div>
          </Card>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Số dư khả dụng"
          value={formatCurrency(walletQuery.data?.balance || 0)}
          description="Khoản ngân sách seller đang có thể dùng để xử lý mua upstream ngay."
          icon={Wallet}
          tone="amber"
        />
        <MetricCard
          label="Doanh thu tháng"
          value={formatCurrency(revenueQuery.data?.summary?.grossRevenue || 0)}
          description="Tổng tiền thu về từ các đơn đã ghi nhận thanh toán trong dữ liệu hiện tại."
          icon={CircleDollarSign}
          tone="sky"
        />
        <MetricCard
          label="Đơn cần chú ý"
          value={String(pendingOrders.length)}
          description="Bao gồm đơn chờ thanh toán, đang mua nguồn hoặc đang chờ upstream có hàng."
          icon={ShoppingCart}
          tone="emerald"
        />
        <MetricCard
          label="Đơn lỗi / hoàn"
          value={String(failedOrders.length)}
          description="Theo dõi để cải thiện ổn định của payment, wallet debit và purchase upstream."
          icon={ShieldCheck}
          tone="amber"
        />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="app-kicker">Live order feed</p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Đơn hàng gần đây
              </h2>
            </div>
            <div className="glass-chip inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs text-slate-200">
              <ArrowUpRight className="h-3.5 w-3.5" />
              Theo dõi 6 đơn mới nhất
            </div>
          </div>

          <div className="mt-6 app-table-wrap">
            <table className="app-table">
              <thead>
                <tr>
                  <th>Mã đơn</th>
                  <th>Sản phẩm</th>
                  <th>Khách</th>
                  <th>Trạng thái</th>
                  <th className="text-right">Tổng tiền</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 6).map((order: any) => (
                  <tr key={order.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <span className="glass-chip flex h-10 w-10 items-center justify-center rounded-2xl">
                          <ShoppingCart className="h-4 w-4 text-slate-100" />
                        </span>
                        <div>
                          <p className="font-semibold text-white">{order.orderCode}</p>
                          <p className="mt-1 text-xs uppercase tracking-[0.18em] text-slate-500">
                            {formatDate(order.createdAt)}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <p className="font-medium text-white">{order.productName}</p>
                      <p className="mt-1 text-sm text-slate-500">{order.product?.sourceName || "-"}</p>
                    </td>
                    <td>{order.customer?.telegramUsername || order.customer?.name || "-"}</td>
                    <td>
                      <Badge tone={getStatusTone(order.status)}>
                        {formatStatusLabel(order.status)}
                      </Badge>
                    </td>
                    <td className="text-right font-semibold text-white">
                      {formatCurrency(order.totalSaleAmount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Buyer leaderboard</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Top người mua
                </h2>
              </div>
              <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
                <Coins className="h-5 w-5 text-cyan-100" />
              </span>
            </div>

            <div className="mt-6 space-y-3">
              {(topBuyersQuery.data || []).slice(0, 5).map((buyer: any, index: number) => (
                <div
                  key={buyer.customerId}
                  className="glass-chip flex items-center justify-between rounded-[22px] px-4 py-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/[0.06] text-sm font-semibold text-white">
                      {String(index + 1).padStart(2, "0")}
                    </div>
                    <div>
                      <p className="font-medium text-white">{buyer.name}</p>
                      <p className="mt-1 text-sm text-slate-500">{buyer.totalOrders} đơn đã mua</p>
                    </div>
                  </div>
                  <p className="font-semibold text-emerald-300">{formatCurrency(buyer.totalSpent)}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="app-kicker">Operational health</p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                  Chỉ số vận hành
                </h2>
              </div>
              <span className="glass-chip flex h-12 w-12 items-center justify-center rounded-2xl">
                <PackageCheck className="h-5 w-5 text-amber-100" />
              </span>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <StatChip
                icon={PackageCheck}
                label="Đơn đã giao"
                value={String(deliveredOrders.length)}
                meta="Hoàn tất giao account"
                tone="emerald"
              />
              <StatChip
                icon={Bot}
                label="Đơn chờ xử lý"
                value={String(pendingOrders.length)}
                meta="Cần theo dõi tiếp"
                tone="sky"
              />
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
