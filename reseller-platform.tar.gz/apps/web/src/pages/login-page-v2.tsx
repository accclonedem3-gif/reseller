import { useState } from "react";
import {
  Bot,
  CreditCard,
  PackageCheck,
  RadioTower,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Navigate } from "react-router-dom";

import { useAuth } from "@/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

function FeatureChip({
  icon: Icon,
  title,
  description,
}: {
  icon: typeof Bot;
  title: string;
  description: string;
}) {
  return (
    <div className="glass-chip rounded-[24px] p-4">
      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/[0.08] text-slate-100">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <p className="font-medium text-white">{title}</p>
          <p className="mt-1 text-sm leading-6 text-slate-400">{description}</p>
        </div>
      </div>
    </div>
  );
}

export function LoginPage() {
  const { login, register, session } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("seller@example.com");
  const [password, setPassword] = useState("Seller123!");
  const [displayName, setDisplayName] = useState("Seller mẫu");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (session) {
    return <Navigate to="/" replace />;
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register(email, password, displayName);
      }
    } catch (submissionError: any) {
      setError(
        submissionError?.response?.data?.message ||
          submissionError?.message ||
          "Không thể đăng nhập.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden px-4 py-8 sm:px-6">
      <div className="orbital-dot left-[8%] top-[12%] h-28 w-28 bg-sky-400/20" />
      <div
        className="orbital-dot right-[14%] top-[22%] h-20 w-20 bg-amber-300/20"
        style={{ animationDelay: "1.4s" }}
      />
      <div
        className="orbital-dot bottom-[16%] right-[20%] h-24 w-24 bg-emerald-300/15"
        style={{ animationDelay: "2.1s" }}
      />

      <div className="mx-auto grid min-h-[calc(100vh-4rem)] max-w-7xl items-center gap-8 lg:grid-cols-[1.08fr_0.92fr]">
        <section className="reveal-up space-y-8 px-2 sm:px-4">
          <div className="glass-chip inline-flex items-center gap-2 rounded-full px-4 py-2 text-[11px] uppercase tracking-[0.3em] text-slate-100">
            <Sparkles className="h-3.5 w-3.5" />
            Nền tảng seller operations
          </div>

          <div className="space-y-5">
            <h1 className="max-w-3xl text-balance font-display text-5xl font-semibold tracking-tight text-white sm:text-6xl xl:text-7xl">
              Dashboard reseller tối màu, nhanh và đủ lực để vận hành bot bán hàng thật.
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-slate-300">
              Quản lý bot Telegram, đồng bộ catalog nguồn, theo dõi ví nội bộ, đơn hàng
              và broadcast từ một hệ thống thống nhất, gọn và sẵn sàng chạy local.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <FeatureChip
              icon={Bot}
              title="Quản trị bot theo shop"
              description="Mỗi seller tự nhập BOT_TOKEN, key nguồn và cấu hình riêng trực tiếp trên dashboard."
            />
            <FeatureChip
              icon={PackageCheck}
              title="Catalog đồng bộ nhanh"
              description="Sync sản phẩm từ nguồn, override giá bán và kiểm soát trạng thái hiển thị trong bot."
            />
            <FeatureChip
              icon={CreditCard}
              title="Ví nội bộ + ledger"
              description="Theo dõi số dư, bút toán trừ hoàn và các thao tác tài chính theo từng đơn hàng."
            />
            <FeatureChip
              icon={RadioTower}
              title="Flow vận hành liền mạch"
              description="Dashboard, queue worker và Telegram bot phối hợp theo thời gian thực trong môi trường local."
            />
          </div>
        </section>

        <section className="reveal-up reveal-delay-1">
          <Card className="relative overflow-hidden border-white/10 p-0">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-sky-400 via-emerald-300 to-amber-300" />

            <div className="grid gap-0 lg:grid-cols-[0.42fr_0.58fr]">
              <div className="border-b border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.06),rgba(255,255,255,0.02))] p-6 lg:border-b-0 lg:border-r">
                <div className="glass-chip inline-flex h-12 w-12 items-center justify-center rounded-2xl text-white">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <h2 className="mt-5 font-display text-3xl font-semibold text-white">
                  Truy cập dashboard
                </h2>
                <p className="mt-3 text-sm leading-7 text-slate-400">
                  Dùng tài khoản demo đã seed sẵn để vào hệ thống ngay hoặc tạo seller mới
                  trong môi trường local.
                </p>

                <div className="mt-8 space-y-4">
                  <div className="glass-chip rounded-[22px] p-4">
                    <p className="text-[11px] uppercase tracking-[0.24em] text-slate-500">
                      Demo seller
                    </p>
                    <p className="mt-2 font-medium text-white">seller@example.com</p>
                    <p className="text-sm text-slate-400">Seller123!</p>
                  </div>
                  <div className="glass-chip rounded-[22px] p-4">
                    <p className="text-[11px] uppercase tracking-[0.24em] text-slate-500">
                      Quyền truy cập
                    </p>
                    <p className="mt-2 text-sm leading-6 text-slate-300">
                      Seller có thể cấu hình bot, đồng bộ sản phẩm, sửa giá và theo dõi đơn.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-6 sm:p-7">
                <div className="mb-6 flex gap-2 rounded-[22px] border border-white/10 bg-white/[0.04] p-1">
                  <button
                    className={`flex-1 rounded-[18px] px-4 py-3 text-sm font-semibold transition ${
                      mode === "login"
                        ? "bg-white text-slate-950 shadow-[0_16px_36px_rgba(15,23,42,0.18)]"
                        : "text-slate-400 hover:text-white"
                    }`}
                    onClick={() => setMode("login")}
                    type="button"
                  >
                    Đăng nhập
                  </button>
                  <button
                    className={`flex-1 rounded-[18px] px-4 py-3 text-sm font-semibold transition ${
                      mode === "register"
                        ? "bg-white text-slate-950 shadow-[0_16px_36px_rgba(15,23,42,0.18)]"
                        : "text-slate-400 hover:text-white"
                    }`}
                    onClick={() => setMode("register")}
                    type="button"
                  >
                    Tạo seller
                  </button>
                </div>

                <form className="space-y-4" onSubmit={handleSubmit}>
                  <div className="space-y-2">
                    <label className="text-sm text-slate-400">Email</label>
                    <Input value={email} onChange={(event) => setEmail(event.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-slate-400">Mật khẩu</label>
                    <Input
                      type="password"
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                    />
                  </div>
                  {mode === "register" ? (
                    <div className="space-y-2">
                      <label className="text-sm text-slate-400">Tên shop / seller</label>
                      <Input
                        value={displayName}
                        onChange={(event) => setDisplayName(event.target.value)}
                      />
                    </div>
                  ) : null}
                  {error ? (
                    <div className="rounded-[22px] border border-rose-500/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">
                      {error}
                    </div>
                  ) : null}
                  <Button className="w-full rounded-[20px] py-3.5" disabled={loading} type="submit">
                    {loading
                      ? "Đang xử lý..."
                      : mode === "login"
                        ? "Vào dashboard"
                        : "Tạo tài khoản seller"}
                  </Button>
                </form>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
}
