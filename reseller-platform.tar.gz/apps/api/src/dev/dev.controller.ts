import { Body, Controller, Get, Inject, Param, Post, Res } from "@nestjs/common";
import type { Response } from "express";

import { OrdersService } from "../orders/orders.service";
import { TelegramBotService } from "../lib/telegram-bot.service";

@Controller("dev")
export class DevController {
  constructor(
    @Inject(OrdersService)
    private readonly ordersService: OrdersService,
    @Inject(TelegramBotService)
    private readonly telegramBotService: TelegramBotService,
  ) {}

  @Get("mock-payments/:externalOrderCode")
  async getMockPaymentPage(
    @Param("externalOrderCode") externalOrderCode: string,
    @Res() response: Response,
  ) {
    response.type("html").send(`
      <html>
        <head>
          <title>Mock Payment</title>
          <style>
            body { font-family: Arial, sans-serif; background: #050816; color: #fff; padding: 32px; }
            .card { max-width: 520px; margin: 0 auto; padding: 24px; border-radius: 24px; background: #0d1326; box-shadow: 0 30px 80px rgba(0,0,0,.4); }
            button { background: #22c55e; color: #00110a; border: 0; padding: 14px 18px; border-radius: 12px; font-weight: 700; cursor: pointer; width: 100%; }
            code { color: #38bdf8; }
          </style>
        </head>
        <body>
          <div class="card">
            <h1>Mock Payment Checkout</h1>
            <p>External order code: <code>${externalOrderCode}</code></p>
            <p>Trang này dùng để giả lập callback thanh toán local khi đang chạy ở chế độ mock.</p>
            <form method="post" action="/api/v1/dev/mock-payments/${externalOrderCode}/confirm">
              <button type="submit">Xác nhận thanh toán thành công</button>
            </form>
          </div>
        </body>
      </html>
    `);
  }

  @Post("mock-payments/:externalOrderCode/confirm")
  async confirmMockPayment(
    @Param("externalOrderCode") externalOrderCode: string,
    @Res() response: Response,
  ) {
    const order = await this.ordersService.markPaymentCompleted(externalOrderCode, {
      mock: true,
      externalOrderCode,
    });

    response.type("html").send(`
      <html>
        <body style="font-family: Arial, sans-serif; background: #050816; color: #fff; padding: 32px;">
          <h1>Thanh toán đã được xác nhận</h1>
          <p>Đơn hàng: ${order.orderCode}</p>
          <p>Trạng thái hiện tại: ${order.status}</p>
          <p>Bạn có thể quay lại Telegram hoặc dashboard để xem tiến trình xử lý.</p>
        </body>
      </html>
    `);
  }

  @Post("telegram/:shopId/simulate")
  async simulateTelegram(
    @Param("shopId") shopId: string,
    @Body()
    body: {
      text?: string;
      callbackData?: string;
      telegramUserId?: string;
      telegramUsername?: string;
      firstName?: string;
      lastName?: string;
    },
  ) {
    const update = body.callbackData
      ? {
          callback_query: {
            id: `mock-callback-${Date.now()}`,
            data: body.callbackData,
            from: {
              id: body.telegramUserId || "9988776655",
              username: body.telegramUsername || "demo_buyer",
              first_name: body.firstName || "Demo",
              last_name: body.lastName || "Buyer",
            },
            message: {
              chat: {
                id: body.telegramUserId || "9988776655",
              },
              message_id: 1,
            },
          },
        }
      : {
          message: {
            text: body.text || "/start",
            chat: {
              id: body.telegramUserId || "9988776655",
            },
            from: {
              id: body.telegramUserId || "9988776655",
              username: body.telegramUsername || "demo_buyer",
              first_name: body.firstName || "Demo",
              last_name: body.lastName || "Buyer",
            },
          },
        };

    return this.telegramBotService.handleIncomingUpdate(shopId, update);
  }
}
