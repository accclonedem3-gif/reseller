import {
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Query,
  UseGuards,
} from "@nestjs/common";

import { CurrentUser } from "../common/decorators/current-user.decorator";
import { JwtAuthGuard } from "../common/guards/jwt-auth.guard";
import type { AuthenticatedUser } from "../types";

import { OrdersService } from "./orders.service";

@Controller("orders")
@UseGuards(JwtAuthGuard)
export class OrdersController {
  constructor(
    @Inject(OrdersService)
    private readonly ordersService: OrdersService,
  ) {}

  @Get()
  listOrders(
    @CurrentUser() user: AuthenticatedUser,
    @Query("status") status?: string,
  ) {
    return this.ordersService.listOrders(user, status);
  }

  @Get(":id")
  getOrder(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.ordersService.getOrder(user, id);
  }

  @Post(":id/manual-complete")
  completeManualOrder(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.ordersService.completePendingManualOrder(user, id);
  }

  @Post(":id/manual-cancel")
  cancelManualOrder(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.ordersService.cancelPendingManualOrder(user, id);
  }

  @Post(":id/manual-payment-confirm")
  confirmManualCryptoPayment(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.ordersService.confirmManualCryptoPayment(user, id);
  }
}
