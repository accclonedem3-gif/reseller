import { Inject, Injectable } from "@nestjs/common";

import { PrismaService } from "../db/prisma.service";
import { decimalToNumber } from "../lib/utils";
import { ShopsService } from "../shops/shops.service";
import type { AuthenticatedUser } from "../types";

@Injectable()
export class ReportsService {
  constructor(
    @Inject(PrismaService)
    private readonly prisma: PrismaService,
    @Inject(ShopsService)
    private readonly shopsService: ShopsService,
  ) {}

  async getTopBuyers(user: AuthenticatedUser) {
    const shop = await this.shopsService.getSellerShop(user.id);
    const orders = await this.prisma.order.findMany({
      where: {
        shopId: shop.id,
        paymentStatus: "PAID",
      },
      include: {
        customer: true,
      },
    });

    const grouped = new Map<
      string,
      {
        customerId: string;
        name: string;
        telegramUsername: string | null;
        totalOrders: number;
        totalSpent: number;
      }
    >();

    for (const order of orders) {
      const current = grouped.get(order.customerId) || {
        customerId: order.customerId,
        name:
          [order.customer.firstName, order.customer.lastName]
            .filter(Boolean)
            .join(" ") ||
          order.customer.telegramUsername ||
          order.customer.telegramUserId,
        telegramUsername: order.customer.telegramUsername,
        totalOrders: 0,
        totalSpent: 0,
      };

      current.totalOrders += 1;
      current.totalSpent += decimalToNumber(order.totalSaleAmount);
      grouped.set(order.customerId, current);
    }

    return Array.from(grouped.values())
      .sort((left, right) => right.totalSpent - left.totalSpent)
      .slice(0, 10);
  }

  async getTopReferrers() {
    return {
      items: [],
      message:
        "Phần referral đang ở mức MVP. Schema đã sẵn sàng nhưng hiện chưa có sự kiện giới thiệu nào được ghi nhận.",
    };
  }

  async getRevenue(user: AuthenticatedUser) {
    const shop = await this.shopsService.getSellerShop(user.id);
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);

    const orders = await this.prisma.order.findMany({
      where: {
        shopId: shop.id,
        paymentStatus: "PAID",
        createdAt: {
          gte: startOfMonth,
        },
      },
      orderBy: {
        createdAt: "asc",
      },
    });

    const points = new Map<
      string,
      {
        label: string;
        grossRevenue: number;
        estimatedProfit: number;
        deliveredOrders: number;
      }
    >();

    for (const order of orders) {
      const label = order.createdAt.toISOString().slice(0, 10);
      const current = points.get(label) || {
        label,
        grossRevenue: 0,
        estimatedProfit: 0,
        deliveredOrders: 0,
      };

      const totalSale = decimalToNumber(order.totalSaleAmount);
      const totalSource = decimalToNumber(order.totalSourceAmount);
      current.grossRevenue += totalSale;
      current.estimatedProfit += totalSale - totalSource;
      if (order.status === "DELIVERED") {
        current.deliveredOrders += 1;
      }
      points.set(label, current);
    }

    const series = Array.from(points.values());
    const totals = series.reduce(
      (accumulator, item) => ({
        grossRevenue: accumulator.grossRevenue + item.grossRevenue,
        estimatedProfit: accumulator.estimatedProfit + item.estimatedProfit,
        deliveredOrders: accumulator.deliveredOrders + item.deliveredOrders,
      }),
      {
        grossRevenue: 0,
        estimatedProfit: 0,
        deliveredOrders: 0,
      },
    );

    return {
      summary: totals,
      series,
    };
  }
}
