import { Inject, Injectable, NotFoundException } from "@nestjs/common";
import {
  decryptSecret,
  isMockBotToken,
  telegramAnswerCallbackQuery,
  telegramEditMessageText,
  telegramSendMessage,
  telegramSendPhoto,
} from "@reseller/shared/server";

import { AppConfigService } from "../config/app-config.service";
import { OrdersService } from "../orders/orders.service";
import { ShopsService } from "../shops/shops.service";
import { formatCurrency } from "./utils";

type TelegramUpdate = Record<string, any>;

@Injectable()
export class TelegramBotService {
  constructor(
    @Inject(ShopsService)
    private readonly shopsService: ShopsService,
    @Inject(OrdersService)
    private readonly ordersService: OrdersService,
    @Inject(AppConfigService)
    private readonly config: AppConfigService,
  ) {}

  async handleIncomingUpdate(shopId: string, update: TelegramUpdate) {
    const shop = await this.shopsService.getSellerShopByShopId(shopId);
    const token = decryptSecret(
      shop.botConfig?.telegramBotTokenEncrypted,
      this.config.encryptionKey,
    );

    if (!token) {
      throw new NotFoundException("Bot token is missing.");
    }

    const actions: unknown[] = [];
    const callbackQuery = update.callback_query;
    const message = update.message;

    if (message?.text?.startsWith("/start")) {
      await this.renderHome(shopId, token, message.chat.id, undefined, actions);
      return { ok: true, actions };
    }

    if (message?.text?.startsWith("/products")) {
      await this.renderCatalog(shopId, token, message.chat.id, undefined, 0, actions);
      return { ok: true, actions };
    }

    if (message?.text?.startsWith("/help")) {
      await this.sendText(
        token,
        message.chat.id,
        this.buildGuideText(shop.name),
        actions,
      );
      return { ok: true, actions };
    }

    if (message?.text?.startsWith("/support")) {
      await this.sendText(
        token,
        message.chat.id,
        this.buildSupportText(shop.name, shop.supportTelegram, shop.supportZalo),
        actions,
      );
      return { ok: true, actions };
    }

    if (callbackQuery) {
      const data = String(callbackQuery.data || "");
      const chatId = callbackQuery.message?.chat?.id;
      const messageId = callbackQuery.message?.message_id;

      if (chatId && callbackQuery.id) {
        await this.answerCallback(token, callbackQuery.id, actions);
      }

      if (data === "home:menu") {
        await this.renderHome(shopId, token, chatId, messageId, actions);
      } else if (data === "home:products") {
        await this.renderCatalog(shopId, token, chatId, messageId, 0, actions);
      } else if (data === "home:guide") {
        await this.editOrSend(
          token,
          chatId,
          messageId,
          this.buildGuideText(shop.name),
          {
            inline_keyboard: [
              [
                { text: "Danh sách sản phẩm", callback_data: "home:products" },
                { text: "Trang chủ", callback_data: "home:menu" },
              ],
            ],
          },
          actions,
        );
      } else if (data === "home:support") {
        await this.editOrSend(
          token,
          chatId,
          messageId,
          this.buildSupportText(shop.name, shop.supportTelegram, shop.supportZalo),
          {
            inline_keyboard: [
              [
                { text: "Trang chủ", callback_data: "home:menu" },
                { text: "Sản phẩm", callback_data: "home:products" },
              ],
            ],
          },
          actions,
        );
      } else if (data.startsWith("catalog:page:")) {
        const page = Number(data.split(":").pop() || "0");
        await this.renderCatalog(shopId, token, chatId, messageId, page, actions);
      } else if (data.startsWith("buy:")) {
        const sourceProductId = data.slice(4);
        await this.handleBuy(
          shopId,
          token,
          sourceProductId,
          {
            telegramUserId: String(callbackQuery.from?.id || ""),
            telegramChatId: String(chatId || callbackQuery.from?.id || ""),
            telegramUsername: callbackQuery.from?.username || null,
            firstName: callbackQuery.from?.first_name || null,
            lastName: callbackQuery.from?.last_name || null,
          },
          actions,
        );
      }
    }

    return { ok: true, actions };
  }

  async sendDeliveredMessage(
    shopId: string,
    chatId: string,
    productName: string,
    deliveredAccountText: string,
  ) {
    const shop = await this.shopsService.getSellerShopByShopId(shopId);
    const token = decryptSecret(
      shop.botConfig?.telegramBotTokenEncrypted,
      this.config.encryptionKey,
    );

    if (!token) {
      return;
    }

    await this.sendText(
      token,
      chatId,
      [
        "Thanh toán thành công",
        `Sản phẩm: ${productName}`,
        "",
        "Tài khoản của bạn:",
        deliveredAccountText,
        "",
        "Vui lòng đổi mật khẩu sau khi đăng nhập để đảm bảo an toàn.",
      ].join("\n"),
      [],
    );
  }

  private async renderHome(
    shopId: string,
    token: string,
    chatId: number,
    messageId: number | undefined,
    actions: unknown[],
  ) {
    const shop = await this.shopsService.getSellerShopByShopId(shopId);
    const products = await this.shopsService.getCatalogViewForShop(shopId);
    const available = products.filter((item) => item.available === null || item.available > 0);

    await this.editOrSend(
      token,
      chatId,
      messageId,
      [
        `${shop.name}`,
        shop.tagline || "Kho tài khoản tự động, cập nhật liên tục 24/7.",
        "",
        `Sản phẩm đang hiển thị: ${products.length}`,
        `Sản phẩm còn hàng: ${available.length}`,
        "",
        "Chọn một mục bên dưới để bắt đầu.",
      ].join("\n"),
      {
        inline_keyboard: [
          [
            { text: "Xem sản phẩm", callback_data: "home:products" },
            { text: "Cách mua hàng", callback_data: "home:guide" },
          ],
          [{ text: "Liên hệ hỗ trợ", callback_data: "home:support" }],
        ],
      },
      actions,
    );
  }

  private async renderCatalog(
    shopId: string,
    token: string,
    chatId: number,
    messageId: number | undefined,
    page: number,
    actions: unknown[],
  ) {
    const products = (await this.shopsService.getCatalogViewForShop(shopId)).filter(
      (item) => item.enabled && !item.hidden,
    );
    const pageSize = 6;
    const pageCount = Math.max(1, Math.ceil(products.length / pageSize));
    const normalizedPage = Math.min(Math.max(page, 0), pageCount - 1);
    const startIndex = normalizedPage * pageSize;
    const pageItems = products.slice(startIndex, startIndex + pageSize);

    const lines = [
      "Danh sách sản phẩm",
      `Trang ${normalizedPage + 1}/${pageCount}`,
      "",
      ...pageItems.map(
        (item, index) =>
          `${startIndex + index + 1}. ${item.displayName} | ${formatCurrency(item.salePrice)} | Còn: ${
            item.available === null ? "?" : item.available
          }`,
      ),
    ];

    const navigationRow: Array<Record<string, unknown>> = [];
    if (normalizedPage > 0) {
      navigationRow.push({
        text: "Trang trước",
        callback_data: `catalog:page:${normalizedPage - 1}`,
      });
    }
    if (normalizedPage < pageCount - 1) {
      navigationRow.push({
        text: "Trang sau",
        callback_data: `catalog:page:${normalizedPage + 1}`,
      });
    }

    await this.editOrSend(
      token,
      chatId,
      messageId,
      lines.join("\n"),
      {
        inline_keyboard: [
          ...pageItems.map((item) => [
            {
              text: `${item.displayName} • ${formatCurrency(item.salePrice)}`,
              callback_data: `buy:${item.id}`,
            },
          ]),
          ...(navigationRow.length > 0 ? [navigationRow] : []),
          [
            { text: "Trang chủ", callback_data: "home:menu" },
            { text: "Hỗ trợ", callback_data: "home:support" },
          ],
        ],
      },
      actions,
    );
  }

  private async handleBuy(
    shopId: string,
    token: string,
    sourceProductId: string,
    customer: {
      telegramUserId: string;
      telegramChatId: string;
      telegramUsername?: string | null;
      firstName?: string | null;
      lastName?: string | null;
    },
    actions: unknown[],
  ) {
    const created = await this.ordersService.createTelegramOrder({
      shopId,
      sourceProductId,
      quantity: 1,
      telegramUserId: customer.telegramUserId,
      telegramChatId: customer.telegramChatId,
      telegramUsername: customer.telegramUsername,
      firstName: customer.firstName,
      lastName: customer.lastName,
    });

    await this.sendText(
      token,
      customer.telegramChatId,
      [
        `Đơn hàng ${created.order.orderCode}`,
        `Sản phẩm: ${created.order.productName}`,
        `Thanh toán: ${formatCurrency(created.order.totalSaleAmount)}`,
        "",
        "Mở link checkout để hoàn tất thanh toán. Sau khi xác nhận thành công, hệ thống sẽ tự động giao tài khoản.",
      ].join("\n"),
      actions,
      {
        inline_keyboard: [
          [{ text: "Mở trang thanh toán", url: created.checkoutUrl }],
          [{ text: "Trang chủ", callback_data: "home:menu" }],
        ],
      },
    );
  }

  private buildGuideText(shopName: string) {
    return [
      `${shopName} | Hướng dẫn mua hàng`,
      "",
      "1. Bấm vào danh sách sản phẩm.",
      "2. Chọn gói bạn muốn mua.",
      "3. Mở link thanh toán và hoàn tất giao dịch.",
      "4. Hệ thống sẽ giao tài khoản ngay sau khi upstream thành công.",
    ].join("\n");
  }

  private buildSupportText(
    shopName: string,
    supportTelegram: string | null,
    supportZalo: string | null,
  ) {
    return [
      `${shopName} | Hỗ trợ`,
      "",
      supportTelegram ? `Telegram: ${supportTelegram}` : null,
      supportZalo ? `Zalo: ${supportZalo}` : null,
      "",
      "Khi nhắn hỗ trợ, vui lòng gửi kèm mã đơn hàng để xử lý nhanh hơn.",
    ]
      .filter(Boolean)
      .join("\n");
  }

  private async editOrSend(
    token: string,
    chatId: number,
    messageId: number | undefined,
    text: string,
    replyMarkup: Record<string, unknown>,
    actions: unknown[],
  ) {
    if (messageId) {
      return this.editText(token, chatId, messageId, text, replyMarkup, actions);
    }

    return this.sendText(token, chatId, text, actions, replyMarkup);
  }

  private async sendText(
    token: string,
    chatId: string | number,
    text: string,
    actions: unknown[],
    replyMarkup?: Record<string, unknown>,
  ) {
    if (this.config.mockTelegramEnabled && isMockBotToken(token)) {
      actions.push({ type: "sendMessage", chatId, text, replyMarkup });
      return;
    }

    await telegramSendMessage(token, chatId, text, {
      reply_markup: replyMarkup,
    });
  }

  private async editText(
    token: string,
    chatId: string | number,
    messageId: number,
    text: string,
    replyMarkup: Record<string, unknown>,
    actions: unknown[],
  ) {
    if (this.config.mockTelegramEnabled && isMockBotToken(token)) {
      actions.push({ type: "editMessageText", chatId, messageId, text, replyMarkup });
      return;
    }

    await telegramEditMessageText(token, chatId, messageId, text, {
      reply_markup: replyMarkup,
    }).catch(async () => {
      await telegramSendMessage(token, chatId, text, {
        reply_markup: replyMarkup,
      });
    });
  }

  private async answerCallback(token: string, callbackQueryId: string, actions: unknown[]) {
    if (this.config.mockTelegramEnabled && isMockBotToken(token)) {
      actions.push({ type: "answerCallbackQuery", callbackQueryId });
      return;
    }

    await telegramAnswerCallbackQuery(token, callbackQueryId).catch(() => undefined);
  }
}
