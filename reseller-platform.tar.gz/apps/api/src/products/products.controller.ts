import { Body, Controller, Delete, Get, Inject, Param, Post, Put, UseGuards } from "@nestjs/common";

import { CurrentUser } from "../common/decorators/current-user.decorator";
import { JwtAuthGuard } from "../common/guards/jwt-auth.guard";
import type { AuthenticatedUser } from "../types";

import {
  CreateManualProductDto,
  PurgeDeliveredInventoryDto,
  UpdateProductDto,
} from "./products.dto";
import { ProductsService } from "./products.service";

@Controller("products")
@UseGuards(JwtAuthGuard)
export class ProductsController {
  constructor(
    @Inject(ProductsService)
    private readonly productsService: ProductsService,
  ) {}

  @Get()
  listProducts(@CurrentUser() user: AuthenticatedUser) {
    return this.productsService.listProducts(user);
  }

  @Get(":id/inventory")
  getProductInventory(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.productsService.getProductInventory(user, id);
  }

  @Get(":id")
  getProduct(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.productsService.getProduct(user, id);
  }

  @Post(":id/inventory/purge-delivered")
  purgeDeliveredInventory(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() body: PurgeDeliveredInventoryDto,
  ) {
    return this.productsService.purgeDeliveredInventory(user, id, body);
  }

  @Post("manual")
  createManualProduct(
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: CreateManualProductDto,
  ) {
    return this.productsService.createManualProduct(user, body);
  }

  @Put(":id")
  updateProduct(
    @CurrentUser() user: AuthenticatedUser,
    @Param("id") id: string,
    @Body() body: UpdateProductDto,
  ) {
    return this.productsService.updateProduct(user, id, body);
  }

  @Delete(":id")
  deleteProduct(@CurrentUser() user: AuthenticatedUser, @Param("id") id: string) {
    return this.productsService.deleteProduct(user, id);
  }
}
