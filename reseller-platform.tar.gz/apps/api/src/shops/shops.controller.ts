import { Body, Controller, Get, Inject, Post, Put, UseGuards } from "@nestjs/common";

import { CurrentUser } from "../common/decorators/current-user.decorator";
import { JwtAuthGuard } from "../common/guards/jwt-auth.guard";
import type { AuthenticatedUser } from "../types";

import { UpdateBotConfigDto, UpdateShopDto } from "./shops.dto";
import { ShopsService } from "./shops.service";

@Controller()
@UseGuards(JwtAuthGuard)
export class ShopsController {
  constructor(
    @Inject(ShopsService)
    private readonly shopsService: ShopsService,
  ) {}

  @Get("shops/current")
  getCurrentShop(@CurrentUser() user: AuthenticatedUser) {
    return this.shopsService.getCurrentShop(user);
  }

  @Put("shops/current")
  updateCurrentShop(
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: UpdateShopDto,
  ) {
    return this.shopsService.updateCurrentShop(user, body);
  }

  @Get("bot-config")
  getBotConfig(@CurrentUser() user: AuthenticatedUser) {
    return this.shopsService.getBotConfig(user);
  }

  @Put("bot-config")
  updateBotConfig(
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: UpdateBotConfigDto,
  ) {
    return this.shopsService.updateBotConfig(user, body);
  }

  @Post("bot-config/verify-telegram")
  verifyTelegram(@CurrentUser() user: AuthenticatedUser) {
    return this.shopsService.verifyTelegram(user);
  }

  @Post("bot-config/verify-provider")
  verifyProvider(@CurrentUser() user: AuthenticatedUser) {
    return this.shopsService.verifyProvider(user);
  }

  @Post("bot-config/sync-products")
  syncProducts(@CurrentUser() user: AuthenticatedUser) {
    return this.shopsService.syncProducts(user);
  }
}
