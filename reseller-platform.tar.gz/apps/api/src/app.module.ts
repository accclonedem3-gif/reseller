import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";

import { AuthController } from "./auth/auth.controller";
import { AuthService } from "./auth/auth.service";
import { BroadcastsController } from "./broadcasts/broadcasts.controller";
import { BroadcastsService } from "./broadcasts/broadcasts.service";
import { JwtAuthGuard } from "./common/guards/jwt-auth.guard";
import { RolesGuard } from "./common/guards/roles.guard";
import { AppConfigService } from "./config/app-config.service";
import { CustomerWalletService } from "./customer-wallet/customer-wallet.service";
import { PrismaService } from "./db/prisma.service";
import { DevController } from "./dev/dev.controller.v2";
import { InternalController } from "./internal/internal.controller";
import { PaymentService } from "./lib/payment.service";
import { BinancePayService } from "./lib/binance-pay.service";
import { OnchainPaymentService } from "./lib/onchain-payment.service";
import { QueueService } from "./lib/queue.service";
import { TelegramBotService } from "./lib/telegram-bot.service.v2";
import { OrdersController } from "./orders/orders.controller";
import { OrdersService } from "./orders/orders.service";
import { ProductsController } from "./products/products.controller";
import { ProductsService } from "./products/products.service";
import { ReportsController } from "./reports/reports.controller";
import { ReportsService } from "./reports/reports.service";
import { ShopsController } from "./shops/shops.controller";
import { ShopsService } from "./shops/shops.service";
import { WalletController } from "./wallet/wallet.controller";
import { WalletService } from "./wallet/wallet.service";
import { WebhooksController } from "./webhooks/webhooks.controller";

@Module({
  imports: [
    JwtModule.register({}),
  ],
  controllers: [
    AuthController,
    ShopsController,
    ProductsController,
    OrdersController,
    WalletController,
    ReportsController,
    BroadcastsController,
    WebhooksController,
    InternalController,
    DevController,
  ],
  providers: [
    AppConfigService,
    PrismaService,
    QueueService,
    BinancePayService,
    OnchainPaymentService,
    PaymentService,
    TelegramBotService,
    AuthService,
    ShopsService,
    CustomerWalletService,
    ProductsService,
    WalletService,
    OrdersService,
    ReportsService,
    BroadcastsService,
    JwtAuthGuard,
    RolesGuard,
  ],
})
export class AppModule {}
