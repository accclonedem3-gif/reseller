import { IsEmail, IsOptional, IsString, MinLength } from "class-validator";

export class LoginDto {
  @IsString()
  @MinLength(2)
  username!: string;

  @IsString()
  @MinLength(6)
  password!: string;
}

export class RefreshDto {
  @IsString()
  refreshToken!: string;
}

export class ForgotPasswordDto {
  @IsEmail()
  email!: string;
}

export class ResetPasswordDto {
  @IsString()
  @MinLength(32)
  token!: string;

  @IsString()
  @MinLength(10)
  newPassword!: string;
}

export class RegisterSellerDto {
  @IsEmail()
  email!: string;

  @IsString()
  @MinLength(10)
  password!: string;

  @IsString()
  @MinLength(2)
  displayName!: string;
}

export class CreateSellerByAdminDto {
  @IsString()
  @MinLength(2)
  username!: string;

  @IsString()
  @MinLength(10)
  password!: string;

  @IsString()
  @MinLength(2)
  displayName!: string;

  @IsOptional()
  @IsEmail()
  recoveryEmail?: string;

  @IsOptional()
  @IsString()
  @MinLength(2)
  shopName?: string;
}

export class UpdateSellerByAdminDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  username?: string;

  @IsOptional()
  @IsString()
  @MinLength(2)
  displayName?: string;

  @IsOptional()
  @IsString()
  @MinLength(2)
  shopName?: string;

  @IsOptional()
  @IsEmail()
  recoveryEmail?: string | null;

  @IsOptional()
  @IsString()
  @MinLength(10)
  password?: string;
}

export class ChangePasswordDto {
  @IsString()
  @MinLength(6)
  currentPassword!: string;

  @IsString()
  @MinLength(10)
  newPassword!: string;
}

export class UpdateRecoveryEmailDto {
  @IsOptional()
  @IsEmail()
  recoveryEmail?: string | null;
}
