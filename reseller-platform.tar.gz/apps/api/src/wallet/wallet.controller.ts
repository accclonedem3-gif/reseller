import { Body, Controller, Get, Inject, Post, UseGuards } from "@nestjs/common";

import { CurrentUser } from "../common/decorators/current-user.decorator";
import { JwtAuthGuard } from "../common/guards/jwt-auth.guard";
import type { AuthenticatedUser } from "../types";

import {
  CreateDepositRequestDto,
  CreateWithdrawRequestDto,
} from "./wallet.dto";
import { WalletService } from "./wallet.service";

@Controller("wallet")
@UseGuards(JwtAuthGuard)
export class WalletController {
  constructor(
    @Inject(WalletService)
    private readonly walletService: WalletService,
  ) {}

  @Get()
  getWallet(@CurrentUser() user: AuthenticatedUser) {
    return this.walletService.getWallet(user);
  }

  @Get("source-balance")
  getSourceWallet(@CurrentUser() user: AuthenticatedUser) {
    return this.walletService.getSourceWallet(user);
  }

  @Get("ledgers")
  getWalletLedgers(@CurrentUser() user: AuthenticatedUser) {
    return this.walletService.getWalletLedgers(user);
  }

  @Get("deposit-requests")
  listDepositRequests(@CurrentUser() user: AuthenticatedUser) {
    return this.walletService.listDepositRequests(user);
  }

  @Get("withdraw-requests")
  listWithdrawRequests(@CurrentUser() user: AuthenticatedUser) {
    return this.walletService.listWithdrawRequests(user);
  }

  @Post("deposit-requests")
  createDepositRequest(
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: CreateDepositRequestDto,
  ) {
    return this.walletService.createDepositRequest(user, body);
  }

  @Post("withdraw-requests")
  createWithdrawRequest(
    @CurrentUser() user: AuthenticatedUser,
    @Body() body: CreateWithdrawRequestDto,
  ) {
    return this.walletService.createWithdrawRequest(user, body);
  }
}
